# -*- coding: utf-8 -*-
'''
Script for Cutting a Release.

Instructions:

If there are static changes:
    Compress static, make new static content version, update static version in
        proper config files.

    update the sandbox and prod THEMING_SVN_STATIC_LOCATION configs in moon_pie
        deployment settings to point to the new release tag for billpay.

Next compare the dev, cert, sandbox and prod config in the main trunk. Ensure no
    one has added any keys to dev that are not in cert, and no keys exist in cert
    that are not in sandbox and prod.

Third compare the trunk/etc binaries against:
http://scm.iqhealth-release.cerner.corp/svn/external/
Move any new binaries across to the release repo.

Fourth, in this file, set the appropriate tag/branch name.

Fifth, run this command (Expect it to take around 7 min to run tag):
    python apple.py run_tag

Once the tag is created, go to the iqhealth-release repo and copy over the
    sensitive_settings config files from stage and prod.

'''
import subprocess
import tempfile
import os
import sys
import re
import shutil

IQH_PROJECTS = frozenset([
                        'iqh_billpay',
                        'iqh_backends',
                        'iqh_clients',
                        'iqh_email',
                        'iqh_template_loaders',
                        'iqh_bp_smoke_tests',
                        'configurations'
                        ])

AXIOM_INSTALL_PROJECTS = frozenset(["fabric_utils",])

ALL_AXIOM_RELEASE_PROJECTS = AXIOM_INSTALL_PROJECTS

ALL_IQH_PROJECTS = IQH_PROJECTS

ALL_IQH_TAG_PROJECTS = IQH_PROJECTS

ALL_AXIOM_PROJECTS = ALL_AXIOM_RELEASE_PROJECTS

ALL_INSTALL_PROJECTS = AXIOM_INSTALL_PROJECTS

NON_INSTALL_RELEASE_PROJECTS = IQH_PROJECTS

ALL_RELEASE_PROJECTS = IQH_PROJECTS | ALL_AXIOM_RELEASE_PROJECTS

branch = "go"
tag = "2019-06-10-billpay"

branch_source_base = "http://scm.iqhealth-emr.cerner.corp/svn/python/trunk/"
branch_dest_base = "http://scm.iqhealth-emr.cerner.corp/svn/python/branches/"

axiom_branch_source_base = "http://scm.healthe-axiom.cerner.corp/svn/axiom-python-services/branches/go/"

tag_source_base = branch_dest_base + branch + "/"
tag_dest_base = "http://scm.iqhealth-emr.cerner.corp/svn/python/tags/"

release_repo_base = "http://scm.iqhealth-release.cerner.corp/svn/"

svn_temp_folder = tempfile.gettempdir()+"/svntemp"
branch_temp_folder = svn_temp_folder+"/branch_"+branch
tag_temp_folder = svn_temp_folder+"/"+tag
release_tag_temp_folder = tag_temp_folder+"-exported"

def create_main_branch():
    subprocess.check_call(["svn", "mkdir",
                           "{0}{1}".format(branch_dest_base, branch),
                           "-m \"Cutting {0} branch\" ".format(branch)])

    print ALL_IQH_PROJECTS
    for project in ALL_IQH_PROJECTS:
        print "Branching Project:"+project
        subprocess.check_call(["svn", "copy",
                               "{0}{1}".format(branch_source_base, project),
                               "{0}{1}/{2}".format(branch_dest_base, branch, project),
                               "-m \"Branching for {0}\" ".format(project)])

def branch_axiom_projects():
    print branch_temp_folder
    os.chdir(branch_temp_folder + '/' + branch)

    print ALL_AXIOM_PROJECTS
    for project in ALL_AXIOM_PROJECTS:
        print "Branching Project:"+project
        subprocess.check_call(["svn",
                               "export",
                               "{0}{1}".format(axiom_branch_source_base, project),
                               ]
        )
        subprocess.check_call(['svn', 'add', project])

    subprocess.check_call(['svn', 'commit', '-m Copying cernerhealth dependencies for release {0}'.format(branch)])

def check_out_branch():
    #Make Sure svn temp folder exists
    if not os.path.exists(svn_temp_folder):
        os.makedirs(svn_temp_folder)

    #attempt to delete old copy of tag
    if  os.path.exists(branch_temp_folder):
        shutil.rmtree(branch_temp_folder, False)

    os.makedirs(branch_temp_folder)
    os.chdir(branch_temp_folder)
    subprocess.check_call([
                           "svn",
                           "checkout",
                           "{0}{1}".format(branch_dest_base, branch)])

def create_main_tag():
    #Don't need this step if the tag has been manually created
    subprocess.check_call(['svn',
                          'mkdir',
                          '{0}{1}'.format(tag_dest_base, tag),
                           '-m \"Cutting tag for release {0}\" '.format(tag)])

    print ALL_IQH_TAG_PROJECTS
    all_projects_list = list(ALL_IQH_TAG_PROJECTS)
    all_projects_list.sort()
    for project in all_projects_list:
        print "Cutting Project:"+project
        subprocess.check_call(['svn',
                               'copy',
                               '{0}{1}'.format(tag_source_base, project),
                               '{0}{1}/{2}'.format(tag_dest_base, tag, project),
                               '-m \"Cutting tag for release {0}\" '.format(project)]
                               )

def check_out_tag():
    #Make Sure svn temp folder exists
    if not os.path.exists(svn_temp_folder):
        os.makedirs(svn_temp_folder)

    #attempt to delete old copy of tag
    if  os.path.exists(tag_temp_folder):
        shutil.rmtree(tag_temp_folder, False)

    #Now commands will be run in the svn_temp_folder
    os.chdir(svn_temp_folder)
    subprocess.check_call(['svn',
                           'checkout',
                           '{0}{1}'.format(tag_dest_base, tag)])

def tag_axiom_projects():
    print tag_temp_folder
    os.chdir(tag_temp_folder)

    print ALL_AXIOM_PROJECTS
    for project in ALL_AXIOM_PROJECTS:
        print "Tagging Project:"+project
        subprocess.check_call(["svn",
                               "export",
                               "{0}{1}".format(axiom_branch_source_base, project),
                               ]
        )
        subprocess.check_call(['svn', 'add', project])

    subprocess.check_call(['svn', 'commit', '-m Committing cernerhealth dependencies for release {0}'.format(tag)])

def export_copy_of_tag():
    """
    This will remove all the svn meta data from the dev repo before we import
    it into the release repo
    """
    os.chdir(svn_temp_folder)
    subprocess.check_call(['svn',
                           'export',
                           '{0}'.format(tag),
                           '{0}-exported'.format(tag)])

def update_release_fab_files():
    environment = [
         "api.env['iqh_svn_root'] = 'http://cernciesvn01.cernerasp.com/iqhealth-release/iqhbp/tags/{0}/'".format(tag),
         "api.env['axiom_svn_root'] = 'http://cernciesvn01.cernerasp.com/iqhealth-release/iqhbp_install/tags/{0}/'".format(tag),
                   ]

    fab_file = release_tag_temp_folder+"/iqh_billpay/fabfile.py"
    _append_lines_to_file(fab_file, environment)

def import_iqhbp():
    subprocess.check_call(['svn',
                           'mkdir',
                           '{0}iqhbp/tags/{1}'.format(release_repo_base, tag),
                           '-m \"Cutting tag for release {0}\" '.format(tag)])

    os.chdir(release_tag_temp_folder)
    for project in NON_INSTALL_RELEASE_PROJECTS:
        subprocess.check_call(['svn',
                               'import',
                               '{0}'.format(project),
                               '{0}iqhbp/tags/{1}/{2}'.format(release_repo_base, tag, project),
                               '-m \"Cutting tag for release {0}\" '.format(tag)])

def import_install():
    subprocess.check_call(['svn',
                          'mkdir',
                          '{0}iqhbp-install/tags/{1}'.format(release_repo_base, tag),
                          '-m \"Cutting tag for release {0}\" '.format(tag)])

    os.chdir(release_tag_temp_folder)
    for project in ALL_INSTALL_PROJECTS:
        subprocess.check_call(['svn',
                               'import',
                               '{0}'.format(project),
                               '{0}iqhbp-install/tags/{1}/{2}'.format(release_repo_base, tag, project),
                               '-m \"Cutting tag for release {0}\" '.format(tag)])

def _sub_lines_in_file(file_path, lines_dct):
    with open(file_path, "r") as fin:
        lines = []
        for line in fin:
            lines.append(line)

    for key, value in lines_dct.items():
        newlines = []
        for line in lines:
            newlines.append(re.sub(key, value, line))
        lines = newlines

    with open(file_path, "w") as fout:
        for line in lines:
            fout.write(line)

def _append_lines_to_file(file_path, lines_to_add):
    with open(file_path, "r") as fin:
        lines = []
        for line in fin:
            lines.append(line)

    for line in lines_to_add:
        lines.append('\n')
        lines.append(line)

    with open(file_path, "w") as fout:
        for line in lines:
            fout.write(line)

def run_branch():
    create_main_branch()
    check_out_branch()
    branch_axiom_projects()

def run_tag():
    create_main_tag()
    check_out_tag()
    tag_axiom_projects()
    export_copy_of_tag()
    update_release_fab_files()

    import_iqhbp()
    import_install()

COMMANDS = dict()
COMMANDS['run_branch'] = run_branch
COMMANDS['run_tag'] = run_tag


def _help():
    print 'Valid commands: {0}'.format(' '.join(COMMANDS.keys()))

COMMANDS['help'] = _help

if __name__ == "__main__":
    if len(sys.argv) <= 1:
        run_branch()
    else:
        command = sys.argv[1]
        func = COMMANDS.get(command, None)
        if func:
            func()
        else:
            print 'Yo no comprendo "{0}". Valid commands: {1}'.format(command,
                                                                      COMMANDS)
    sys.exit()
