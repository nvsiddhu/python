# -*- coding: utf-8 -*-


def helper(arg):
    """
    Acts as a callable helper function for the django debug toolbar
    because the toolbar needs a dotted path to a callable function.
    """
    return True
