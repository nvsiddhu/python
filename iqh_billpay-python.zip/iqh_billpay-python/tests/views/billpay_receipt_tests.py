# -*- coding: utf-8 -*-

from django.core import mail
from django.core.urlresolvers import reverse
from django.utils.dateformat import format

from axiom_dates.timezones import utc_naive_to_tz
from axiom_django.templatetags.axiom_phone import phone_format
from datetime import datetime
from views import PAYMENT_DATA_SESSION_KEY, TOKEN_REFERENCE_ID_SESSION_KEY
from mock import patch, MagicMock
from tests.views.base_billpay_test import BaseBillPayTest


class BaseBillPayTest(BaseBillPayTest):
    """ Tests Bill Pay receipt flows """
    functional = True

    @patch('views.payments.get_payment')
    @patch('views.payments.get_account')
    def test_get_receipt(self, get_account, get_payment):
        """
        The Receipt should display the following details:
            facility name, payment amount, remaining balance, receipt number,
            masked patient account number, patient name, payment date and time,
            billing provider's name, billing provider's address, billing provider's phone number,
            masked credit card number, credit card type, and name on credit card.
        The user should have the option to print the receipt.
        The user should have the option to email the receipt.
        The Receipt page shall allow the user to return to the View Accounts page.
        """
        form_data = {'payment_amount': 1000, 'interchange_id': '123', 'masked_card_number': '************1111', 'card_type': 'Visa', 'expiration_date': '2099-1-1', 'payer_name': 'Jane Smith', 'address': '200 1st St.', 'city': 'Chicago', 'state': 'IL', 'postal_code': '99999'}
        self.login_user('g_1')
        self.set_payment_data_in_session(form_data)
        self.set_token_reference_id_session()

        get_account.return_value = self._mock_acount()
        get_payment.return_value = self._mock_payment_info()

        response = self.client.get(reverse('payment', args=['44444', '5678']))
        self.assertContains(response, response.context['acct']['facility'])
        self.assertContains(response, str(response.context['payment']['amount']))
        self.assertContains(response, str(response.context['payment']['remaining_balance']))
        self.assertContains(response, response.context['payment']['receipt_number'])
        self.assertContains(response, response.context['acct']['masked_account_number'])
        self.assertContains(response, response.context['acct']['patient_name'])
        payment_date = utc_naive_to_tz(datetime.utcnow(), 'America/Chicago')
        self.assertContains(response, format(payment_date, "F j, Y P"))
        self.assertContains(response, response.context['payment']['payee_name'])
        self.assertContains(response, response.context['payment']['payee_address_line_1'])
        self.assertContains(response, response.context['payment']['payee_city'])
        self.assertContains(response, response.context['payment']['payee_state'])
        self.assertContains(response, response.context['payment']['payee_postal_code'])
        self.assertContains(response, phone_format(response.context['payment']['payee_phone']))
        self.assertContains(response, '************1111')
        self.assertContains(response, 'Visa')
        self.assertContains(response, response.context['payment']['payer_name'])
        self.assertContains(response, 'Print')
        self.assertContains(response, reverse('email_receipt', args=['44444', '5678']))
        self.assertContains(response, reverse('view_accounts'))

        self.assertIsNone(self.client.session[TOKEN_REFERENCE_ID_SESSION_KEY])
        self.assertIsNone(self.client.session[PAYMENT_DATA_SESSION_KEY])

    @patch('views.payments')
    @patch('views.get_cache')
    def test_clear_failure_counter_cache(self, get_cache, mock_payments):
        """
        As a user, the number of failure attempts I've made should be cleared
        when the payment has been successfully made on the check status page.
        """
        self.login_user('g_1')
        self.set_payment_data_in_session()
        self.set_token_reference_id_session()

        cache = MagicMock()
        cache.get.return_value = True
        get_cache.return_value = cache

        mock_payments.check_payment_status.return_value = ('success', {'payment_id': '600'})
        mock_payments.get_account.return_value = self._mock_acount()
        mock_payments.get_payment.return_value = self._mock_payment_info()

        url = reverse('payment', args=['44444', '5678']) + '?i=t'
        self.client.get(url)

        self.assertTrue(cache.delete_many.called)

    @patch('views.payments')
    @patch('views.get_cache')
    def test_dont_clear_failure_counter_cache(self, get_cache, mock_payments):
        """
        As a user, the number of failure attempts I've made SHOULD NOT be cleared
        when the user navigates to the receipt page without completing the submit
        payment workflow.
        """
        self.login_user('g_1')
        self.set_payment_data_in_session()
        self.set_token_reference_id_session()

        cache = MagicMock()
        # cache should not be set since the user did not attempt to submit a payment
        cache.get.return_value = None
        get_cache.return_value = cache

        mock_payments.check_payment_status.return_value = ('success', {'payment_id': '600'})
        mock_payments.get_account.return_value = self._mock_acount()
        mock_payments.get_payment.return_value = self._mock_payment_info()

        url = reverse('payment', args=['44444', '5678']) + '?i=t'
        self.client.get(url)

        self.assertFalse(cache.delete_many.called)

    @patch('views.payments')
    @patch('views.get_cache')
    def test_check_payment_status_called_success_payment_data(self, get_cache, mock_payments):
        """
        check_payment_status function should be called with required parameters (including the
        correct card_type) in payment function when payment_data isn't available. When it returns
        success, we should redirect user to payment url and show payment receipt.
        """
        self.login_user('g_1')
        self.set_payment_data_in_session()
        self.set_token_reference_id_session()

        cache = MagicMock()
        cache.get.return_value = True
        get_cache.return_value = cache

        mock_payments.check_payment_status.return_value = ('success', {'payment_id': '600'})
        mock_payments.get_account.return_value = self._mock_acount()
        mock_payments.get_payment.return_value = self._mock_payment_info()

        url = reverse('payment', args=['44444', '5678']) + '?i=t'
        response = self.client.get(url)

        mock_payments.check_payment_status.assert_called_with(u'baseline-south', 'g_1', u'44444', u'5678', 'SUBMITTER_TSEP', 'Visa')
        self.assertEquals(response.request.get('PATH_INFO'), '/quickpay/accounts/44444/payment/5678')
        self.assertTemplateUsed(response, 'payment_receipt.html')

    @patch('views.payments')
    @patch('views.get_cache')
    def test_check_payment_status_called_timeout_payment_data(self, get_cache, mock_payments):
        """
        check_payment_status function should be called with required parameters (including the
        correct card_type) in payment function when payment_data isn't available. When it returns
        timeout, we should show payment_status.html template to the user.
        """
        self.login_user('g_1')
        self.set_payment_data_in_session()
        self.set_token_reference_id_session()

        cache = MagicMock()
        cache.get.return_value = True
        get_cache.return_value = cache

        mock_payments.check_payment_status.return_value = ('timeout', {'payment_id': '600'})
        mock_payments.get_account.return_value = self._mock_acount()
        mock_payments.get_payment.return_value = self._mock_payment_info()

        url = reverse('payment', args=['44444', '5678']) + '?i=t'
        response = self.client.get(url)

        mock_payments.check_payment_status.assert_called_with(u'baseline-south', 'g_1', u'44444', u'5678', 'SUBMITTER_TSEP', 'Visa')
        self.assertTemplateUsed(response, 'payment_status.html')

    @patch('views.payments')
    @patch('views.get_cache')
    def test_check_payment_status_called_success_no_payment_data(self, get_cache, mock_payments):
        """
        check_payment_status function should be called with required parameters (and None for
        card_type) in payment function when payment_data isn't available. When it returns success,
        we should redirect user to payment url and show payment receipt.
        """
        self.login_user('g_1')
        self.set_payment_data_in_session(set_data=False)
        self.set_token_reference_id_session()

        cache = MagicMock()
        cache.get.return_value = True
        get_cache.return_value = cache

        mock_payments.check_payment_status.return_value = ('success', {'payment_id': '600'})
        mock_payments.get_account.return_value = self._mock_acount()
        mock_payments.get_payment.return_value = self._mock_payment_info()

        url = reverse('payment', args=['44444', '5678']) + '?i=t'
        response = self.client.get(url)

        mock_payments.check_payment_status.assert_called_with(u'baseline-south', 'g_1', u'44444', u'5678', 'SUBMITTER_TSEP', None)
        self.assertEquals(response.request.get('PATH_INFO'), '/quickpay/accounts/44444/payment/5678')
        self.assertTemplateUsed(response, 'payment_receipt.html')

    @patch('views.payments')
    @patch('views.get_cache')
    def test_check_payment_status_called_timeout_no_payment_data(self, get_cache, mock_payments):
        """
        check_payment_status function should be called with required parameters (and None for
        card_type) in payment function when payment_data isn't available. When it returns timeout,
        we should show payment_status.html template to the user.
        """
        self.login_user('g_1')
        self.set_payment_data_in_session(set_data=False)
        self.set_token_reference_id_session()

        cache = MagicMock()
        cache.get.return_value = True
        get_cache.return_value = cache

        mock_payments.check_payment_status.return_value = ('timeout', {'payment_id': '600'})
        mock_payments.get_account.return_value = self._mock_acount()
        mock_payments.get_payment.return_value = self._mock_payment_info()

        url = reverse('payment', args=['44444', '5678']) + '?i=t'
        response = self.client.get(url)

        mock_payments.check_payment_status.assert_called_with(u'baseline-south', 'g_1', u'44444', u'5678', 'SUBMITTER_TSEP', None)
        self.assertTemplateUsed(response, 'payment_status.html')

    @patch('views.payments.get_payment')
    @patch('views.payments.get_account')
    def test_email_receipt(self, get_account, get_payment):
        """
        The email subject shall contain the organization name.
        The "From" email address shall be configurable by organization.
        The email shall display the following receipt details:
            payment amount, remaining balance, receipt number,
            masked patient account number, patient name, payment date/time,
            billing provider's name, billing provider's address,
            billing provider's phone number, and name on credit card.
        If the email is successfully sent, a message shall display indicating the receipt was successfully sent.
        """
        self.login_user('g_4')
        self.set_payment_data_in_session()
        self.set_token_reference_id_session()

        get_account.return_value = self._mock_acount()
        get_payment.return_value = self._mock_payment_info()

        post_data = {'email': 'quickpay@yopmail.com'}
        response = self.client.post(reverse('email_receipt', args=['44444', '9876']),
                                    post_data, follow=True)
        self.assertRedirects(response, reverse('payment', args=['44444', '9876']))
        self.assertContains(response, 'alert-message success')

        self.assertEqual(len(mail.outbox), 1)
        email = mail.outbox[0]
        self.assertTrue(email.subject.find(self.org['name']) > -1)
        self.assertEqual(email.from_email, self.domain['notification_email'])
        self.assertEqual(email.to[0], post_data['email'])
        self.assertTrue(email.body.find(str(response.context['payment']['amount'])) > -1)
        self.assertTrue(email.body.find(str(response.context['payment']['remaining_balance'])) > -1)
        self.assertTrue(email.body.find(response.context['payment']['receipt_number']) > -1)
        self.assertTrue(email.body.find(response.context['payment']['masked_account_number']) > -1)
        self.assertTrue(email.body.find(response.context['payment']['patient_name']) > -1)
        payment_date = utc_naive_to_tz(datetime.utcnow(), 'America/Chicago')
        self.assertTrue(email.body.find(format(payment_date, "F j, Y P")) > -1)
        self.assertTrue(email.body.find(response.context['payment']['payee_name']) > -1)
        self.assertTrue(email.body.find(response.context['payment']['payee_address_line_1']) > -1)
        self.assertTrue(email.body.find(response.context['payment']['payee_city']) > -1)
        self.assertTrue(email.body.find(response.context['payment']['payee_state']) > -1)
        self.assertTrue(email.body.find(phone_format(response.context['payment']['payee_phone'])) > -1)
        self.assertTrue(email.body.find(response.context['payment']['payer_name']) > -1)

    @patch('views.send_email_from_templates')
    def test_email_receipt_failure(self, mock):
        """
        If the email fails, a message shall display indicating the email was not sent.
        """
        self.login_user('g_4')
        self.set_payment_data_in_session()
        self.set_token_reference_id_session()

        def raise_exception():
            raise Exception
        mock.side_effect = raise_exception

        post_data = {'email': 'quickpay@yopmail.com'}
        response = self.client.post(reverse('email_receipt', args=['44444', '9876']),
                                    post_data, follow=True)
        self.assertRedirects(response, reverse('payment', args=['44444', '9876']))
        self.assertContains(response, 'alert-message danger')

        self.assertEqual(len(mail.outbox), 0)

    def _mock_acount(self):
        return {
            'id': '44444',
            'account_number': '4444-4444-444',
            'masked_account_number': 'XXXX-XXXX-444',
            'patient_name': 'Jane Smith',
            'facility': 'Baseline South',
            'last_payment_amount': None,
            'last_payment_date': None,
            'amount_due': 566.44,
            'bad_debt_amount': 0,
            'payment_receiver_id': 'scenario4'
        }

    def _mock_payment_info(self):
        return {
            'receipt_number': 'r5678',
            'amount': 1.00,
            'payment_date': datetime.utcnow(),
            'account_number': '4444-4444-444',
            'masked_account_number': 'XXXX-XXXX-444',
            'patient_name': 'Jane Smith',
            'payer_name': 'Smith, John',
            'payee_name': 'Baseline South',
            'payee_address_line_1': '123 Main St.',
            'payee_city': 'Kansas City',
            'payee_state': 'MO',
            'payee_postal_code': '64117',
            'payee_phone': '8165557654'
        }
