# -*- coding: utf-8 -*-

from django.conf import settings
from django.test import TestCase
from mock import patch
from mock_services import (fake_get_careaware_service_url, fake_get_oauth_client, fake_accounts_http_get,
                        fake_get_facility, fake_http_post, fake_submit_credit_payment, fake_get_payment_response,
                        fake_get_guarantor_http_get, fake_get_payment_types_http_get,
                        fake_get_payment, fake_payment_response_http_get, fake_http_put, fake_get_payment_http_get,
                        fake_get_account, fake_submit_credit_payment_http_post, fake_account_http_get, fake_get_facility_http_get, fake_get_payment_types_manifest_device_id,
                        test_facility, test_account_1, test_account_2, test_account_3)
from datetime import datetime
from iqh_payments.backends.hnam_rest_payments import PaymentBackend
from replicators import build_org, build_config, build_domain
import mock


class BillPayBackendTests(TestCase):
    """ Tests Bill Pay Backend """
    whitebox = True

    def setUp(self):
        self.payments = PaymentBackend()
        build_config()
        self.domain = build_domain()
        self.org = build_org()

    @mock.patch("iqh_payments.backends.hnam_rest_payments.get_service_url", fake_get_careaware_service_url)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.PaymentBackend._get_oauth_client", fake_get_oauth_client)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.requests.get", fake_get_guarantor_http_get)
    def test_get_guarantor_id(self):
        """
        get_guarantor_id should return guarantor id when org_slug, access_code,
        last_name and birth_date are passed in
        """
        try:
            self.payments.get_guarantor_id('baseline-south', '00000', 'smith', '1/1/1970')
            self.fail('expected an exception, failed to retrieve resource')
        except:
            pass

        try:
            self.payments.get_guarantor_id('baseline-south', '00000', 'smith', '1/100/1970')
            self.fail('expected an exception, invalid dob')
        except:
            pass

        guarantor_id = self.payments.get_guarantor_id('baseline-south', '12345', 'smith', '1/1/1970')
        self.assertEqual(guarantor_id, 'g_1', 'guarantor_id should be g_1, instead it was {0}'.format(guarantor_id))

        guarantor_id = self.payments.get_guarantor_id('baseline-south', '54321', 'smith', '1/1/1970')
        self.assertEqual(guarantor_id, 'g_2', 'guarantor_id should be g_2, instead it was {0}'.format(guarantor_id))

        guarantor_id = self.payments.get_guarantor_id('baseline-south', '99999', 'smith', '1/1/1970')
        self.assertEqual(guarantor_id, None, 'guarantor_id should be None, instead it was {0}'.format(guarantor_id))

        guarantor_id = self.payments.get_guarantor_id('baseline-south', '67890', 'smith', '1/1/1890')
        self.assertEqual(guarantor_id, 'g_3', 'guarantor_id should be g_3, instead it was {0}'.format(guarantor_id))

    @mock.patch("iqh_payments.backends.hnam_rest_payments.get_service_url", fake_get_careaware_service_url)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.PaymentBackend._get_oauth_client", fake_get_oauth_client)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.requests.get", fake_accounts_http_get)
    def test_get_accounts(self):
        """
        get_accounts should return all accounts for a guarantor in an org
        """
        try:
            self.payments.get_accounts('baseline-south', 'g_4')
            self.fail('expected an exception')
        except:
            pass

        accounts = self.payments.get_accounts('baseline-south', 'g_1')
        self.assertEqual(len(accounts), 3, 'expected 3 accounts')
        self._verify_account(accounts[0], test_account_1)
        self._verify_account(accounts[1], test_account_2)
        self._verify_account(accounts[2], test_account_3)

        accounts = self.payments.get_accounts('baseline-south', 'g_2')
        self.assertEqual(len(accounts), 1, 'expected 1 account')
        self._verify_account(accounts[0], test_account_2)

        accounts = self.payments.get_accounts('baseline-south', 'g_3')
        self.assertEqual(len(accounts), 0, 'expected 0 accounts')

    @mock.patch("iqh_payments.backends.hnam_rest_payments.get_service_url", fake_get_careaware_service_url)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.PaymentBackend._get_oauth_client", fake_get_oauth_client)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.PaymentBackend._get_facility", fake_get_facility)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.requests.get", fake_account_http_get)
    def test_get_account(self):
        """
        get_accounts should return a single account given an org, gaurantor_id, and an account_id
        """
        try:
            self.payments.get_account('baseline-south', 'g_1', '7777')
            self.fail('expected an exception')
        except:
            pass

        account = self.payments.get_account('baseline-south', 'g_1', '1234')
        self._verify_account(account, test_account_1)
        self.assertEqual(account['payment_receiver_id'], '444')

        account = self.payments.get_account('baseline-south', 'g_2', '1235')
        self._verify_account(account, test_account_2)
        self.assertEqual(account['payment_receiver_id'], '444')

        account = self.payments.get_account('baseline-south', 'g_3', '1234')
        self.assertEqual(account, None)

    @mock.patch("iqh_payments.backends.hnam_rest_payments.requests.get", fake_get_payment_types_http_get)
    def test_get_supported_payment_types_and_merchant_id(self):
        """
        get_supported_payment_types should return a list of supported payment types given an org and a payment_receiver_id
        """
        payment_types, merchant_id = self.payments.get_supported_payment_types_and_merchant_id('baseline-south', '444', 'g_1', '1234')
        self.assertTrue(payment_types['visa'], 'visa was an expected payment type')
        self.assertTrue(payment_types['mastercard'], 'mastercard was an expected payment type')
        self.assertTrue(payment_types['discover'], 'discover was an expected payment type')
        self.assertTrue(payment_types['american_express'], 'american express was an expected payment type')
        self.assertEqual(merchant_id, '123456789')

        payment_types, merchant_id = self.payments.get_supported_payment_types_and_merchant_id('baseline-south', '445', 'g_2', '1235')
        self.assertFalse(payment_types['visa'], 'visa was not an expected payment type')
        self.assertFalse(payment_types['mastercard'], 'mastercard was not an expected payment type')
        self.assertFalse(payment_types['discover'], 'discover was not an expected payment type')
        self.assertFalse(payment_types['american_express'], 'american express was not an expected payment type')
        self.assertEqual(merchant_id, '123456789')

        payment_types, merchant_id = self.payments.get_supported_payment_types_and_merchant_id('baseline-south', '555', 'g_3', '1236')
        self.assertEqual(payment_types, {}, 'expected payment_types to be an empty dict')
        self.assertEqual(merchant_id, None)

        payment_types, merchant_id = self.payments.get_supported_payment_types_and_merchant_id('baseline-south', '666', 'g_4', '1237')
        self.assertEqual(payment_types, {}, 'expected payment_types to be an empty dict')
        self.assertEqual(merchant_id, None)

        payment_types, merchant_id = self.payments.get_supported_payment_types_and_merchant_id('baseline-south', '777', 'g_5', '1238')
        self.assertEqual(payment_types, {}, 'expected payment_types to be an empty dict')
        self.assertEqual(merchant_id, None)

    @patch('iqh_payments.backends.hnam_rest_payments.logger')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.post', fake_get_payment_types_manifest_device_id)
    def test_get_merchant(self, mock_logger):
        """
        get_supported_payment_types_and_manifest_and_device_id should return supported payment types, manifest and
        device id when provided with an org and payment_receiver_id.
        """
        merchant = self.payments.get_merchant('test_slug', '111', 'g_1', '1234')
        payment_types = merchant.get('payment_types')
        manifest = merchant.get('manifest')
        device_id = merchant.get('device_id')
        self.assertTrue(payment_types['visa'])
        self.assertTrue(payment_types['mastercard'])
        self.assertTrue(payment_types['discover'])
        self.assertTrue(payment_types['american_express'])
        self.assertEqual(manifest, 'a1a1a1a1')
        self.assertEqual(device_id, '8888')

        merchant = self.payments.get_merchant('test_slug', '222', 'g_2', '1235')
        payment_types = merchant.get('payment_types')
        manifest = merchant.get('manifest')
        device_id = merchant.get('device_id')
        self.assertFalse(payment_types['visa'])
        self.assertFalse(payment_types['mastercard'])
        self.assertFalse(payment_types['discover'])
        self.assertFalse(payment_types['american_express'])
        self.assertEqual(manifest, 'a1a1a1a1')
        self.assertEqual(device_id, '8888')

        merchant = self.payments.get_merchant('test_slug', '333', 'g_3', '1236')
        payment_types = merchant.get('payment_types')
        manifest = merchant.get('manifest')
        device_id = merchant.get('device_id')
        self.assertEqual(payment_types, {})
        self.assertIsNone(manifest)
        self.assertIsNone(device_id)
        mock_logger.error.assert_called_with('An error was returned from {}merchant/.'.format(settings.EDI_BILLPAY_API_URL)
        + ' Response was:{"ack": {"errors": {"error": [{"errorCode": "401", "errorMsg": "401 - 401 - Invalid submitter or password"}]}}}. Org_Slug=test_slug, Payment_Receiver_ID=333, Guarantor_ID=g_3, Account_ID=1236.')

        merchant = self.payments.get_merchant('test_slug', '444', 'g_4', '1237')
        payment_types = merchant.get('payment_types')
        manifest = merchant.get('manifest')
        device_id = merchant.get('device_id')
        self.assertEqual(payment_types, {})
        self.assertIsNone(manifest)
        self.assertIsNone(device_id)
        mock_logger.exception.assert_called_with("Failed to retrieve resource at {}merchant/ for Org_Slug=test_slug, Payment_Receiver_ID=444, Guarantor_ID=g_4, Account_ID=1237".format(settings.EDI_BILLPAY_API_URL))

        merchant = self.payments.get_merchant('test_slug', '555', 'g_5', '1238')
        payment_types = merchant.get('payment_types')
        manifest = merchant.get('manifest')
        device_id = merchant.get('device_id')
        self.assertEqual(payment_types, {})
        self.assertIsNone(manifest)
        self.assertIsNone(device_id)
        mock_logger.error.assert_called_with("Failed to retrieve resource at {}merchant/ for Org_Slug=test_slug, Payment_Receiver_ID=555, Guarantor_ID=g_5, Account_ID=1238. Response was: 404 ".format(settings.EDI_BILLPAY_API_URL))

    @patch('iqh_payments.backends.hnam_rest_payments.time.sleep')
    @mock.patch("iqh_payments.backends.hnam_rest_payments.get_service_url", fake_get_careaware_service_url)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.PaymentBackend._get_oauth_client", fake_get_oauth_client)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.PaymentBackend.get_payment", fake_get_payment)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.requests.get", fake_payment_response_http_get)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.requests.put", fake_http_put)
    def test_check_payment_status(self, mock_time_sleep):
        """
        check_payment_status returns the results of _get_payment_response
        """
        payment_status = self.payments.check_payment_status('baseline-south', 'g_1', '1234', '111111', '444', 'Visa')
        self.assertEqual(payment_status[0], 'success', 'expected success')
        self.assertEqual(payment_status[1]['payment_id'], '111111')

        payment_status = self.payments.check_payment_status('baseline-south', 'g_1', '1234', '111112', '444', 'Visa')
        self.assertEqual(payment_status[0], 'failure', 'expected failure')
        self.assertEqual(payment_status[1]['error_code'], 'declined')

        payment_status = self.payments.check_payment_status('baseline-south', 'g_1', '1235', '111113', '444', 'Visa')
        self.assertEqual(payment_status[0], 'timeout', 'expected timeout')
        self.assertEqual(payment_status[1]['payment_id'], '111113')

        payment_status = self.payments.check_payment_status('baseline-south', 'g_1', '1236', '111114', '444', 'Visa')
        self.assertEqual(payment_status[0], 'failure', 'expected failure')
        self.assertEqual(payment_status[1]['error_code'], 'submission_failure')

        payment_status = self.payments.check_payment_status('baseline-south', 'g_1', '1234', '111115', '444', 'Visa')
        self.assertEqual(payment_status[0], 'timeout', 'expected timeout')
        self.assertEqual(payment_status[1]['payment_id'], '111115')

        payment_status = self.payments.check_payment_status('baseline-south', 'g_2', '1235', '111116', '444', 'Visa')
        self.assertEqual(payment_status[0], 'timeout', 'expected timeout')
        self.assertEqual(payment_status[1]['payment_id'], '111116')

    @mock.patch("iqh_payments.backends.hnam_rest_payments.get_service_url", fake_get_careaware_service_url)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.PaymentBackend._get_oauth_client", fake_get_oauth_client)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.PaymentBackend.get_account", fake_get_account)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.PaymentBackend._get_facility", fake_get_facility)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.requests.get", fake_get_payment_http_get)
    def test_get_payment(self):
        """
        get_payment returns a payment given org_slug, guarantor_id, account_id, and payment_id
        """
        try:
            self.payments.get_payment('baseline-south', 'g_1', '1235', '0001')
            self.fail('expected an exception')
        except:
            pass

        payment = self.payments.get_payment('baseline-south', 'g_1', '1234', '0001')
        self.assertEqual(payment['receipt_number'], '123221')
        self.assertEqual(payment['amount'], 0.49)
        self.assertEqual(payment['payment_date'], datetime(2012, 2, 22, 0, 0))
        self.assertEqual(payment['account_number'], '1234')
        self.assertEqual(payment['masked_account_number'], '***4')
        self.assertEqual(payment['patient_name'], 'John Smith')
        self.assertEqual(payment['payer_name'], 'John Smith')
        self.assertEqual(payment['transaction_id'], '000001')
        self.assertEqual(payment['payee_name'], test_facility['name'])
        self.assertEqual(payment['payee_address_line_1'], test_facility['address_line_1'])
        self.assertEqual(payment['payee_address_line_2'], test_facility['address_line_2'])
        self.assertEqual(payment['payee_city'], test_facility['city'])
        self.assertEqual(payment['payee_state'], test_facility['state'])
        self.assertEqual(payment['payee_postal_code'], test_facility['postal_code'])
        self.assertEqual(payment['payee_phone'], test_facility['phone'])

    @mock.patch("iqh_payments.backends.hnam_rest_payments.requests.get", fake_get_facility_http_get)
    @mock.patch("iqh_payments.backends.hnam_rest_payments.PaymentBackend._get_oauth_client", fake_get_oauth_client)
    def test_get_facility(self):
        """
        given a facility id _get_facility should return a dict containing facility informaiton
        """
        org_slug = 'baseline'
        oauth_client = self.payments._get_oauth_client(org_slug, "config")
        base_service_url = 'baseserviceurl.com'

        #{"submitterId":"444","name":"John Smith","streetAddress1":"123 Fake Street","streetAddress2":"Suite 103","streetAddress3":"",
        #"streetAddress4":"","city":"Kansas City","state":"MO","zipCode":"64117","country":"USA","phone":"888-123-4567"}
        try:
            self.payments._get_facility('0000', oauth_client, base_service_url, org_slug)
            self.fail('expected an exception')
        except:
            pass

        facility = self.payments._get_facility('1111', oauth_client, base_service_url, org_slug)
        self._verify_facility(facility, test_facility)

    def _verify_account(self, account, test_account):
        self.assertEqual(test_account['id'], account['id'])
        self.assertEqual(test_account['account_number'], account['account_number'])
        self.assertEqual(test_account['masked_account_number'], account['masked_account_number'])
        self.assertEqual(test_account['patient_name'], account['patient_name'])
        self.assertEqual(test_account['facility'], account['facility'])
        self.assertEqual(test_account['facility_id'], account['facility_id'])
        self.assertEqual(test_account['last_payment_amount'], account['last_payment_amount'])
        self.assertEqual(test_account['last_payment_date'], account['last_payment_date'])
        self.assertEqual(test_account['amount_due'], account['amount_due'])
        self.assertEqual(test_account['bad_debt_amount'], account['bad_debt_amount'])

    def _verify_facility(self, facility, test_facility):
        self.assertEqual(test_facility['payment_receiver_id'], facility['payment_receiver_id'])
        self.assertEqual(test_facility['name'], facility['name'])
        self.assertEqual(test_facility['address_line_1'], facility['address_line_1'])
        self.assertEqual(test_facility['address_line_2'], facility['address_line_2'])
        self.assertEqual(test_facility['address_line_3'], facility['address_line_3'])
        self.assertEqual(test_facility['address_line_4'], facility['address_line_4'])
        self.assertEqual(test_facility['city'], facility['city'])
        self.assertEqual(test_facility['state'], facility['state'])
        self.assertEqual(test_facility['postal_code'], facility['postal_code'])
        self.assertEqual(test_facility['country'], facility['country'])
        self.assertEqual(test_facility['phone'], facility['phone'])
