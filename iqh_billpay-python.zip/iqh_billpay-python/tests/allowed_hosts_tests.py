# -*- coding: utf-8 -*-

from mock import patch

from django.conf import settings
from django.test import TestCase
from django.test.utils import override_settings

from allowed_hosts_setting import AllowedHosts
from iqh_domains.models import Domain


@override_settings(ALLOWED_HOSTS=AllowedHosts())
class AllowedHostsTests(TestCase):
    "Test settings.ALLOWED_HOSTS"

    @patch.object(Domain, 'objects')
    def test_allowed_hosts(self, domain_mock):
        """
        Allowed hosts setting should contain domain names for those domains that
        are configured in the S Tool so Django doesn't thrown a SuspiciousOperation when
        handling the request.
        """
        domain_mock.values.return_value = [{'domain_name': 'test'}, {'domain_name': 'test1'}]
        hosts = [host for host in settings.ALLOWED_HOSTS]
        self.assertEquals(len(hosts), 2)
        self.assertEquals(list(hosts), ['test', 'test1'])

    @patch.object(Domain, 'objects')
    def test_allowed_hosts_empty(self, domain_mock):
        """
        Allowed hosts setting should be empty if no domain names are
        configured.
        """
        domain_mock.values.return_value = []
        hosts = [host for host in settings.ALLOWED_HOSTS]
        self.assertEquals(len(hosts), 0)

    @patch.object(Domain, 'objects')
    def test_allowed_hosts_called_multiple_times(self, domain_mock):
        """
        Allowed hosts setting should return the same domain names when called multiple times.
        """
        domain_mock.values.return_value = [{'domain_name': 'test'}, {'domain_name': 'test1'}]
        expected_output = ['test', 'test1']
        for x in range(2):
            self.assertEquals(list(settings.ALLOWED_HOSTS), expected_output)

    @patch.object(Domain, 'objects')
    @override_settings(DEPLOYMENT_MODE='stage')
    def test_allowed_hosts_staging(self, domain_mock):
        """
        Allowed hosts setting should return sandboxpaymyhealthbill.com when deployment mode
        is stage. This domain will be used to publish themes for billpay.
        """
        domain_mock.values.return_value = [{'domain_name': 'test'}, {'domain_name': 'test1'}]
        hosts = [host for host in settings.ALLOWED_HOSTS]
        self.assertEquals(len(hosts), 3)

        # the root domain should be at the end of the list
        self.assertEquals(hosts[2], 'sandboxpaymyhealthbill.com')

    @patch.object(Domain, 'objects')
    @override_settings(DEPLOYMENT_MODE='prod')
    def test_allowed_hosts_prod(self, domain_mock):
        """
        Allowed hosts setting should return paymyhealthbill.com when deployment mode
        is prod. This domain will be used to publish themes for billpay.
        """
        domain_mock.values.return_value = [{'domain_name': 'test'}, {'domain_name': 'test1'}]
        hosts = [host for host in settings.ALLOWED_HOSTS]
        self.assertEquals(len(hosts), 3)

        # the root domain should be at the end of the list
        self.assertEquals(hosts[2], 'paymyhealthbill.com')
