# -*- coding: utf-8 -*-

from sensitive_settings import *
import os

DEBUG = False
DEPLOYMENT_MODE = "stage"

#STATIC_URL = 'https://sandboxcrnst.com/s/billpay/'
STATIC_URL = 'https://d2n71bzmceqrtw.cloudfront.net/s/billpay/'
STATIC_ROOT =  os.environ.get('STATIC_ROOT', '/opt/djangoprojects/billpay-static/')


# Mongo is used to write logs. This is the sandbox/staging mongo instance.
MONGODB_CONNECTION_URI = 'mongodb://cerncwpapp110,cerncwpapp111,cerncwpapp108'

# Session cookie for 15 minutes.
SESSION_COOKIE_AGE = 60 * 15
SESSION_COOKIE_SECURE = True

DATABASE_CONNECTION_POOL_SIZE = 5
DATABASE_CONNECTION_MAX_OVERFLOW = 10
DATABASE_CONNECTION_TIMEOUT = 30

CC_OAUTH_ACCESS_TOKEN_URL = 'https://api.sandboxcernercare.com/oauth/access'
CC_OAUTH_CONSUMER_KEY_IQH = '299f23e7-ef07-49a5-9dc1-d750171cea29'

EMAIL_HOST = 'mail.cernerasp.com'

# The EDI cert is not stable, so pointing our stage to EDI prod.
EDI_SUBMITTER_LOOKUP_API_URL = 'https://rapidservices.cernerasp.com/edi/'
EDI_BILLPAY_API_URL = 'https://revenuecyclepci.cernerworks.com/edi/epayment/'

EDI_TOKEN_REQUEST_API_URL = 'https://revenuecyclepci.cernerworks.com/edi/epayment/cors/token'
TOKENIZATION_SERVICE_TIMEOUT = 40000

TSEP_TRANSIT_DOMAIN = 'https://gateway.transit-pass.com'

STATSD_HOST = 'cerncwpapp59'
STATSD_PORT = 8125

#connection timeout for caches in milliseconds
CACHE_CONNECTION_TIMEOUT = 70

CACHE_HOSTS = ['cerniqhmem101', 'cerniqhmem102']

DEFAULT_CACHE = {
    'default': {
        'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
        #This must be a host in the PCI network
        'LOCATION': 'cerniqhqpapp101:11700',
        'VERSION': '1',
        'OPTIONS':{
            'connect_timeout': CACHE_CONNECTION_TIMEOUT,
            'hash': 'murmur',
            'distribution': 'consistent',
        }
    }
}

DEFAULT_FILE_STORAGE = 'storages.backends.s3boto.S3BotoStorage'
AWS_STORAGE_BUCKET_NAME = 'cerner-healthelife-iqh-public-stage'
AWS_S3_CUSTOM_DOMAIN = 'd28rxn7dspw3qi.cloudfront.net'
AWS_S3_FILE_OVERWRITE = False
AWS_QUERYSTRING_AUTH = False

AWS_HEADERS = {
    'x-amz-server-side-encryption': 'AES256',
}

THEMING_ACCESS_TOKEN = '5f9d7bc2-154a-44a3-b5fe-185fdd3b4b81'
VIRTUAL_ENV_BIN = '/opt/.virtualenvs/iqh_billpay/bin'
