# -*- coding: utf-8 -*-

import datetime
import json
from django.test import TestCase

from axiom_django.backends import get_backend
from mock import patch, MagicMock
import requests

from client_utils.oauth_util import SimpleOAuthClient


payments = get_backend('',
                       'iqh_payments.backends.hnam_rest_payments',
                       'PaymentBackend')


class TestCreatePayment(TestCase):

    @patch('iqh_payments.backends.hnam_rest_payments.requests.post')
    def test_create_payment_exception(self, MockPost):
        """
        create_payment should raise an exception when the
        request made to patient accounting to create the payment
        raised an exception.
        """
        MockPost.side_effect = requests.exceptions.Timeout
        with self.assertRaises(requests.exceptions.Timeout):
            self._create_payment()

    @patch('iqh_payments.backends.hnam_rest_payments.requests.post')
    def test_create_payment_failure(self, MockPost):
        """
        create_payment should raise an HTTPError when the request
        made to patient account to create a payment returns a
        4XX or 5XX.
        """
        self.mock_response = MagicMock()
        self.mock_response.headers = {'content-length': 4}
        self.mock_response.elapsed = datetime.timedelta(0)
        self.mock_response.raise_for_status.side_effect = requests.exceptions.HTTPError

        MockPost.return_value = self.mock_response

        with self.assertRaises(requests.exceptions.HTTPError):
            self._create_payment()

    @patch('iqh_payments.backends.hnam_rest_payments.requests.post')
    def test_create_payment_success(self, MockPost):
        """
        create_payment should return a payment_id when the request
        to create a payment is successful. create_payment should send
        the correct data to millennium to create the payment.
        """
        self.mock_response = MagicMock()
        self.mock_response.headers = {'content-length': 4}
        self.mock_response.elapsed = datetime.timedelta(0)
        self.mock_response.text = json.dumps({'paymentId': '123456'})

        MockPost.return_value = self.mock_response

        payment_id = self._create_payment()
        self.assertEquals(payment_id, '123456')

        # ensure the amount, reason, paymentMethod, and payerName data is appropriately set
        data = MockPost.call_args[1]['data']
        self.assertEquals(data, '{"amount": 0.49, "paymentReason": "ONLINEBILLPY", "paymentMethod": "CREDIT CARD", "payerName": "John Smith"}')

    def _create_payment(self):
        return payments.create_payment(
                'http://devtest.cerner.corp/edi',
                MagicMock(SimpleOAuthClient),
                'baseline-health',
                'guarantor_id',
                'account_id',
                0.49,
                'John Smith')
