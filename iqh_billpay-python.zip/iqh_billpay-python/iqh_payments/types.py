# -*- coding: utf-8 -*-

from collections import namedtuple


PaymentStatus = namedtuple('PaymentStatus',
        ['interchange_id',
         'approval_code',
         'amount_charged',
         'amount_requested',
         'code',
         'charged',
         'error_message']
)
