/*
 * Axiom - Modal
 * Requires presence of bootstrap modal jQuery plugin. See http://twitter.github.com/bootstrap/javascript.html#modal
 * Copyright(c) 2011- Cerner Corporation 
*/
$(function() {
  // Reference to the currently opened dialog, if any.
  var $dialog = null,
      offset = null,
      position = null;

  /**
  * Loads a dialog using XMLHttpRequest GET with the href attribute from the anchor in context.
  * @param {Event} e A click event triggered from an anchor element or one of its descendants.
  * @return false
  */
  function sendXHR(e) {
    $.ajax({ type: "get", url: this.href, success: success, error: error });
    return false;
  }

  /**
  * Submits a form and loads the response into a dialog using XMLHttpRequest with the method from the form element (or any of its descendants) in context.
  * @param {Event} e A (click | submit) event triggered from a form element or one of its descendants.
  */
  function submitXHR(e) {
    // TODO: if the trigger is an input, add it to the serialized data.
    var $form = this.tagName == "form" ? $(this) : $(this).closest("form");
    $.ajax({
      type: $form.attr("method"),
      url:  $form.attr("action"),
      data: $form.serialize(),
      statusCode: {
        200: success,
        204: closeDialog
      }
    }).error(error);
  }

  /**
  * Handles XMLHttpRequest failure.
  * @param {jqXHR} jqXHR
  * @param {String} textStatus
  * @param {String} errorThrown
  */
  function error(jqXHR, textStatus, errorThrown) {
    $('body').trigger("error.axiom-alerts", ["An error has occurred", "Please try again later."])
    if ($dialog) {
      $dialog.removeClass('fade').modal('hide');
    }
  }

  /**
  * Handles successful XMLHttpRequests containing dialog content.
  * @param {String} html
  */
  function success(html) {
    if ($dialog) {
      $dialog.replaceWith(html);
    } else {
      $dialog = $(html).hide().appendTo('body');
      $dialog.bind({ hidden: resetDialog, mousedown: beginDrag, mouseup: endDrag })
        .modal({ backdrop: true, keyboard: true, show: true })
        .css({ marginTop: -$dialog.outerHeight()/2 + "px" });
    }
  }

  /**
  * Resets the dialog reference to null.
  */
  function resetDialog() {
    $dialog.remove();
    $dialog = null;
  }

  /**
  * Handles events for closing the modal dialog
  * @param {Event} An event triggered from within the model indicating an intent to close the modal.
  */
  function closeDialog(e) {
    $dialog.modal('hide');
  }

  /**
  * Starts monitoring drag events.
  * @param {Event} e
  */
  function beginDrag(e) {
    if (e.target == $dialog.get(0)) {
      // Need to remove fade animations if the user drags
      $dialog.removeClass('fade');
      $(window).bind({ 'mousemove.axiom-modal': drag, 'mouseup.axiom-modal': endDrag });
      offset = $dialog.offset();
      position = { x: e.pageX, y: e.pageY };
    }
  }

  /**
  * Stops monitoring drag events.
  * @param {Event} e
  */
  function endDrag(e) {
    $(window).unbind('.axiom-modal');
  }

  /**
  * Recalculates the dialog's offset position.
  * @param {Event} e
  */
  function drag(e) {
    if (position.x === e.pageX && position.y === e.pageY) {
      return;
    }

    $dialog.offset(function() {
      offset = {
        top: offset.top + e.pageY - position.y,
        left: offset.left + e.pageX - position.x
      }
      return offset;
    });

    position = { x: e.pageX, y: e.pageY };
  }

  // Log an error if this component is loaded without the Twitter Bootstrapper Modal jQuery plugin.
  if (!$.fn.modal) {
    if (typeof console != 'undefined') {
      console.error("Twitter modal-bootstrap jQuery plugin not detected. Axiom modal component delegates not attached.");
    }
    return;
  }

  // Attach delegates
  $('body')
    .delegate('a[data-controls-load-modal]', 'click', sendXHR)
    .delegate('form[data-controls-load-modal] input[type=submit]', 'click', submitXHR)
    .delegate('form[data-controls-load-modal]', 'submit', submitXHR)
    .delegate('.modal .close-button', 'click', closeDialog);
});
