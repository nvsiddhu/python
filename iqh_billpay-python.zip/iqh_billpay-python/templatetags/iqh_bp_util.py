# -*- coding: utf-8 -*-

import re

from django.template import Library

register = Library()
   
@register.filter(name='is_phone_formatted')
def is_phone_formatted(phone_number):
    """
    This filter will check to see if a phone number is formatted.
    
    Example Usage:
    
    {% load iqh_bp_util %}
    {% if person.phone_number|is_phone_formatted %}
    
    @param phone_number: The phone_number to check for formatting
    @return True if the phone_number is formatted or is None, False otherwise
    """
    reg=re.compile('^\d+$')
    return not phone_number or not reg.match(phone_number)
