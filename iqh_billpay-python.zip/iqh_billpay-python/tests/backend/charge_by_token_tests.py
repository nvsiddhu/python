# -*- coding: utf-8 -*-

from mock import patch

from axiom_django.backends import get_backend
from requests.exceptions import Timeout, SSLError
from django.test import TestCase

from iqh_payments.types import PaymentStatus
from mock_services import fake_get_careaware_service_url, fake_get_oauth_client
from replicators import build_org, build_config

payments = get_backend('',
                       'iqh_payments.backends.hnam_rest_payments',
                       'PaymentBackend')


@patch("iqh_payments.backends.hnam_rest_payments.get_service_url", fake_get_careaware_service_url)
@patch("iqh_payments.backends.hnam_rest_payments.PaymentBackend._get_oauth_client", fake_get_oauth_client)
@patch.object(payments, "create_payment")
class TestChargeByToken(TestCase):

    def setUp(self):
        self.org = build_org()
        build_config()

    def test_exception_when_creating_payment(self, create_payment):
        """
        charge_by_token should return a payment status of 'failure'
        with an error_code of 'submission_failure' when the creation of the payment
        in millennium raised an exception.
        """
        create_payment.side_effect = Exception("Failure to create payment")
        status = self._charge()

        self.assertEquals(status, ('failure', {'error_code': 'submission_failure'}))

    def test_failure_when_creating_payment(self, create_payment):
        """
        charge_by_token should return a payment status of 'failure'
        with an error_code of 'submission_failure' when the payment
        in millennium failed to be created.
        """
        create_payment.return_value = None
        status = self._charge()

        self.assertEquals(status, ('failure', {'error_code': 'submission_failure'}))

    @patch.object(payments, '_update_payment')
    @patch.object(payments, '_submit_payment')
    def test_timeout_when_submitting_payment(self, submit_payment, update_payment, create_payment):
        """
        charge_by_token should return a payment status of 'timeout' and
        the payment_id when the submission of the payment timed out.
        """
        create_payment.return_value = '123456'
        submit_payment.side_effect = Timeout
        status = self._charge()
        self.assertEquals(status, ('timeout', {'payment_id': '123456'}))
        self.assertTrue(update_payment.called)

        # assert the reason that was sent to millennium when updating the payment status
        payment_status_reason = update_payment.call_args[0][1]
        self.assertEquals(payment_status_reason['statusReason'], 'TIMEOUT')

    @patch.object(payments, '_update_payment')
    @patch.object(payments, '_submit_payment')
    def test_SSL_timeout_when_submitting_payment(self, submit_payment, update_payment, create_payment):
        """
        charge_by_token should return a payment status of 'timeout' and
        the payment_id when the submission of the payment timed out due to SSL timeout error.
        """
        create_payment.return_value = '123456'
        submit_payment.side_effect = SSLError('read operation timed out')
        status = self._charge()
        self.assertEquals(status, ('timeout', {'payment_id': '123456'}))
        self.assertTrue(update_payment.called)

        # assert the reason that was sent to millennium when updating the payment status
        payment_status_reason = update_payment.call_args[0][1]
        self.assertEquals(payment_status_reason['statusReason'], 'TIMEOUT')

    @patch.object(payments, '_update_payment')
    @patch.object(payments, '_submit_payment')
    def test_SSL_non_timeout_when_submitting_payment(self, submit_payment, update_payment, create_payment):
        """
        charge_by_token should return a payment status of 'failure'
        with an error_code of 'submission_failure' and updates the payment
        status in millennium to 'CANCEL' when the submission of the payment
        raised a non timeout SSLError.
        """
        create_payment.return_value = '123456'
        submit_payment.side_effect = SSLError('handshake error')
        status = self._charge()

        self.assertEquals(status, ('failure', {'error_code': 'submission_failure'}))
        self.assertTrue(update_payment.called)

        # assert the reason that was sent to millennium when updating the payment status
        payment_status_reason = update_payment.call_args[0][1]
        self.assertEquals(payment_status_reason['paymentStatus'], 'CANCEL')
        self.assertEquals(payment_status_reason['statusReason'], 'GENERAL_SYSTEM_FAILURE')

    @patch.object(payments, '_update_payment')
    @patch.object(payments, '_submit_payment')
    def test_exception_when_submitting_payment(self, submit_payment, update_payment, create_payment):
        """
        charge_by_token should return a payment status of 'failure'
        with an error_code of 'submission_failure' and updates the payment
        status in millennium to 'CANCEL' when the submission of the payment
        raised an exception.
        """
        create_payment.return_value = '123456'
        submit_payment.side_effect = Exception('Failure to submit payment')
        status = self._charge()

        self.assertEquals(status, ('failure', {'error_code': 'submission_failure'}))
        self.assertTrue(update_payment.called)

        # assert the cancel reason that was sent to millennium when updating the payment status
        payment_status_reason = update_payment.call_args[0][1]
        self.assertEquals(payment_status_reason['paymentStatus'], 'CANCEL')
        self.assertEquals(payment_status_reason['statusReason'], 'GENERAL_SYSTEM_FAILURE')

    @patch.object(payments, '_get_error_code')
    @patch.object(payments, '_get_status_reason')
    @patch.object(payments, '_update_payment')
    @patch.object(payments, '_submit_payment')
    def test_status_code_failure_when_submitting_payment(self, submit_payment, update_payment,
                                            get_status_code, get_error_code, create_payment):
        """
        charge_by_token should return a payment status of 'failure'
        with the translated code and updates the payment status in millennium to 'CANCEL
        with the translated status reason when a status code is returned from EDI. The interchange_id
        passed to _update_payment must be the one received from _submit_payment.
        """
        payment_status = PaymentStatus(
            interchange_id='interchange1_id',
            code='01',
            approval_code=None,
            amount_charged=None,
            amount_requested=None,
            charged=False,
            error_message='Declined'
        )

        create_payment.return_value = '123456'
        submit_payment.return_value = payment_status
        get_status_code.return_value = 'DECLINED'
        get_error_code.return_value = 'declined'
        status = self._charge()

        self.assertTrue(status, ('failure', {'error_code': 'declined'}))
        self.assertTrue(update_payment.called)

        # Ensure we call _get_status_reason function to get the status reason
        # given the status code
        self.assertTrue(get_status_code.called)
        get_status_code.assert_called_with(payment_status.code)

        # Ensure we call _get_error_code function to get the error_code
        # given the status code
        self.assertTrue(get_error_code.called)
        get_error_code.assert_called_with(payment_status.code)

        # assert the cancel reason that was sent to millennium when updating the payment status
        payment_status_reason = update_payment.call_args[0][1]
        self.assertEquals(payment_status_reason['transactionId'], 'interchange1_id')
        self.assertEquals(payment_status_reason['paymentStatus'], 'CANCEL')
        self.assertEquals(payment_status_reason['statusReason'], 'DECLINED')

    @patch.object(payments, '_get_error_code')
    @patch.object(payments, '_get_status_reason')
    @patch.object(payments, '_update_payment')
    @patch.object(payments, '_submit_payment')
    def test_error_code_failure_when_submitting_payment(self, submit_payment, update_payment,
                                                get_status_code, get_error_code, create_payment):
        """
        charge_by_token should return a'failure' status with error_code
        submission_failure and updates the payment status in millennium to
        'CANCEL' with reason GENERAL_SYSTEM_FAILURE when an error code other than S6
        is returned from EDI. The interchange_id passed to _update_payment must be
        the one received form _submit_payment.
        """
        payment_status = PaymentStatus(
            interchange_id='interchange1_id',
            code='S2',
            approval_code=None,
            amount_charged=None,
            amount_requested=None,
            charged=False,
            error_message='Invalid Request'
        )

        create_payment.return_value = '123456'
        submit_payment.return_value = payment_status
        get_status_code.return_value = 'GENERAL_SYSTEM_FAILURE'
        get_error_code.return_value = 'submission_failure'
        status = self._charge()

        self.assertTrue(status, ('failure', {'error_code': 'submission_failure'}))
        self.assertTrue(update_payment.called)

        # Ensure we call _get_status_reason function to get the status reason
        # given the status code
        self.assertTrue(get_status_code.called)
        get_status_code.assert_called_with(payment_status.code)

        # Ensure we call _get_error_code function to get the error_code
        # given the status code
        self.assertTrue(get_error_code.called)
        get_error_code.assert_called_with(payment_status.code)

        # assert the cancel reason that was sent to millennium when updating the payment status
        payment_status_reason = update_payment.call_args[0][1]
        self.assertEquals(payment_status_reason['transactionId'], 'interchange1_id')
        self.assertEquals(payment_status_reason['paymentStatus'], 'CANCEL')
        self.assertEquals(payment_status_reason['statusReason'], 'GENERAL_SYSTEM_FAILURE')

    @patch.object(payments, '_update_payment')
    @patch.object(payments, '_submit_payment')
    def test_S6_error_code_when_submitting_payment(self, submit_payment, update_payment, create_payment):
        """
        charge_by_token should return a payment status of 'failure'
        with an error_code and updates the payment status in millennium to 'TIMEOUT' when
        an S6 error code is returned from EDI.
        """
        payment_status = PaymentStatus(
            interchange_id='interchange_id',
            code='S6',
            approval_code=None,
            amount_charged=None,
            amount_requested=None,
            charged=False,
            error_message='Server Not Avaliable'
        )

        create_payment.return_value = '123456'
        submit_payment.return_value = payment_status
        status = self._charge()

        self.assertTrue(status, ('timeout', {'payment_id': '123456'}))
        self.assertTrue(update_payment.called)

        # assert the reason that was sent to millennium when updating the payment status
        payment_status_reason = update_payment.call_args[0][1]
        self.assertEquals(payment_status_reason['statusReason'], 'TIMEOUT')

    @patch.object(payments, '_update_payment')
    @patch.object(payments, '_submit_payment')
    def test_success_when_submitting_payment(self, submit_payment, update_payment, create_payment):
        """
        charge_by_token should return a payment status of 'success'
        and the payment_id when the submission of the payment is
        successful. The interchange_id being passed to _update_payment
        must be the one received from _submit_payment.
        """
        payment_status = self._mock_successful_payment()

        create_payment.return_value = '123456'
        submit_payment.return_value = payment_status
        status = self._charge()

        self.assertTrue(status, ('success', {'payment_id': '123456'}))
        self.assertTrue(update_payment.called)

        # assert the status update sent to millennium when updating the payment status
        payment_status_reason = update_payment.call_args[0][1]
        self.assertEquals(payment_status_reason, {
                'transactionId': 'interchange1_id',
                'paymentStatus': 'POST',
                'referenceNumber': payment_status.approval_code,
                'amount': payment_status.amount_charged,
                'merchantID': '123456789',
                'cardNumber': '************1111',
                'expirationDate': '05/2019',
                'cardType': 'Visa'
            })

    def _charge(self):
        return payments.charge_by_token(
                self.org['slug'],
                'guarantor_id',
                'account_id',
                'payment_receiver_id',
                0.49,
                'Kevin Smith',
                'Address',
                'city',
                'state',
                '64177',
                'interchange_id',
                '************1111',
                'Visa',
                '05/2019',
                '123456789',
                'token_reference_id')

    def _mock_successful_payment(self):
        return PaymentStatus(
                interchange_id='interchange1_id',
                code='00',
                approval_code='854090',
                amount_charged=0.49,
                amount_requested=0.50,
                charged=True,
                error_message=None
                )
