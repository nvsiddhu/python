# -*- coding: utf-8 -*-

import unittest

from decorators import GUARANTOR_SESSION_KEY

from guarantor_auth.auth import guarantor_login, guarantor_logout
from iqh_billpay.tests.utils import BillpayRequestFactory


class LoginTests(unittest.TestCase):

    def setUp(self):
        self.request = BillpayRequestFactory().get("/")

        # create a fresh session w/ session key
        self.request.session.flush()

    def test_login_rotate_csrf_token(self):
        """
        The csrf token should be rotated when the user logs in.
        """
        old_csrf_token = self.request.META.get('CSRF_COOKIE')
        guarantor_login(self.request, '12345')
        new_csrf_token = self.request.META.get('CSRF_COOKIE')

        self.assertNotEquals(old_csrf_token, new_csrf_token)

    def test_login_fresh_session(self):
        """
        Create an empty session with a fresh session key when
        the current session's guarantor id does not match the
        guarantor id for the current user requesting to login.
        """

        old_session_key = self.request.session.session_key

        old_guarantor_id = '67890'
        new_guarantor_id = '12345'

        # set up session with a guarantor id that is not equal to the
        # guarantor id upon login.
        self.request.session[GUARANTOR_SESSION_KEY] = old_guarantor_id
        self.request.session['random_stuff_in_session'] = '123'
        guarantor_login(self.request, new_guarantor_id)

        new_session_key = self.request.session.session_key

        # verify the new guarantor id has been set
        guarantor_id = self.request.session[GUARANTOR_SESSION_KEY]
        self.assertEquals(guarantor_id, new_guarantor_id)

        # fresh session should not have any data from previous session
        self.assertIsNone(self.request.session.get('random_stuff_in_session'))
        self.assertNotEquals(old_session_key, new_session_key)

    def test_login_fresh_session_key(self):
        """
        Create an a fresh session key but retains the data when
        the current session does not have a guarantor id set in the
        current session. The new session should have the guarantor_id set.
        """

        old_session_key = self.request.session.session_key

        new_guarantor_id = '12345'

        self.request.session['random_stuff_in_session'] = '123'
        guarantor_login(self.request, new_guarantor_id)

        new_session_key = self.request.session.session_key

        # verify the new guarantor id has been set
        guarantor_id = self.request.session[GUARANTOR_SESSION_KEY]
        self.assertEquals(guarantor_id, new_guarantor_id)

        # session should have data set from previous session
        self.assertEquals(self.request.session.get('random_stuff_in_session'), '123')
        self.assertNotEquals(old_session_key, new_session_key)

    def test_login_dont_create_new_session(self):
        """
        Don't create a new session when the current session's guarantor id matches
        with the guarantor id for the current user requesting to login.
        """

        old_session_key = self.request.session.session_key

        current_guarantor_id = '12345'

        self.request.session[GUARANTOR_SESSION_KEY] = current_guarantor_id
        self.request.session['random_stuff_in_session'] = '123'
        guarantor_login(self.request, current_guarantor_id)

        new_session_key = self.request.session.session_key

        # verify the new guarantor id has been set
        guarantor_id = self.request.session[GUARANTOR_SESSION_KEY]
        self.assertEquals(guarantor_id, current_guarantor_id)

        self.assertEquals(self.request.session.get('random_stuff_in_session'), '123')
        self.assertEquals(old_session_key, new_session_key)


class LogoutTests(unittest.TestCase):

    def setUp(self):
        self.request = BillpayRequestFactory().get("/")

        # create a fresh session w/ session key
        self.request.session.flush()

    def test_logout(self):
        """
        On logout, the current user's session should be flushed and deleted.
        """

        guarantor_id = '12345'

        old_session_key = self.request.session.session_key
        self.request.session[GUARANTOR_SESSION_KEY] = guarantor_id
        self.request.session['random_stuff_in_session'] = '123'
        guarantor_logout(self.request)

        new_session_key = self.request.session.session_key

        self.assertIsNone(self.request.session.get(GUARANTOR_SESSION_KEY))
        self.assertIsNone(self.request.session.get('random_stuff_in_session'))
        self.assertNotEquals(old_session_key, new_session_key)

        self.assertFalse(self.request.session.exists(old_session_key))
