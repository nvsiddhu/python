# -*- coding: utf-8 -*-

"""Utilities to help generate objects. """

from iqh_domains import domains
from iqh_organizations import organizations
from iqh_configurations import configuration_enums
from iqh_configurations import configurations

def build_org(slug="baseline-south", name="Baseline South", domain="iqhbillpay.com"):

    org = {'default_security_question':'Last 4 digits of your SSN',
             'notification_email':'alex.beaumont@cerner.com',
             'java_context_root':'iqh2',
             'small_logo_url':'http://iqhwhiteboxphr.northamerica.cerner.net:8002/healthe/baseline-north-small.png',
             'large_logo_url':'http://iqhwhiteboxphr.northamerica.cerner.net:8002/healthe/baseline-north-large.png',
             'domain_id': "iqhbillpay.com"}
    org['slug'] = slug
    org['name'] = name
    org['domain'] = domain
    org['time_zone'] = 'America/Chicago'
    org_id = organizations.add(org)
    return organizations.get_by_id(org_id)

def build_config(org_slug="baseline-south"):
    org_config = {configuration_enums.CAREAWARE_SERVICE: {
                  'service_directory_url':'http://prod.app.exodus.cerner.corp/services-directory',
                  'consumer_key':'com.cerner.iqhealth',
                  'consumer_secret':'JOatjd/i5neMUviAsHgj+STA50wh6uFYKeZife4TdT1Uqo7yPeuUwnzEbpb9eizlP/0ASyW6F+hnMAyvW7N0xa01QYaI5WTQQ6zRrjsdqZdJIHSmvQT6vEN0BLfCCnAw8+XrbNNQmZPAZ5AXuel5xokL6Zm9uf2MB7OS3Im6fjs=',
                  'domain':'solution.northamerica.cerner.net',
                  'client_mnemonic': 'ENG_MO'},
             configuration_enums.GLOBAL: {'time_zone':'America/Chicago'}
             }
    for config_type, config in org_config.items():
        configurations.ensure(config_type, config, 'replicators.py', org_slug)

def build_domain(org_slug="baseline-south", res_domain="iqhbillpay.com"):
    domain = {'domain_name':'testserver',
              'res_domain':res_domain,
              'text':'Local Billpay',
              'site_root_uri':'http://testserver/',
              'ch_api_client_id':'testserver',
              'ch_api_client_secret':'testserver',
              'created_id':'replicators.py',
              'support_email':'support@testserver',
              'notification_email':'noreply@testserver',
              'default_org':org_slug
              }

    domains.add(domain)
    return domains.get(domain['domain_name'])
