# -*- coding: utf-8 -*-

import unittest

from mock import Mock
from django.http import HttpResponse

from iqh_billpay import middleware


class NoCacheMiddlwareTestCase(unittest.TestCase):

    def setUp(self):
        self.middleware = middleware.NoCacheMiddleware()

    def test_ignored_request_path(self):
        """
        NoCacheMiddleware should NOT set cache headers for paths configured to be ignored.
        """
        middleware.NOCACHE_MIDDLEWARE_IGNORE_PATHS = ['/path1', '/path2']
        request = Mock()
        request.path = '/path1/to/stuff'

        response = HttpResponse()
        response = self.middleware.process_response(request, response)

        self.assertFalse(response.has_header('Cache-Control'))
        self.assertFalse(response.has_header('Expires'))

    def test_set_cached_headers(self):
        """
        NoCacheMiddleware should set cache headers when response does NOT have existing cache headers,
        and the path is NOT configured to be ignored.
        """
        request = Mock()
        request.path = '/somepath'

        response = HttpResponse()
        response = self.middleware.process_response(request, response)

        self.assertTrue(response.has_header('Cache-Control'))
        self.assertEquals(response['Cache-Control'], 'no-cache, no-store, must-revalidate')
        self.assertTrue(response.has_header('Expires'))
        self.assertEquals(response['Expires'], '-1')

    def test_dont_overwrite_existing_cached_headers(self):
        """
        NoCacheMiddleware should NOT set cache headers when response already has existing cache headers,
        and the path is NOT configured to be ignored.
        """
        request = Mock()
        request.path = '/somepath'

        response = HttpResponse()
        response['Cache-Control'] = 'public'
        response['Expires'] = '365000'
        response = self.middleware.process_response(request, response)

        self.assertTrue(response.has_header('Cache-Control'))
        self.assertEquals(response['Cache-Control'], 'public')
        self.assertTrue(response.has_header('Expires'))
        self.assertEquals(response['Expires'], '365000')
