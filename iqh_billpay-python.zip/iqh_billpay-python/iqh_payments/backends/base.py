# -*- coding: utf-8 -*-

"""
Base class for backend implementations of IQHealth Bill Payments.
"""


class BasePaymentBackend(object):

    def __init__(self, **kwargs):
        pass

    def get_guarantor_id(self, org_slug, access_code, last_name, birth_date):
        """
        Gets the id of the guarantor matching the given criteria.

        @param org_slug: Slug for the organization to fetch guarantors for.
        @param access_code: Access code for the guarantor to get. This is the
                            code the organization gave them to login and
                            make payments, e.g. via mail.
        @param last_name: Last name of the guarantor (not necessarily same
                          as the patient, e.g. parent paying for child).
        @param birth_date: Birth date of the guarantor (again, not necessarily
                           same as the patient). Can either be a date,
                           datetime or a String that can be parsed into
                           a date, such as YYYYMMDD, YYYY-MM-DD, etc.

        @return The id of the guarantor matching the specified criteria or None
                if no guarantor id could be found.
        """
        raise NotImplementedError

    def get_accounts(self, org_slug, guarantor_id):
        """
        Gets the guarantor's patient accounts at the given organization.

        @param org_slug: Slug for the organization to fetch accounts for.
        @param guarantor_id: Id of the guarantor to fetch accounts for.

        @return The list of patient account dictionaries for the given
                guarantor. May be empty if given an invalid gaurantor id.

                Each patient account dictionary will have the following
                possible keys:

                "id" - The account id.
                "account_number" - The account number.
                "masked_account_number" - The account number with a portion of
                                          the digits masked.
                "patient_name" - The name of the patient for the account.
                "facility" - The name of the facility for the account.
                "last_payment_amount" - The amount of the last payment on the
                                        account (float). If > 0 it's the
                                        amount the patient last paid, if < 0
                                        then it's the amount the hospital last
                                        credited back to the patient.
                "last_payment_date" - The date of the last payment (datetime).
                "amount_due" - The current amount owed on the account (float).
                               If > 0 it's the amount the patient owes, if
                               negative then they have a balance left over
                               i.e. hospital owes them. If it's 0 then no
                               money is due.
        """
        raise NotImplementedError

    def get_account(self, org_slug, guarantor_id, account_id):
        """
        Gets a specific guarantor patient account at the given organization.

        @param org_slug: Slug for the organization to fetch the account for.
        @param guarantor_id: Id of the guarantor to fetch the account for.
        @param account_id: Id of the account to fetch.

        @return The patient account dictionary for the given guarantor account
                or None if not found.

                The account dictionary will have the following possible keys:

                "id" - The account id.
                "account_number" - The account number.
                "masked_account_number" - The account number with a portion of
                                          the digits masked.
                "patient_name" - The name of the patient for the account.
                "facility" - The name of the facility for the account.
                "last_payment_amount" - The amount of the last payment on the
                                        account.
                "last_payment_date" - The date of the last payment.
                "amount_due" - The current amount owed on the account.
                "payment_receiver_id" - The id of the entity the payment should
                                        be submitted to.
        """
        raise NotImplementedError

    def get_supported_payment_types_and_merchant_id(self, org_slug, payment_receiver_id, guarantor_id, account_id):
        """
        Gets the set of supported credit card types for the given payment
        receiver id and the merchant id

        @param org_slug: Slug for the organization the payment is for.
        @param payment_receiver_id: Id of the entity to get supported payment types for.
        @param guarantor_id: Id of the guarantor responsible for the payment.
        @param account_id: Id of account being paid.

        @return
            A tuple containing both:
                A dictionary containing the supported card types.  May be empty
                if there is a problem retrieving types for the given payment
                receiver id.

                If successful, the following keys will be set in the payment
                types dictionary:

                    "mastercard" - True if the entity supports mastercard,
                                   False otherwise.
                    "visa" - True if the entity supports visa, False otherwise.
                    "american_express" - True if the entity supports american
                                         express, False otherwise.
                    "discover" - True if the entity supports discover cards,
                                 False otherwise.
            and
                The merchant id for the entity
        """
        raise NotImplementedError

    def get_merchant(self, org_slug, payment_receiver_id, guarantor_id, account_id):
        """
        Gets the set of supported credit card types for the given payment receiver id and
        the manifest and device id to initiate a token call for TSEP workflow.

        @param org_slug: Slug for the organization the payment is for.
        @param payment_receiver_id: Id of the entity to get supported payment types for.
        @param guarantor_id: Id of the guarantor responsible for the payment.
        @param account_id: Id of account being paid.

        @return
            A tuple containing:
                A dictionary containing the supported card types.  May be empty
                if there is a problem retrieving types for the given payment
                receiver id.

                If successful, the following keys will be set in the payment
                types dictionary:

                    "mastercard" - True if the entity supports mastercard,
                                   False otherwise.
                    "visa" - True if the entity supports visa, False otherwise.
                    "american_express" - True if the entity supports american
                                         express, False otherwise.
                    "discover" - True if the entity supports discover cards,
                                 False otherwise.

                The manifest and device id.
        """
        raise NotImplementedError

    def create_payment(self, base_service_url, oauth_client, org_slug, guarantor_id, account_id, amount, payer_name):
        """
        Creates a payment to notify millennium that the application is about to make a payment.

        @param base_service_url: The base service url for patient accounting services
        @param oauth_client: A SimpleOAuthClient
        @param org_slug: Slug for the organization the payment is for.
        @param guarantor_id: Id of the guarantor responsible for the payment.
        @param account_id: Id of account being paid.
        @param amount: The amount of payment to submit. Should be a float
                       or Decimal.
        @param payer_name: Name of the payer (not necessarily the patient).

        @return A payment_id.
        """
        raise NotImplementedError

    def charge_by_token(self, org_slug, guarantor_id, account_id, payment_receiver_id, amount, payer_name,
                        street_address, city, state, postal_code, interchange_id, card_number, card_type,
                        expiration_date, merchant_id, token_reference_id):
        """
        Charges the token and updates the payment status in millennium.

        @param org_slug: Slug for the organization the payment is for.
        @param guarantor_id: Id of the guarantor responsible for the payment.
        @param account_id: Id of account being paid.
        @param payment_receiver_id: Id of the entity to submit the payment to.
        @param amount: The amount of payment to submit. Should be a float
                       or Decimal.
        @param payer_name: Name of the payer (not necessarily the patient).
        @param street_address: The billing street address of the card.
        @param city: The billing city of the card.
        @param state: The two letter state code of billing address for the card
        @param postal_code: The postal code of the billing address for the card
        @param interchange_id: The token used to submit the payment
        @param card_number: The masked number of card used for the transaction
        @param card_type: The type of card used for the transaction
        @param expiration_date: The expiration date of the card used for the transaction in form MM/YYYY
        @param merchant_id: The indentifier of the merchant
        @param token_reference_id: The billpay identifier that is tied to EDI's
                interchange_id.

        @return A 2-tuple containing the following elements:
                status - one of: 'success', 'failure' or 'timeout'
                details - A dictionary containing different keys based upon the
                          status. Possible keys are:
                          "payment_id": The id of the payment, only populated
                                        if the status is success or timeout.
                          "error_code": The error code string, only populated
                                        if the status is failure.

        The following steps are taken to charge a token successfully:
         - Create a payment to notify millennium that billpay is about to make a payment
         - Charge the amount
         - If the charge timed out, return a timeout status and DO NOT update payment status in millennium.
           The views should handle the timeout workflow.
         - If the charge did not timeout, update the payment status in millennium.
        """
        raise NotImplementedError

    def check_payment_status(self, org_slug, guarantor_id, account_id,
                             payment_id, payment_receiver_id, card_type):
        """
        Checks on a payment to see if the processing has been completed.

        @param org_slug: Slug for the organization the payment is for.
        @param guarantor_id: Id of the guarantor responsible for the payment.
        @param account_id: Id of account being paid.
        @param payment_id: Id of the payment to check.
        @param payment_receiver_id: Id of the entity the payment was submitted to.
        @param card_type: The type of card used for the transaction

        @return see submit_credit_card_payment above.
        """
        raise NotImplementedError

    def get_payment(self, org_slug, guarantor_id, account_id, payment_id):
        """
        Gets a payment at the given organization.

        @param org_slug: Slug for the organization the payment was for.
        @param guarantor_id: Id of the guarantor responsible for the payment.
        @param account_id: Id of account being paid.
        @param payment_id: Id of the payment to retrieve.

        @return A dictionary containing the following keys:
                "receipt_number" - An identifier for the receipt of the payment.
                "amount" - The amount of the payment (float).
                "payment_date" - The date the payment was made (datetime).
                "account_number" - The account number the payment was credited to.
                "masked_account_number" - The account number with a portion of
                                          the digits masked.
                "patient_name" - The name of the patient on the account that was paid.
                "payer_name" - The name of the person that made the payment.
                "payee_name" - The name of the entity the payment was sent to.
                "payee_address_line_1" - Line 1 of the street address of the entity
                                         the payment was sent to.
                "payee_address_line_2" - Line 2 of the street address of the entity
                                         the payment was sent to.
                "payee_city" - The city of the entity the payment was sent to.
                "payee_state" - The state of the entity the payment was sent to.
                "payee_postal_code" - The postal code of the entity the payment was sent to.
                "payee_phone" - The phone number of the entity the payment was sent to.
                "merchant_id" - the id of the entity the payment was sent to.
                "card_number" - the masked number of the card used to make the payment.
                "expiration_date" - the expiration date of the card used to make the payment.
        """
        raise NotImplementedError
