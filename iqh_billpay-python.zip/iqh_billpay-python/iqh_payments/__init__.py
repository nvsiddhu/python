# -*- coding: utf-8 -*-

"""
Overview
========

This package provides backends for IQHealth Bill Payments.

Configuration Settings
======================

IQH_PAYMENTS_BACKEND
    Specifies the active backend for `payments`. The default is
    `iqh_payments.backends.hnam_rest_payments`.

Please read the documentation for the selected backend for information on any
backend-specific configuration.

Example usage:

from iqh_payments import payments

"""

from axiom_django.backends import get_backend

payments = get_backend('IQH_PAYMENTS_BACKEND',
                       'iqh_payments.backends.hnam_rest_payments',
                       'PaymentBackend')
