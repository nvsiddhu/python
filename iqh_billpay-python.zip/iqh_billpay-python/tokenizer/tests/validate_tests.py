# -*- coding: utf-8 -*-

from django.test import TestCase
from mock import patch
from tests.utils import BillpayRequestFactory

from tokenizer.exceptions import (EDISystemException,
                                  MissingInfoException,
                                  GenericTokenException,
                                  TSEPSystemException)
from tokenizer.validate import is_get_token_response_valid


@patch('tokenizer.validate.logger')
class TestIsGetTokenResponseValid(TestCase):

    def test_no_error_code_and_no_token(self, logger):
        """
        is_get_token_response_valid should log an error and raise an EDISystemException
        when the post data does not have any errors or interchange_id.
        This normally means the request unexpectedly failed on the client's end.
        """
        request = BillpayRequestFactory().post('/', {})
        self.assertRaises(EDISystemException, is_get_token_response_valid, request)
        self.assertTrue(logger.error.called)

    def test_error_code(self, logger):
        """
        is_get_token_response_valid should log an error and raise an Exception
        when the post data has an error_code populated by the CORS request.
        """
        request = BillpayRequestFactory().post('/', {'error_code': 'S2', 'http_status_code': '200'})
        self.assertRaises(GenericTokenException, is_get_token_response_valid, request)
        self.assertTrue(logger.error.called)

    def test_unknown_error(self, logger):
        """
        is_get_token_response_valid should log an error and raise an EDISystemException
        when the post data has an error_message of 'unknown_error'.
        """
        request = BillpayRequestFactory().post('/', {'error_message': 'unknown_error'})
        self.assertRaises(EDISystemException, is_get_token_response_valid, request)
        self.assertTrue(logger.error.called)

    def test_cancelled_error_message(self, logger):
        """
        is_get_token_response_valid should log an error and raise an EDISystemException
        when the post data has an error_message of 'cancelled'.
        """
        request = BillpayRequestFactory().post('/', {'error_message': 'cancelled'})
        self.assertRaises(EDISystemException, is_get_token_response_valid, request)
        self.assertTrue(logger.error.called)

    def test_error_thrown_by_javascript(self, logger):
        """
        is_get_token_response_valid should log an error and raise an EDISystemException
        when the post data has an error_message other than 'unknown_error'
        but no status code.
        """
        request = BillpayRequestFactory().post('/', {'error_message': 'Access is Denied'})
        self.assertRaises(EDISystemException, is_get_token_response_valid, request)
        self.assertTrue(logger.error.called)

    def test_unexpected_success_response_structure(self, logger):
        """
        is_get_token_response_valid should log an error and raise an EDISystemException
        when the post data does not have an error but we're missing data
        that should be present for a successful response.
        """
        request = BillpayRequestFactory().post('/',
                {'interchange_id': '12345', 'card_type': 'V'})  # missing masked card number
        self.assertRaises(EDISystemException, is_get_token_response_valid, request)
        self.assertTrue(logger.error.called)

    def test_success(self, logger):
        """
        is_get_token_response_valid should return True when all the information
        that our application deems the response to be valid is in the post data.
        """
        request = BillpayRequestFactory().post('/',
                {'interchange_id': '12345', 'card_type': 'V', 'masked_card_number': '************1234'})
        is_valid = is_get_token_response_valid(request)

        self.assertTrue(is_valid)
        self.assertFalse(logger.error.called)

    def test_missing_required_sensitive_information(self, logger):
        """
        is_get_token_response_valid should return False when we're missing required
        sensitive information. The logger should not be called.
        """
        request = BillpayRequestFactory().post('/', {'error_message': 'sensitive_info_missing'})
        self.assertRaises(MissingInfoException, is_get_token_response_valid, request)
        self.assertFalse(logger.error.called)

    def test_tsep_errors(self, logger):
        """
        is_get_token_response_valid should throw an Exception when tsep errors are present
        The logger should be called with the tsep error code and message.
        """
        request = BillpayRequestFactory().post('/', {'tsep_error_code': 'D100', 'tsep_error_message': 'Invalid Card'})
        self.assertRaises(GenericTokenException, is_get_token_response_valid, request)
        self.assertTrue(logger.error.called)

    def test_tsep_system_errors(self, logger):
        """
        is_get_token_response_valid should throw a TSEPSystemException when tsep system error is present
        The logger should be called with the tsep error code and message.
        """
        request = BillpayRequestFactory().post('/', {'tsep_error_code': 'TSEPERR911', 'tsep_error_message': 'Invalid Card'})
        self.assertRaises(TSEPSystemException, is_get_token_response_valid, request)
        self.assertTrue(logger.error.called)
