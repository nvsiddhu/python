/* 
 * Dropdown
 * Copyright(c) 2011- Cerner Corporation
 * 
 * dropdown.js v1.0
 */


$(function(){
	function showDropdown(e) {
		e.preventDefault();
		e.stopPropagation();
		hideDropdowns();
		$(this).addClass('active');
		$(this).next().show();
	}
	
	function hideDropdowns() {
		$('.dropdown').children('a').removeClass('active').next().hide();
	}
	
	$('body').bind('click', hideDropdowns);
	$('body').delegate('.dropdown-switch', 'click', showDropdown);
});