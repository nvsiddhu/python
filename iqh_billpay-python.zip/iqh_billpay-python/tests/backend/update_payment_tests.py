# -*- coding: utf-8 -*-

import datetime
import json
from django.test import TestCase

from axiom_django.backends import get_backend
from mock import patch, MagicMock
import requests

from client_utils.oauth_util import SimpleOAuthClient


payments = get_backend('',
                       'iqh_payments.backends.hnam_rest_payments',
                       'PaymentBackend')


class TestUpdatePayment(TestCase):

    @patch('iqh_payments.backends.hnam_rest_payments.logger')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.put')
    def test_update_payment_exception(self, MockPut, logger):
        """
        _update_payment should log an error and SHOULD NOT raise
        an exception when the request to update the payment raised
        an exception. The client would have to manually reconcile the
        payment status in millennium.
        """
        MockPut.side_effect = requests.exceptions.Timeout
        try:
            self._update_payment()
        except:
            self.fail("_update_payment() raised an Exception unexpectedly!")

        self.assertTrue(logger.exception.called)

    @patch('iqh_payments.backends.hnam_rest_payments.logger')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.put')
    def test_update_payment_failure(self, MockPut, logger):
        """
        _update_payment should log an error and SHOULD NOT raise
        an exception when the request to update the payment returns
        a status code of 4XX or 5XX. The client would have to manually
        reconcile the payments status in millennium.
        """
        self.mock_response = MagicMock()
        self.mock_response.headers = {'content-length': 4}
        self.mock_response.elapsed = datetime.timedelta(0)
        self.mock_response.status_code = 500
        MockPut.return_value = self.mock_response

        try:
            self._update_payment()
        except:
            self.fail("_update_payment() raised an Exception unexpectedly!")

        self.assertTrue(logger.error.called)

    @patch('iqh_payments.backends.hnam_rest_payments.logger')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.put')
    def test_update_payment_success(self, MockPut, logger):
        """
        _update_payment should not log an error when the request to
        update the payment is successful.
        """
        self.mock_response = MagicMock()
        self.mock_response.headers = {'content-length': 4}
        self.mock_response.elapsed = datetime.timedelta(0)
        self.mock_response.status_code = 200
        MockPut.return_value = self.mock_response

        self._update_payment()

        self.assertFalse(logger.exception.called)
        self.assertFalse(logger.error.called)

    def _update_payment(self):
        return payments._update_payment(
                'http://devtest.cerner.corp/edi',
                {"amount": 0.49, "paymentReason": "ONLINEBILLPY", "paymentMethod": "CREDIT CARD", "payerName": "John Smith"},
                MagicMock(SimpleOAuthClient),
                'baseline-health',
                'g_1',
                '1234')
