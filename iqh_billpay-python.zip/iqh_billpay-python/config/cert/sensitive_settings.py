# -*- coding: utf-8 -*-

# Oracle db for in-house cert deployments of iqh
DATABASES = {
    'default': {
        'ENGINE': 'axiom_oracle',
        'NAME': '(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=cerniqhcertorcl01.northamerica.cerner.net)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=hthlifcert)))',
        'USER': 'Billpay',
        'PASSWORD': 'bpcert',
    }
}

MEMCACHED_DATA_ENC_KEY = '89To6PoJVU1gmtow'
IQH_SECRET = '5e4ffb2dff1643238975f808994520e7'

EDI_API_USER = 'IQHEALTH'
EDI_API_PASSWORD = '2018Cerner'

CC_OAUTH_CONSUMER_SECRET_IQH = '_ALSsaqoKlg0oMMbcQOzRr22TIJNhtCc'

SECRET_KEY = "t8h7i%(lp&q9434=el@7epiup$ambyc-8^s!vta)@c22#wr+dt"
SESSION_SALT = '8b1cb878-610c-11e3-bb70-14109fdf6c31'

# iqh_cert user for S3 buckets
AWS_ACCESS_KEY_ID = 'AKIAI3A2ZGX6CGAH5OAA'
AWS_SECRET_ACCESS_KEY = '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'

# ReCaptcha v2 settings
G_RECAPTCHA_SITE_KEY = '6LfqDE4UAAAAAFiMix1lF4rF2E4Q_1drPZcWL_KH'
G_RECAPTCHA_SECRET_KEY = '6LfqDE4UAAAAAJLNGOuWlxvSWOZZ3GGCfRycs2Ou'
