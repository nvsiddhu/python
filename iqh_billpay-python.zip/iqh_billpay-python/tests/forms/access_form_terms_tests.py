# -*- coding: utf-8 -*-

from django.test import TestCase

from forms import AccessFormTerms


class AccessFormTermsTests(TestCase):
    """
    Ensures terms form is functioning correctly.
    """
    whitebox = True

    def test_required_fields(self):
        """
        If the user indicates to continue without entering data in all search
        criteria fields, the system shall display a message, such as:
        "All fields are required."
        """
        post_data = {}
        form = AccessFormTerms(post_data)
        form.full_clean()
        assert 'quickpay_terms' in form._errors

        post_data = {'quickpay_terms': False}
        form = AccessFormTerms(post_data)
        form.full_clean()
        assert 'quickpay_terms' in form._errors

        post_data = {'quickpay_terms': True}
        form = AccessFormTerms(post_data)
        form.full_clean()
        assert 'quickpay_terms' not in form._errors
