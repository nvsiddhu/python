# -*- coding: utf-8 -*-

from django.test import TestCase
from django.test.client import RequestFactory

from forms import PaymentForm
import datetime


class PaymentFormTests(TestCase):
    """
    Ensures payment form is functioning correctly.
    """

    def test_sensitive_inputs(self):
        """
        Sensitive inputs such as card number and security number should not render
        the name attribute on the template.
        """
        form = PaymentForm(payment_types={'visa': True}, request={},
                           org_tz='America/Chicago')

        html_output = form.as_p()

        # ensure there is no name attribute for card_number and security number
        self.assertEqual(html_output.count('name="card_number"'), 0,
                         'The name attribute for card number should not be present on the form.')
        self.assertEqual(html_output.count('name="security_number"'), 0,
                         'The name attribute for security number should not be present on the form.')

        # expiration date field should have a name attribute
        self.assertEqual(html_output.count('name="expiration_date_month"'), 1,
                         'The name attribute for expiration_date_month should be present on the form.')
        self.assertEqual(html_output.count('name="expiration_date_year"'), 1,
                         'The name attribute for expiration_date_year should be present on the form.')

    def test_supported_cc_types(self):
        """
        The payment form should contain the correct supported credit card types
        """
        self._verify_cc_types({'visa': True, 'discover': True,
                               'mastercard': True, 'american_express': True})

        self._verify_cc_types({'visa': False, 'discover': False,
                               'mastercard': False, 'american_express': False})

        self._verify_cc_types({'visa': True, 'discover': False,
                               'mastercard': False, 'american_express': True})

        self._verify_cc_types({'visa': True, 'discover': False})

    def _verify_cc_types(self, supported_types):
        form = PaymentForm(payment_types=supported_types, request={},
                           org_tz='America/Chicago')
        for cc_type, is_supported in supported_types.iteritems():
            assert cc_type in form.supported_cc_types if is_supported else cc_type not in form.supported_cc_types

    def test_payment_amount(self):
        """
        The payment amount should be less than or equal to the amount due.
        """
        post_data = {'payment_amount': '.99'}
        request = RequestFactory().post('', post_data)
        request.acct = {'amount_due': 1.0}
        form = PaymentForm(post_data, payment_types={'visa': True},
                           request=request, org_tz='America/Chicago')
        form.full_clean()
        assert 'payment_amount' not in form._errors

        post_data = {'payment_amount': '1.0'}
        request = RequestFactory().post('', post_data)
        request.acct = {'amount_due': 1.0}
        form = PaymentForm(post_data, payment_types={'visa': True}, request=request, org_tz='America/Chicago')
        form.full_clean()
        assert 'payment_amount' not in form._errors

        #Currency symbols and thousands separators should be ignored
        post_data = {'payment_amount': '$1,000.0'}
        request = RequestFactory().post('', post_data)
        request.acct = {'amount_due': 1000.0}
        form = PaymentForm(post_data, payment_types={'visa': True},
                           request=request, org_tz='America/Chicago')
        form.full_clean()
        assert 'payment_amount' not in form._errors

        post_data = {'payment_amount': '1.01'}
        request = RequestFactory().post('', post_data)
        request.acct = {'amount_due': 1.0}
        form = PaymentForm(post_data, payment_types={'visa': True},
                           request=request, org_tz='America/Chicago')
        form.full_clean()
        assert form._errors['payment_amount']is not None

        #The payment amount can contain no more than 2 decimal places
        post_data = {'payment_amount': '.999'}
        request = RequestFactory().post('', post_data)
        request.acct = {'amount_due': 1.0}
        form = PaymentForm(post_data, payment_types={'visa': True},
                           request=request, org_tz='America/Chicago')
        form.full_clean()
        assert form._errors['payment_amount'] is not None

        #The payment amount must be a number
        post_data = {'payment_amount': 'abcd'}
        request = RequestFactory().post('', post_data)
        request.acct = {'amount_due': 1.0}
        form = PaymentForm(post_data, payment_types={'visa': True},
                           request=request, org_tz='America/Chicago')
        form.full_clean()
        assert form._errors['payment_amount'] is not None

    def test_required_fields(self):
        """
        The payment form shall require the user to enter the following:
            Payment Amount,Expiration Date, Name on Card, Billing Address,
            City, State, and Zip Code.
        """
        post_data = {}
        request = RequestFactory().post('', post_data)
        request.acct = {'amount_due': 1}
        form = PaymentForm(post_data, payment_types={'visa': True},
                           request=request, org_tz='America/Chicago')
        form.full_clean()
        assert 'payment_amount' in form._errors
        assert 'card_number' not in form._errors
        assert 'security_number' not in form._errors
        assert 'expiration_date' in form._errors
        assert 'payer_name' in form._errors
        assert 'address' in form._errors
        assert 'city' in form._errors
        assert 'state' in form._errors
        assert 'postal_code' in form._errors
        assert 'token' not in form._errors
        assert 'card_type' not in form._errors
        assert 'masked_card' not in form.errors
        assert 'errormsg' not in form.errors

        post_data = {'payment_amount': '', 'expiration_date': '',
                     'payer_name': '', 'address': '', 'city': '', 'state': '',
                     'postal_code': '', 'token': '', 'card_type': '',
                     'masked_card': '', 'errormsg': ''}
        request = RequestFactory().post('', post_data)
        request.acct = {'amount_due': 1}
        form = PaymentForm(post_data, payment_types={'visa': True},
                           request=request, org_tz='America/Chicago')
        form.full_clean()
        assert 'payment_amount' in form._errors
        assert 'card_number' not in form._errors
        assert 'security_number' not in form._errors
        assert 'expiration_date' in form._errors
        assert 'payer_name' in form._errors
        assert 'address' in form._errors
        assert 'city' in form._errors
        assert 'state' in form._errors
        assert 'postal_code' in form._errors
        assert 'token' not in form._errors
        assert 'card_type' not in form._errors
        assert 'masked_card' not in form.errors
        assert 'errormsg' not in form.errors

        post_data = {'payment_amount': '1', 'expiration_date': '2099-1-1',
                     'payer_name': 'abcd', 'address': '123', 'city': 'abcd',
                     'state': 'MO', 'postal_code': '12345', 'token': '12345', 'card_type': 'M',
                     'masked_card': '1234', 'errormsg': 'Invalid Card'}
        request = RequestFactory().post('', post_data)
        request.acct = {'amount_due': 1.0}
        form = PaymentForm(post_data, payment_types={'visa': True},
                           request=request, org_tz='America/Chicago')
        form.full_clean()
        assert 'payment_amount' not in form._errors
        assert 'card_number' not in form._errors
        assert 'security_number' not in form._errors
        assert 'expiration_date' not in form._errors
        assert 'payer_name' not in form._errors
        assert 'address' not in form._errors
        assert 'city' not in form._errors
        assert 'state' not in form._errors
        assert 'postal_code' not in form._errors
        assert 'token' not in form._errors
        assert 'card_type' not in form._errors
        assert 'masked_card' not in form.errors
        assert 'errormsg' not in form.errors

    def test_state_choices(self):
        """
        The State field shall be pre-populated with the state options.
        """
        form = PaymentForm(payment_types={'visa': True}, request={},
                           org_tz='America/Chicago')
        assert len(form.fields['state'].widget.choices) >= 50

    def test_expiration_date(self):
        """
        Expiration date must not be in the past.
        """
        now = datetime.date.today()
        last_month = now - datetime.timedelta(days=31)
        post_data = {'expiration_date': last_month.strftime('%Y-%m-1')}
        request = RequestFactory().post('', post_data)
        form = PaymentForm(post_data, payment_types={'visa': True},
                           request=request, org_tz='America/Chicago')
        form.full_clean()
        assert 'expiration_date' in form._errors
