# -*- coding: utf-8 -*-

import hashlib
import pickle

from django.conf import settings
from django.contrib.sessions.backends.cache import KEY_PREFIX
from django.contrib.sessions.backends.cache import SessionStore as CachedStore
from django.contrib.sessions.backends.base import CreateError
from django.core.signing import b64_encode
from django.utils import crypto

from iqh_backend_utils.encrypt_util import aes_encrypt, aes_decrypt

BILLPAY_DATA_SESSION_KEY = '_bp_session_data'


class SessionStore(CachedStore):
    """
    Implements cached session store but hashes the session id and encrypts the session data
    before storing it in cache.
    """

    @property
    def cache_key(self):
        """
        The key of the user's session in cache. The cache key is
        KEY_PREFIX + a hased value of session_key.
        """
        session_key = self._get_or_create_session_key()
        return self._get_cache_key(session_key)

    def save(self, must_create=False):
        # This function is very similar to django's cache backends.
        # The only difference is encrypting the session data before sending it to memcache.
        # https://github.com/django/django/blob/1.4.11/django/contrib/sessions/backends/cache.py
        if must_create:
            func = self._cache.add
        else:
            func = self._cache.set

        session_data = self._get_session(no_load=must_create)
        encrypted_session_data = aes_encrypt(pickle.dumps(session_data), settings.SESSION_DATA_ENC_KEY)

        result = func(self.cache_key,
                      encrypted_session_data,
                      self.get_expiry_age())

        if must_create and not result:
            raise CreateError

    def load(self):
        session_data = super(SessionStore, self).load()

        if not session_data:
            return session_data

        # decrypt the session data from memcache
        session_data = aes_decrypt(session_data, settings.SESSION_DATA_ENC_KEY)
        return pickle.loads(session_data)

    def exists(self, session_key):
        cache_key = self._get_cache_key(session_key)
        return cache_key in self._cache

    def delete(self, session_key=None):
        if session_key is None:
            if self.session_key is None:
                return
            session_key = self.session_key

        cache_key = self._get_cache_key(session_key)
        self._cache.delete(cache_key)

    def cycle_key(self):
        """
        Creates a new session key, whilst retaining the current session data.
        """
        super(SessionStore, self).cycle_key()

        # since we changed keys, we need to update the _session_key
        self._session_cache['_session_key'] = self.session_key

    def _get_cache_key(self, session_key):
        """
        Returns the cache key given the session key. The cache key is hashed value of the session id.
        """
        hashed_session_key = hashlib.sha256(settings.SESSION_SALT + session_key).hexdigest()
        return KEY_PREFIX + hashed_session_key
