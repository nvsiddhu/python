# -*- coding: utf-8 -*-

import iqh_logging
from django.conf import settings
from django.core.urlresolvers import reverse
from django.utils.cache import patch_cache_control
from django.shortcuts import redirect

from iqh_domains import domains

NOCACHE_MIDDLEWARE_IGNORE_PATHS = getattr(settings, 'NOCACHE_MIDDLEWARE_IGNORE_PATHS', [])

logger = iqh_logging.get_logger(__name__)

class IQHRequestDomainMiddleware(object):
    ignored_paths = [
        reverse('health_check')
    ]

    def process_request(self, request):
        if request.path.startswith('/api/theming') or request.path in self.ignored_paths:
            return
        domain_name = _get_domain(request)
        if domain_name:
            request.domain_name = domain_name
            request.domain = domains.get_or_404(domain_name.lower())

domain_ignores = ['m', 't', 's']


def _get_domain(request):
    """
    Gets the 'domain' from the django request, with the port removed. Ignores
    subdomains used for mobile / tablet

    e.g.
    'm.foo.com:8001' -> 'foo.com'
    't.foo.com' -> 'foo.com'
    'foo.com' -> 'foo.com'
    'foo.com:8001' -> 'foo.com'
    'm.y.z.foo.com:8001' -> 'y.z.foo.com'
    """
    host = request.get_host()
    if host:
        # Get rid of port if present
        sans_port = host.partition(':')[0]
        the_dots = sans_port.split('.')
        if the_dots[0] in domain_ignores:
            #return substring after first dot
            return sans_port[sans_port.find('.') + 1:]
        else:
            return sans_port

    return


class XFrameOptionsMiddleware(object):
    """
    Middleware that sets the X-Frame-Options HTTP header to prevent the site
    from loading in a hidden iframe on a malicious site (clickjacking).

    http://en.wikipedia.org/wiki/Clickjacking

    We can get rid of this when upgrading to Django 1.4, as that should include
    similar functionality via::

        http://code.djangoproject.com/ticket/14261

    """
    def process_response(self, request, response):
        options = getattr(settings, 'X_FRAME_OPTIONS', 'DENY')
        response['X-FRAME-OPTIONS'] = options.upper()
        return response


class NoCacheMiddleware(object):
    """
    Middleware to set all view response's cache and expires headers to prevent
    caching of web pages. If Cache-Control and Expires headers are already set, the
    initial directives will be used.

    - Cache-Control: no-cache, no-store, must_revalidate
    - Expires: -1

    """
    def process_response(self, request, response):
        if self.is_path_ignored(request.path):
            return response

        if not response.has_header('Cache-Control'):
            patch_cache_control(response, no_cache=True, no_store=True, must_revalidate=True)

        if not response.has_header('Expires'):
            response['Expires'] = '-1'

        return response

    def is_path_ignored(self, path):
        """
        Check the ignored paths for patient portal (currently same as the axiom_django skippable decorator prefixes).
        """
        for ignore_path in NOCACHE_MIDDLEWARE_IGNORE_PATHS:
            if path.startswith(ignore_path):
                return True

        return False


class ValidateUserSessionMiddleware(object):
    """
    Middleware to ensure the user's session data isn't tampered with.

    Since memcached doesn't require authentication, malicious users can attempt to
    copy session data from one session to another. If this were to occur, then log
    an error, flush the cache, and redirect him/her back to the homepage.
    """

    def process_request(self, request):
        # if session key has not been set to the session data, then set it
        if not request.session.get('_session_key'):
            request.session['_session_key'] = request.session.session_key

        # compare the session key from the user's cookie to the key in the session data
        elif str(request.session.session_key) != str(request.session.get('_session_key')):
            logger.error("User's current session key does not match the key in it's session data. "
                         "This is likely caused by tampering of session data in cache. Will log "
                         "out the user and redirect back to the home page.")

            request.session.flush()
            return redirect(reverse('home'))
