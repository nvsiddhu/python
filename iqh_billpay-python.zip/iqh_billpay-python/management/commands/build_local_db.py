# -*- coding: utf-8 -*-


from django.core import management
from django.core.management import base


class Command(base.NoArgsCommand):
    help = """Builds all of the commonly needed data for local development and
    billpay runtime."""

    def handle_noargs(self, **options):
        management.call_command('syncdb', verbosity=0, interactive=False)
        management.call_command('init_local_data')
