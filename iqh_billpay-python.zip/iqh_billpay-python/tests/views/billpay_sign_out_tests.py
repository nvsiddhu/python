# -*- coding: utf-8 -*-

from mock import patch
from urlparse import urlparse

from django.core.urlresolvers import reverse

from tests.views.base_billpay_test import BaseBillPayTest


class BillPaySignOutTest(BaseBillPayTest):
    """ Tests Bill Pay sign out link """
    functional = True

    def setUp(self):
        super(BillPaySignOutTest, self).setUp()

        self.login_user('g_1')

    @patch('views.guarantor_logout')
    def test_sign_out_page(self, mock_logout):
        """
        The user will be directed to the unauthenticated home page with the
        session flushed when the user is taken to the logout page.
        """
        response = self.client.get(reverse('logout'))
        self.assertEqual(response.status_code, 302)

        self.assertTrue(mock_logout.called)

    def test_sign_out_view_accounts_page(self):
        """
        Signing out shall return the user to the billpay homepage and clear the
        session so that you can't go back and view sensitive information
        """
        #with valid session info go to the view accounts page
        response = self.client.get(reverse('view_accounts'))
        self.assertTemplateUsed(response, 'account.html')
        self.assertEqual(response.status_code, 200)

        #sign out
        response = self.client.get(reverse('logout'))
        self.assertEquals(urlparse(response['location'])[2], reverse('home'))
        self.assertEqual(response.status_code, 302)

        #try to go back to the view accounts page and verify
        #that it is unsuccessful
        response = self.client.get(reverse('view_accounts'))
        self.assertTemplateNotUsed(response, 'account.html')
        self.assertEqual(response.status_code, 302)

    def test_sign_out_account_payment_page(self):
        """
        Signing out shall return the user to the billpay homepage and clear the
        session so that you can't go back and view sensitive information
        """
        #with valid session info go to the make payment page
        response = self.client.get(reverse('account_payment', args=['1234']))
        self.assertTemplateUsed(response, 'account_payment.html')
        self.assertEqual(response.status_code, 200)

        #sign out
        response = self.client.get(reverse('logout'))
        self.assertEquals(urlparse(response['location'])[2], reverse('home'))
        self.assertEqual(response.status_code, 302)

        #try to go back to the make payment page and verify
        #that it is unsuccessful
        response = self.client.get(reverse('account_payment', args=['1234']))
        self.assertTemplateNotUsed(response, 'account_payment.html')
        self.assertEqual(response.status_code, 302)

    def test_sign_out_confirm_payment_page(self):
        """
        Signing out shall return the user to the billpay homepage and clear the
        session so that you can't go back and view sensitive information
        """
        self.set_payment_data_in_session()
        self.set_token_reference_id_session()

        #with valid session info go to the confirm page
        response = self.client.get(reverse('confirm_payment', args=['1234']))
        self.assertTemplateUsed(response, 'confirm_payment.html')
        self.assertEqual(response.status_code, 200)

        #sign out
        response = self.client.get(reverse('logout'))
        self.assertEquals(urlparse(response['location'])[2], reverse('home'))
        self.assertEqual(response.status_code, 302)

        #try to go back to the confirm page and verify
        #that it is unsuccessful
        response = self.client.get(reverse('confirm_payment', args=['1234']))
        self.assertTemplateNotUsed(response, 'confirm_payment.html')
        self.assertEqual(response.status_code, 302)

    def test_sign_out_receipt_page(self):
        """
        Signing out shall return the user to the billpay homepage and clear the
        session so that you can't go back and view sensitive information
        """
        self.set_payment_data_in_session()
        self.set_token_reference_id_session()

        #with valid session info go to the receipt page
        response = self.client.get(reverse('payment', args=['44444', '5678']))
        self.assertTemplateUsed(response, 'payment_receipt.html')
        self.assertEqual(response.status_code, 200)

        #sign out
        response = self.client.get(reverse('logout'))
        self.assertEquals(urlparse(response['location'])[2], reverse('home'))
        self.assertEqual(response.status_code, 302)

        #try to go back to the receipt page and verify
        #that it is unsuccessful
        response = self.client.get(reverse('payment', args=['44444', '5678']))
        self.assertTemplateNotUsed(response, 'payment_receipt.html')
        self.assertEqual(response.status_code, 302)

    @patch('views.guarantor_logout')
    def test_sign_out_from_timeout(self, mock_logout):
        """
        If the user's session is timed out, the user will be directed to the
        unauthenticated home page with a message explaining that the session has timed
        out.
        """
        response = self.client.get(reverse('logout') + '?timeout=t')
        self.assertEqual(response.status_code, 302)

        response = self.client.get(reverse('home'))
        self.assertContains(response, 'alert-message')
