# -*- coding: utf-8 -*-

from django.test import TestCase

from forms import ReceiptForm


class ReceiptFormTests(TestCase):
    """
    Ensures the receipt form is functioning correctly.
    """
    whitebox = True

    def  test_email_address(self):
        """
        An error message shall display if the entered email address is not a
        valid email format.
        """
        form = ReceiptForm({'email': '123 asdf'})
        form.full_clean()
        assert form._errors['email'] != None

        form = ReceiptForm({'email': 'one@1231234 askldjf'})
        form.full_clean()
        assert form._errors['email'] != None

        form = ReceiptForm({'email': '@gmail.com'})
        form.full_clean()
        assert form._errors['email'] != None

        form = ReceiptForm({'email': 'test@'})
        form.full_clean()
        assert form._errors['email'] != None

        form = ReceiptForm({'email': 'test@yopmail.com'})
        form.full_clean()
        assert 'email' not in form._errors

    def test_required_fields(self):
        """
        The receipt form shall require the user to enter an email address.
        """
        form = ReceiptForm({})
        form.full_clean()
        assert form._errors['email'] != None

        form = ReceiptForm({'email': ''})
        form.full_clean()
        assert form._errors['email'] != None

        form = ReceiptForm({'email': 'test@yopmail.com'})
        form.full_clean()
        assert 'email' not in form._errors
