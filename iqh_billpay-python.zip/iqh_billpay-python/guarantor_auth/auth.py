# -*- coding: utf-8 -*-

from django.conf import settings
from django.middleware.csrf import _get_new_csrf_key

from decorators import GUARANTOR_SESSION_KEY
from iqh_payments import payments


def guarantor_authenticate(org_slug, access_code, last_name, date_of_birth):
    """
    Authenticates the user given org_slug, access code, last name, and date of birth.
    If the function returns a guarator_id, the given data is valid.
    If the data is invalid, guarantor_authenticate() returns None.
    """

    return payments.get_guarantor_id(org_slug, access_code, last_name, date_of_birth)


def guarantor_login(request, guarantor_id):
    """
    Logs in the user. Saves the guarantor_id in the session that uniquely
    identifies the user. Note that any data set during the anonymous session is retained
    in the session after a user logs in.
    """

    if request.session.get(GUARANTOR_SESSION_KEY):

        if request.session.get(GUARANTOR_SESSION_KEY) != guarantor_id:
            # To avoid reusing another user's session, create a new, empty
            # session if the existing session corresponds to a different user.
            request.session.flush()
    else:
        # creates a new session but retains the current session data
        request.session.cycle_key()

    request.session[GUARANTOR_SESSION_KEY] = guarantor_id
    _rotate_token(request)


def guarantor_logout(request):
    """
    Flushes the user's session data.
    """
    request.session.flush()


def _rotate_token(request):
    """
    Changes the CSRF token in use for a request - should be done on login
    for security purposes.

    TODO: Remove this function and use Django's rotate_token when we upgrade django to 1.5.5 or higher.
    """
    request.META.update({
        "CSRF_COOKIE_USED": True,
        "CSRF_COOKIE": _get_new_csrf_key(),
    })
