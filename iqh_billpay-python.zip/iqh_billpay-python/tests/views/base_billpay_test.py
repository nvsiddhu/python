# -*- coding: utf-8 -*-

from django.test import TestCase
from django.conf import settings
from django.utils.importlib import import_module

from decorators import GUARANTOR_SESSION_KEY

from replicators import build_org, build_config, build_domain
from views import PAYMENT_DATA_SESSION_KEY, TOKEN_REFERENCE_ID_SESSION_KEY
import re

from mock import MagicMock, patch

class BaseBillPayTest(TestCase):
    """ Base Bill Pay TestCase for tests that use Django's Client"""

    def setUp(self):
        self.domain = build_domain()
        self.org = build_org()
        build_config()
        self._create_session()

    def login_user(self, guarantor_id=None):
        if not guarantor_id:
            guarantor_id = 'g_1'

        self.session[GUARANTOR_SESSION_KEY] = guarantor_id
        self.session.save()

    def set_payment_data_in_session(self, payment_data=None, set_data=True):
        if not set_data:
            return  # Passive change to allow setting no payment_data.
        if not payment_data:
            payment_data = {
                'payment_amount': 999, 'masked_card_number': '************1111', 'card_type': 'Visa',
                'expiration_date': '2099-1-1', 'payer_name': 'Jane Smith', 'address': '200 1st St.',
                'city': 'Chicago', 'state': 'IL', 'postal_code': '99999'}

        self.session[PAYMENT_DATA_SESSION_KEY] = unicode(payment_data)
        self.session.save()

    def set_token_reference_id_session(self, token_reference_id=None):
        """
        Sets payment data (also known as form data) in the request's session.
        """
        if not token_reference_id:
            token_reference_id = '999'

        self.session[TOKEN_REFERENCE_ID_SESSION_KEY] = token_reference_id
        self.session.save()

    def _create_session(self):
        """
        Django testing doesn't create a session for anonymous users.
        Workaround until https://code.djangoproject.com/ticket/11475 is fixed.
        """
        engine = import_module(settings.SESSION_ENGINE)
        session = engine.SessionStore()
        session.save()
        self.session = session

        # Set the cookie to represent the session.
        session_cookie = settings.SESSION_COOKIE_NAME
        self.client.cookies[session_cookie] = session.session_key
        cookie_data = {
            'max-age': None,
            'path': '/',
            'domain': settings.SESSION_COOKIE_DOMAIN,
            'secure': settings.SESSION_COOKIE_SECURE or None,
            'expires': None,
        }
        self.client.cookies[session_cookie].update(cookie_data)

    def _assertContainsRegex(self, regex, response):
        self.assertTrue(re.search(regex, response.content), u"Couldn't find '{0}' in response".format(regex))


class GuarantorLoggedinTestCase(BaseBillPayTest):

    def setUp(self):
        super(GuarantorLoggedinTestCase, self).setUp()
        self.login_user()


class BaseBillPayCustomDomainTest(BaseBillPayTest):
    """ Base Bill Pay test with all available domain options customized. """

    def setUp(self):
        self.org = build_org()
        build_config()
        self.domain = build_domain('baseline-south', 'test.com')
        self._create_session()

        patcher = patch('views.BillpayTemplateConfig.objects.get')
        self.template_model_objects_get = patcher.start()
        self.addCleanup(patcher.stop)

        quickpay_template_object = MagicMock()
        quickpay_template_object.template_html_content = 'quickpay terms content'
        self.template_model_objects_get.return_value = quickpay_template_object
