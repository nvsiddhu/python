# -*- coding: utf-8 -*-

import os.path
import sys

DEBUG = True
DEPLOYMENT_MODE = 'local'

# Disable Requests verififcation of SSL certs in local/dev/cert, Enable in staging/prod
VERIFY_SSL = False

os.environ['REQUESTS_CA_BUNDLE'] = ''

STATICFILES_STORAGE = 'pipeline.storage.PipelineStorage'
if 'collectstatic' in sys.argv:
    STATICFILES_STORAGE = 'pipeline.storage.PipelineCachedStorage'

EMAIL_HOST = 'smtprr.cerner.com'

here = lambda *x: os.path.join(os.path.abspath(os.path.dirname(__file__)), *x)

# By default when running locally we hit sqlite and the mock backend so we can
# run without having any kind of internet + VPN + DB + HNAM service connection.
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': here('sqlite3/iqh_bp.db'),
    }
}

IQH_PAYMENTS_BACKEND = 'iqh_payments.backends.mock_payments'

# You can comment this stuff back in (or add to my_settings.py) to switch
# to using the real backend and/or the real DB...
# IQH_PAYMENTS_BACKEND = 'iqh_payments.backends.hnam_rest_payments'
#DATABASE_CONNECTION_POOL_SIZE = 5
#DATABASE_CONNECTION_MAX_OVERFLOW = 10
#DATABASE_CONNECTION_TIMEOUT = 30
#DATABASES = {
#    'default': {
#        'ENGINE': 'oracle_axiom',
#        'NAME': '(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=vmhealthedb02.northamerica.cerner.net)(PORT=1521)))(LOAD_BALANCE=yes)(CONNECT_DATA=(SERVER=DEDICATED)(SID=hetst1)))',
#        'USER': 'iqh',
#        'PASSWORD': 'iqh',
#    }
#}

#force http instead of https for local
SESSION_COOKIE_SECURE = False
CSRF_COOKIE_SECURE = False

SECRET_KEY = 'd5hmez8!irlx*96edrzf)6m!9aa=lu(4l*&3$%1)l1281z4vo!'
SESSION_SALT = 'c39c0fa1-610c-11e3-881e-14109fdf6c31'

# By default, turn template caching off for local development so you can make
# template changes without having to restart the dev server.
# If you DO want template caching while running locally, simply copy
# TEMPLATE_LOADERS from settings.py to a local_settings.py
TEMPLATE_LOADERS = (
    'django.template.loaders.filesystem.Loader',
    'django.template.loaders.app_directories.Loader'
)

DEBUG_TOOLBAR_PANELS = (
    'debug_toolbar.panels.version.VersionDebugPanel',
    'debug_toolbar.panels.timer.TimerDebugPanel',
    'debug_toolbar.panels.settings_vars.SettingsVarsDebugPanel',
    'debug_toolbar.panels.headers.HeaderDebugPanel',
    'debug_toolbar.panels.request_vars.RequestVarsDebugPanel',
    'debug_toolbar.panels.template.TemplateDebugPanel',
    'debug_toolbar.panels.sql.SQLDebugPanel',
    'debug_toolbar.panels.signals.SignalDebugPanel',
    'debug_toolbar.panels.logger.LoggingPanel',
)
DEBUG_TOOLBAR_CONFIG = {
    'INTERCEPT_REDIRECTS': False,
#    'SHOW_TOOLBAR_CALLBACK': custom_show_toolbar,
#    'EXTRA_SIGNALS': ['myproject.signals.MySignal'],
#    'HIDE_DJANGO_SQL': False,
#    'TAG': 'div',
}

CC_OAUTH_ACCESS_TOKEN_URL = 'https://api.devcernercare.com/oauth/access'
CC_OAUTH_CONSUMER_KEY_IQH = '4f813eda-d402-4db1-b05c-432b78f505e2'
CC_OAUTH_CONSUMER_SECRET_IQH = '_ALSsaqoKlg0oMMbcQOzRr22TIJNhtCc'

GWX_OAUTH_ACCESS_TOKEN_URL = CC_OAUTH_ACCESS_TOKEN_URL
GWX_OAUTH_CONSUMER_KEY_IQH = CC_OAUTH_CONSUMER_KEY_IQH
GWX_OAUTH_CONSUMER_SECRET_IQH = CC_OAUTH_CONSUMER_SECRET_IQH

# ReCaptcha v2 settings -- these keys enforce recaptcha when running locally
G_RECAPTCHA_SITE_KEY = '6LeIxAcTAAAAAJcZVRqyHh71UMIEGNQ_MXjiZKhI'
G_RECAPTCHA_SECRET_KEY = '6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe'

CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'default',
    },
    'moonpie.theming': {
        #don't use LocMemCache as it produces undesirable results when publishing themes
        'BACKEND': 'django.core.cache.backends.dummy.DummyCache',
    },
    'moonpie.theme_publish_status': {
        'BACKEND': 'django.core.cache.backends.filebased.FileBasedCache',
        'LOCATION': '/tmp/cache/',
        'VERSION': '1',
    },
    'axiom_django_filez': {
    'BACKEND': 'django.core.cache.backends.filebased.FileBasedCache',
    'LOCATION': '/tmp/axiom_django_filez',
    'TIMEOUT': 60,
    'OPTIONS': {
            'MAX_ENTRIES': 1000
        }
    },
    'billpay.access.captcha.counter': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'billpay.access.captcha.counter',
    },
    'billpay.payment.captcha.counter': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'billpay.payment.captcha.counter',
    },
    'oauth.access_tokens': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'oauth.access_tokens',
    },
    'iqh.domains': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'iqh.domains',
    },
    'iqh.orgs': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'iqh.orgs',
    },
    'iqh.orgs.slug_to_id': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'iqh.orgs.slug_to_id',
    },
    'iqh.configurations': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'iqh.configurations',
    },
    'iqh.oauth': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'iqh.oauth',
    },
    'iqh.templates': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'iqh.oauth',
    },
    'iqh.payments.facilities': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'iqh.payments.facilities',
    },
    'iqh.payments.submitter_id_to_payment_types': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'iqh.payments.submitter_id_to_payment_types',
    },
    'iqh.payments.account_id_to_facility_id': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'iqh.payments.account_id_to_facility_id',
    },
    'iqh.careaware_service_urls': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'iqh.careaware_service_urls',
    },
    'django_cache_manager.cache_backend': {
        'BACKEND': 'django.core.cache.backends.dummy.DummyCache',
    },
    # Long cache timeout for staticfiles, since this is used heavily by the optimizing storage.
    "staticfiles": {
        "BACKEND": "django.core.cache.backends.locmem.LocMemCache",
        "TIMEOUT": 60 * 60 * 24 * 365,
        "LOCATION": "staticfiles",
    },
}

THEMING_ACCESS_TOKEN = 'LOCAL_ACCESS_TOKEN'

# https://docs.djangoproject.com/en/dev/ref/files/storage/
DEFAULT_FILE_STORAGE = 'django.core.files.storage.FileSystemStorage'

# Absolute path to the directory that holds media.
# Example: "/home/media/media.lawrence.com/"
# Since media_root is no longer being used for our static files,
# we are instead using it for our file storage system
MEDIA_ROOT = '/tmp/axiom_django_filez/'
MEDIA_URL = 'http://localiqhbillpay.com:8019/filez/'

SESSION_DATA_ENC_KEY = 'ZjY2NGVlZDNmZTNh'
MEMCACHED_DATA_ENC_KEY = 'vn3cV8SC5Xp3sR6n'
IQH_SECRET = '5e4ffb2dff1643238975f808994520e7'

EDI_SUBMITTER_LOOKUP_API_URL = 'http://vipercert.edi.cerner.corp/edi/'
EDI_BILLPAY_API_URL = 'https://ipedipcicrt101.northamerica.cerner.net/edi/epayment/'

TSEP_TRANSIT_DOMAIN = 'https://stagegw.transnox.com'

# Need to hit service over http b/c ie 8/9 won't allow cors requests.
# If http protocols aren't the same. Our local server uses http so the service
# must use http.
EDI_TOKEN_REQUEST_API_URL = 'http://ipedipcicrt101.northamerica.cerner.net/edi/epayment/cors/token'
TOKENIZATION_SERVICE_TIMEOUT = 40000

EDI_API_USER = 'IQHEALTH'
EDI_API_PASSWORD = '2018Cerner'

LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    'root': {
        'level': 'WARNING',
        'handlers': ['file'],
    },
    'loggers': {
        'iqh_billpay': {
            'handlers': ['null'],
            'level': 'WARNING',
        },
        # Temporarily create an 'iqh' logger and set level to WARNING so we
        # don't log debug level logs in iqh_clients
        'iqh': {
            'handlers': ['null'],
            'level': 'WARNING',
        },
        'django': {
            'handlers': ['null'],
            'level': 'DEBUG',
        },
        'requests': {
            'handlers': ['null'],
            'propagate': False,
            'level': 'DEBUG',
        },
        'template_timings_panel.panels': {
            'handlers': ['null'],
            'propagate': False,
            'level': 'WARNING',
        }
    },
    'formatters': {
        'simple': {
            #leave the space for syslog formatting compatibility
            'format': ' [%(levelname)s] %(name)s: process_id="%(process)s";thread_id="%(thread)s";%(message)s',
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'simple'
        },
        'null': {
            'class': 'logging.NullHandler',
        },
        'file': {
            'class': 'logging.FileHandler',
            'filename': 'iqh_billpay.logs',
            'formatter': 'simple'
        }
    }
}

if DEBUG and not 'test' in sys.argv:
    # make all loggers use the console.
    for logger in LOGGING['loggers']:
        LOGGING['loggers'][logger]['handlers'] += ['console']

# Anyone on the team can create their own my_settings.py if they'd like to
# override the standard local settings. This my_settings.py is included
# in SVN ignore
try:
    from my_settings import *
except ImportError:
    pass
