import os, sys

#note, this will only work for linux, change as appropriate
os.environ['PYTHON_EGG_CACHE'] = '/opt/.virtualenvs/iqh_billpay/egg-cache'

sys.path.append('/opt/djangoprojects/')
sys.path.append('/opt/djangoprojects/iqh_billpay/')
os.environ['DJANGO_SETTINGS_MODULE'] = 'iqh_billpay.settings'

import django.core.handlers.wsgi
application = django.core.handlers.wsgi.WSGIHandler()
