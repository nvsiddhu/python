# -*- coding: utf-8 -*-

import iqh_logging
from iqh_payments.codes import *
from tokenizer.exceptions import (EDISystemException,
                                  MissingInfoException,
                                  GenericTokenException,
                                  TSEPSystemException)

logger = iqh_logging.get_logger(__name__)


def is_get_token_response_valid(request):
    """
    Validates the response returned form EDI's Request Token service made using CORS or the response returned
    by the TSEP token service. Logs messages for responses that are invalid or have errors.

    Returns True if valid
    """
    data = request.POST
    error_code = data.get('error_code')
    error_message = data.get('error_message')
    interchange_id = data.get('interchange_id')
    card_type = data.get('card_type')
    masked_card_number = data.get('masked_card_number')
    org_slug = request.org['slug']
    http_status_code = data.get('http_status_code')
    tsep_error_code = data.get('tsep_error_code')
    tsep_error_message = data.get('tsep_error_message')
    account_id = getattr(request, 'acct', {}).get('id')
    guarantor_id = getattr(request, 'guarantor_id', None)

    # Ensure that all the required fields for a valid response are present.
    if interchange_id and card_type and masked_card_number:
        return True

    # sensitive credit card data was missing or not valid. No need to log an error.
    # We do however want to log errors for '01' because TSYS uses that code for
    # their unknown errors.
    elif error_message == 'sensitive_info_missing':
        raise MissingInfoException(error_message)

    elif error_code == INVALID_CARD:
        # Keeping existing behavior that did not log an error for an invalid card.
        raise GenericTokenException(error_message)

    # if POST data does not have either an error code, error message, or interchange_id,
    # the cors request to EDI unexpectedly failed.
    elif not error_code and not interchange_id and not error_message and not tsep_error_code and not tsep_error_message:
        logger.error("We received an unexpected error trying to send the request to "
                     "EDI's Request Token service. This may be related to the javascript component in charge"
                     "of making the CORS request to EDI. User Agent: {0}, org_slug: {1}, guarantor_id: {2}, account_id: {3}, http status code: {4}".format(
                         request.META.get('HTTP_USER_AGENT'), org_slug, guarantor_id, account_id, http_status_code))

    # An unknown_error was returned and we're unsure what happened to the request.
    # A browser using XDomainRequest will log this error when the response returns a 4XX or 5XX.
    elif error_message == 'unknown_error':
        logger.error("We're unsure what went wrong trying to receive the response from the Request Token "
                     "service. If the user is using IE 8/9, we may have received a response of "
                     "4XX or 5XX but we're unsure due to IE restrictions. On the other hand the issue may have been caused "
                     "by a network failure or the billpay domain requesting the token is not authorized to make a CORS request. "
                     "User Agent: {0}, org_slug: {1}, guarantor_id: {2}, account_id: {3}, http status code: {4}".format(
                         request.META.get('HTTP_USER_AGENT'), org_slug, guarantor_id, account_id, http_status_code))

    # We cancelled the request because the xhr callback handlers were never called.
    elif error_message == 'cancelled':
        logger.error("The CORS request unexpectedly aborted when trying to request a token. This is likely "
                     "caused by a javascript error in our code or a browser related issue that is causing the request to act abnormally. "
                     "User Agent: {0}, org_slug: {1}, guarantor_id: {2}, account_id: {3}".format(request.META.get('HTTP_USER_AGENT'), org_slug, guarantor_id, account_id))

    # if a status code wasn't set, then the request never received a response but we still
    # received an error message. This is not a service error but probably a Timeout or an error that
    # the javascript component caught.
    elif error_message and not http_status_code:
        logger.error("The following error was returned trying to recieve a response from EDI's "
                     "Request Token service: {0}. User Agent: {1} org_slug: {2} guarantor_id: {3} account_id: {4}".format(
                         error_message, request.META.get('HTTP_USER_AGENT'), org_slug, guarantor_id, account_id))

    # The service returned an expected error response structure so lets log it properly.
    elif error_code or error_message:
        logger.error('Request Token Service error when requesting an interchange_id. '
                     'The error is {0} - {1} for org_slug {2}, interchange_id {3}, guarantor_id: {4}, account_id: {5} and http status code {6}'.format(
                         error_code, error_message, org_slug, interchange_id, guarantor_id, account_id, http_status_code))

    # TSEP returned a page error
    elif tsep_error_code and tsep_error_message:
        error_msg = "TSEP error returned when requesting a TSEP token {0} - {1} for org_slug {2}, guarantor_id: {3}, account_id: {4}".format(
                        tsep_error_code, tsep_error_message, org_slug, guarantor_id, account_id)
        logger.error(error_msg)
        if tsep_error_code == "TSEPERR911":
            raise TSEPSystemException(error_msg)
        else:
            raise GenericTokenException(error_msg)

    # The response structure is not what we expected
    else:
        logger.error('Request Token Service returned an unexpected response when the requesting an '
                     'interchange_id. Expected interchange_id, card_type, and masked_card_number '
                     'to be on the response for org_slug {0}, interchange_id {1}, guarantor_id: {2}, account_id: {3}, for User Agent {4} and http status code {5} '.format(
                         org_slug, interchange_id, guarantor_id, account_id, request.META.get('HTTP_USER_AGENT'), http_status_code))

    if error_code in [INVALID_REQUEST, TRANSACTION_PROCESSING_ERROR] or error_message in ['timeout']:
        raise GenericTokenException(error_message)
    else:
        raise EDISystemException(error_message)
