# -*- coding: utf-8 -*-

from axiom_dates.parsers import parse_date
from axiom_django.forms.fields import EmailField
from axiom_django.forms.stripped import StrippedForm
from axiom_django.forms.widgets import MonthYearWidget
from recaptcha.fields import ReCaptchaField
from style_guide.forms.fields import CaptchaForm

from django import forms
from django.forms.widgets import TextInput, Widget
from django.utils.translation import ugettext_lazy as _lazy, ugettext as _
from django.contrib.localflavor.us.forms import USStateField
from django.contrib.localflavor.us.forms import USZipCodeField
from django.contrib.localflavor.us.us_states import STATE_CHOICES
from django.template.loader import render_to_string

import calendar
import datetime
import decimal
import re


class SensitiveTextInput(TextInput):
    """
    Widget removes the name attribute so the user entered data won't be sent back to the servers.
    """

    def build_attrs(self, extra_attrs=None, **kwargs):
        attrs = super(SensitiveTextInput, self).build_attrs(extra_attrs=extra_attrs, **kwargs)

        # remove name attribute from attrs so the data from the input does not get sent
        # back to the server on form submit.
        attrs.pop('name', None)
        return attrs


class TsepInput(SensitiveTextInput):
    """
    Widget renders a TSEP input
    """

    def render(self, name, value, attrs=None):
        attrs = self.build_attrs(attrs)
        if attrs.get('inline', False):
            return '<div id="{0}" style="display: inline;"></div>'.format(attrs['id'])
        return '<div id="{0}"></div>'.format(attrs['id'])


class AccessForm(StrippedForm):
    last_name = forms.CharField(label=_("Last name of bill recipient"),
            min_length=2, max_length=40, widget=forms.TextInput(attrs={'autocomplete': 'off'}))
    date_of_birth = forms.DateField(label=_("Date of birth of bill recipient"),
            help_text="ex. mm/dd/yyyy", widget=forms.DateInput(attrs={'class': 'axiom-datepicker',
                                                  'autocomplete': 'off'}))
    access_code = forms.CharField(label=_("Access code"), min_length=2,
            max_length=40, widget=forms.TextInput(attrs={'autocomplete': 'off'}))


class AccessFormTerms(StrippedForm):
    quickpay_terms = forms.BooleanField(required=True, label=_('I have read and accept the above Terms of Use'))


class RecaptchaForm(CaptchaForm):
    recaptcha = ReCaptchaField()


class PaymentForm(StrippedForm):
    """
    The form that allows the user to enter in their credit card data and billing address.
    Since we don't want sensitive information to get sent to our servers, lets remove the name
    attribute off of card number, secuirty number, and expiration date.
    """
    payment_amount = forms.CharField(label=_("Payment amount"),
            widget=forms.TextInput(attrs={'autocomplete': 'off'}))

    card_number = forms.CharField(label=_('Card number'), max_length=19, required=False,
            widget=SensitiveTextInput(attrs={'autocomplete': 'off', 'id': 'card_number'}))

    security_number = forms.CharField(label=_('Security code'), max_length=4, required=False,
            widget=SensitiveTextInput(attrs={'autocomplete': 'off', 'id': 'security_number'}))

    expiration_date = forms.DateField(label=_('Expiration date'))

    payer_name = forms.CharField(label=_("Name on card"), min_length=2,
            max_length=80, widget=forms.TextInput(attrs={'autocomplete': 'off'}))

    address = forms.CharField(label=_("Billing address"), max_length=200,
            widget=forms.TextInput(attrs={'autocomplete': 'off'}))

    city = forms.CharField(label=_("City"), max_length=100,
            widget=forms.TextInput(attrs={'autocomplete': 'off'}))

    US_STATE_CHOICES = list(STATE_CHOICES)
    US_STATE_CHOICES.insert(0, ('', ''))
    state = USStateField(label=_('State'), widget=forms.Select(choices=US_STATE_CHOICES))

    postal_code = USZipCodeField(label=_('Zip code'),
            widget=forms.TextInput(attrs={'autocomplete': 'off'}))

    interchange_id = forms.CharField(max_length=256, widget=forms.HiddenInput(), required=False)
    card_type = forms.CharField(max_length=1, widget=forms.HiddenInput(), required=False)
    masked_card_number = forms.CharField(max_length=16, widget=forms.HiddenInput(), required=False)
    tsep_error_code = forms.CharField(max_length=256, widget=forms.HiddenInput(), required=False)
    tsep_error_message = forms.CharField(max_length=256, widget=forms.HiddenInput(), required=False)

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop('request')

        payment_types = kwargs.pop('payment_types')
        self.supported_cc_types = []
        for cc_type, is_supported in payment_types.iteritems():
            if is_supported:
                self.supported_cc_types.append(cc_type)

        self.org_tz = kwargs.pop('org_tz')
        super(PaymentForm, self).__init__(*args, **kwargs)

        local_date = parse_date(astimezone=self.org_tz)
        self.fields['card_number'].help_text = render_to_string('payment_types.html', {'payment_types': payment_types})
        self.fields['expiration_date'].widget = MonthYearWidget(
                years=range(local_date.year, local_date.year + 16), attrs={'class': 'expiration_date'})

    def clean_payment_amount(self):
        """ User can't pay more than the amount they owe. """
        pay_amount = self.cleaned_data.get('payment_amount', None)
        if pay_amount is not None:
            try:
                pay_amount = decimal.Decimal(re.sub(r'[\s$,]', '', pay_amount))
            except:
                pay_amount = -1

            if pay_amount <= 0:
                raise forms.ValidationError("You must enter a payment amount.")

            exponent = pay_amount.as_tuple()[2]
            if abs(exponent) > 2:
                raise forms.ValidationError("Ensure that there are no more than 2 decimal places.")

            pay_amount = float(str(pay_amount))
            due_amount = self.request.acct.get('amount_due', None)
            if due_amount and due_amount < pay_amount:
                raise forms.ValidationError("Enter an amount less than or equal to your current balance.")

        return pay_amount

    def clean_expiration_date(self):
        """ User can't set a past expiration date. """
        expiration_date = self.cleaned_data.get('expiration_date', None)
        if expiration_date:
            # The expiration date widget sets the day to the first, but for credit
            # cards, it's actually the last day of the month
            days_in_month = calendar.monthrange(expiration_date.year, expiration_date.month)[1]
            expiration_date = expiration_date.replace(day=days_in_month)
            if expiration_date < datetime.date.today():
                raise forms.ValidationError("Enter an expiration date in the future.")

        return expiration_date


class TSEPPaymentForm(StrippedForm):
    """
    The form that allows the user to enter in their credit card data and billing address.
    Since we don't want sensitive information to get sent to our servers, lets remove the name
    attribute off of card number, secuirty number, and expiration date.
    """
    tsep_card_number = forms.CharField(label=_('Card number'), max_length=16, required=False,
            widget=TsepInput(attrs={'autocomplete': 'off', 'id': 'tsep-cardNumDiv'}))

    tsep_security_number = forms.CharField(label=_('Security code'), max_length=4, required=False,
            widget=TsepInput(attrs={'autocomplete': 'off', 'id': 'tsep-cvv2Div'}))

    tsep_expiration_date = forms.CharField(label=_('Expiration date'), max_length=7, required=False,
            widget=TsepInput(attrs={'autocomplete': 'off', 'id':'tsep-datepickerDiv'}))


class ReceiptForm(StrippedForm):
    email = EmailField(label='Email Address', min_length=5, max_length=75,
                       widget=forms.TextInput(attrs={'autocomplete': 'off'}))
