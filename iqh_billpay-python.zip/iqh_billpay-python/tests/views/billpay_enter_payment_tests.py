# -*- coding: utf-8 -*-

from urlparse import urlparse

import ast

import datetime
from django.conf import settings
from django.contrib import messages
from django.core.urlresolvers import reverse, resolve
from django.test import TestCase
from iqh_organizations.backends.factories import OrganizationFactory
from mock import patch, MagicMock
from tests.utils import BillpayRequestFactory
from tests.views.base_billpay_test import GuarantorLoggedinTestCase
from views import AccountPaymentView, TSEPAccountPaymentView
from views import PAYMENT_DATA_SESSION_KEY, TOKEN_REFERENCE_ID_SESSION_KEY


class AccountPaymentViewGetTests(TestCase):

    def setUp(self):
        self.request = BillpayRequestFactory(guarantor_id='98765', account_id='1234').get('/')
        self.view = AccountPaymentView()
        self.view.request = self.request
        self.view.org = OrganizationFactory()
        self.view.kwargs = {'account_id': '1234'}

    @patch('views.random_id')
    def test_context_data_for_request_token(self, random_id):
        """
        The AccountPaymentView should set the required data for the CORS
        request into context.
        """
        random_id.return_value = '999'

        context = self.view.get_context_data()

        self.assertEquals(context['token_reference_id'], '999')
        self.assertEquals(self.request.session[TOKEN_REFERENCE_ID_SESSION_KEY], '999')
        self.assertEquals(context['interchange_id_lookup_api_url'], settings.EDI_TOKEN_REQUEST_API_URL)
        self.assertEquals(context['tokenization_service_timeout'], settings.TOKENIZATION_SERVICE_TIMEOUT)
        self.assertEquals(context['account_id'], '1234')
        self.assertEquals(context['payment_receiver_id'], self.request.acct['payment_receiver_id'])

    def test_get_captcha_key(self):
        """
        The AccountPaymentView should return the captcha key for all the failed
        attemps submitting a payment.
        """
        key = self.view.get_captcha_key()

        self.assertEquals(key, 'payment_failed_{0}_{1}'.format(self.request.org['slug'], '1234'))

    @patch('views.payments.get_supported_payment_types_and_merchant_id')
    def test_get_supported_payment_types_and_merchant_id(self, mock_api):
        """
        When called the first time, should pass org_slug and payment_receiver_id to the API
        then return the results. When called again, should just return the results without
        calling the api.
        """
        payment_types = {'payment_type1', 'payment_type2'}
        merchant_id = 'merchant_id'
        mock_api.return_value = (payment_types, merchant_id)

        return_value = self.view.get_supported_payment_types_and_merchant_id('org_slug', 'payment_receiver_id', 'guarantor_id', 'account_id')

        mock_api.assert_called_with('org_slug', 'payment_receiver_id', 'guarantor_id', 'account_id')
        self.assertEqual(return_value[0], payment_types)
        self.assertEqual(return_value[1], merchant_id)

        return_value = self.view.get_supported_payment_types_and_merchant_id('org_slug', 'payment_receiver_id', 'guarantor_id', 'account_id')

        self.assertEqual(mock_api.call_count, 1)
        self.assertEqual(return_value[0], payment_types)
        self.assertEqual(return_value[1], merchant_id)

    @patch('views.payments.get_merchant')
    @patch('views.BillPayConfig')
    def test_get_supported_payment_types_and_merchant_id_with_tsep(self, billpayconfig, mock_api):
        """
        When called the first time, should pass org_slug and payment_receiver_id to the API
        then return the results. When called again, should just return the results without
        calling the api.
        """
        payment_types = {'payment_type1', 'payment_type2'}
        merchant_id = 'merchant_id'
        merchant = {}
        merchant['payment_types'] = payment_types
        merchant['merchant_id'] = merchant_id
        mock_api.return_value = merchant
        billpayconfig.is_tsep_enabled.return_value = True

        return_value = self.view.get_supported_payment_types_and_merchant_id('org_slug', 'payment_receiver_id', 'guarantor_id', 'account_id')

        mock_api.assert_called_with('org_slug', 'payment_receiver_id', 'guarantor_id', 'account_id')
        self.assertEqual(return_value[0], payment_types)
        self.assertEqual(return_value[1], merchant_id)

        return_value = self.view.get_supported_payment_types_and_merchant_id('org_slug', 'payment_receiver_id', 'guarantor_id', 'account_id')

        self.assertEqual(mock_api.call_count, 1)
        self.assertEqual(return_value[0], payment_types)
        self.assertEqual(return_value[1], merchant_id)

class TSEPViewTests(TestCase):

    def setUp(self):
        self.view = TSEPAccountPaymentView()
        self.view.request = BillpayRequestFactory(guarantor_id='98765', account_id='1234').get('/')
        self.view.org = OrganizationFactory()

    @patch('views.payments.get_merchant')
    @patch('views.FormView')
    def test_tsep_view_gets_merchant(self, formview, get_merchant):
        """
        When the tsep view is called, the merchant is added to the context.
        """
        formview.get_context.return_value = {}
        get_merchant.return_value = {'merchant_id': '1234'}
        context = self.view.get_context_data()
        self.assertEqual(context['merchant_id'], '1234')

    def test_tsep_view_requires_account_id(self):
        """
        The tsep view must be called with an account_id argument to get the payment_receiver_id.
        """
        url = reverse('tsep', kwargs={'account_id': '123'})
        self.assertTrue(len(url) > 1)


class AccountPaymentViewPostTests(TestCase):

    def setUp(self):
        self.factory = BillpayRequestFactory(guarantor_id='98765', account_id='1234')
        self.view = AccountPaymentView()
        self.view.org = OrganizationFactory()
        self.view.kwargs = {'account_id': '1234'}

    @patch('views.record_measured_request')
    @patch('views.payments._build_statsd_keys')
    def test_record_request_metrics(self, keys, record_metrics):
        """
        The AccountPaymentView should record metrics when response time is set
        in the post data.
        """
        keys.return_value = ['key1', 'key2']

        request = self.factory.post('/', {'response_time': '10000', 'http_status_code': '200'})
        self.view.request = request
        self.view.post(request)

        self.assertTrue(record_metrics.called)
        record_metrics.assert_called_with(['key1', 'key2'], '200', '10000', None)

    @patch('views.record_measured_request')
    def test_record_request_metrics_no_response_time(self, record_metrics):
        """
        The AccountPaymentView should NOT record metrics when response_time is NOT
        set in the post data. This occurs when the CORS request is NOT sent.
        """
        request = self.factory.post('/', {})
        self.view.request = request
        self.view.post(request)

        self.assertFalse(record_metrics.called)

    @patch('views.is_get_token_response_valid')
    def test_payment_data_in_session(self, is_get_token_response_valid):
        """
        AccountPaymentView should put encrypted form data in session and redirect the user
        to the confirm page when the form and token retrival response is valid.
        """
        is_get_token_response_valid.return_value = True

        request = self.factory.post('/',
                {'payment_amount': '1', 'interchange_id': '123', 'expiration_date': '2099-1-1', 'payer_name': 'John',
                 'address': '123 Main', 'city': 'KC', 'state': 'MO', 'postal_code': '12345', 'card_type': 'V',
                 'masked_card_number': '************9999'})
        self.view.request = request
        response = self.view.post(request)

        form_data = request.session[PAYMENT_DATA_SESSION_KEY]
        session_data = ast.literal_eval(form_data)

        # ensure all the required but unsensitive data is in session
        self.assertEquals(session_data['card_number'], '')
        self.assertEquals(session_data['security_number'], '')
        self.assertEquals(session_data['interchange_id'], '123')
        self.assertEquals(session_data['address'], '123 Main')
        self.assertEquals(session_data['city'], 'KC')
        self.assertEquals(session_data['state'], 'MO')
        self.assertEquals(session_data['postal_code'], '12345')
        self.assertEquals(session_data['payment_amount'], 1.0)
        self.assertEquals(session_data['payer_name'], 'John')
        self.assertEquals(session_data['expiration_date'], '2099-01-31')
        self.assertEquals(session_data['masked_card_number'], '************9999')
        self.assertEquals(session_data['card_type'], 'Visa')

        # ensure the user is redirected to the confirm payment page
        self.assertEquals(response.status_code, 302)
        self.assertEquals(resolve(urlparse(response['location'])[2]).url_name, "confirm_payment")

    @patch('views.CaptchaMixin.delete_access_failures_cache')
    @patch('views.is_get_token_response_valid')
    def test_form_valid_delete_cache_when_payment_successful(self, is_get_token_response_valid, mock_delete_cache):
        """
        form_valid should delete the cache when is_get_token_response_valid returns True.
        """
        is_get_token_response_valid.return_value = True
        mock_delete_cache.assert_called_once()

    def test_account_payment_form_invalid(self):
        """
        The accounts payment form should have the card number and security number
        in addition to other form errors if the form is invalid.
        """
        request = self.factory.post('/',
                {'payment_amount': '1', 'interchange_id': '123', 'expiration_date': '', 'payer_name': 'John',
                 'address': '123 Main', 'city': 'KC', 'state': 'MO', 'postal_code': '12345', 'card_type': 'V',
                 'masked_card_number': '************9999'})
        self.view.request = request
        response = self.view.post(request)

        form_errors = response.context_data['form']._errors
        self.assertIn('card_number', form_errors.keys())
        self.assertIn('security_number', form_errors.keys())
        self.assertIn('expiration_date', form_errors.keys())


class BillPayEnterPaymentTests(GuarantorLoggedinTestCase):
    """ Django client Tests for enter payment flows """

    def test_no_sensitive_field_name_attributes_on_form(self):
        """
        The Make Payment page should not render the field name
        attributes for card number and security number so the sensitive data
        does not get sent back to the server.
        """
        response = self.client.get(reverse('account_payment', args=['1234']))

        self.assertTemplateUsed(response, 'account_payment.html')
        self.assertNotContains(response, 'name="card_number"')
        self.assertNotContains(response, 'name="security_number"')

    def test_account_details(self):
        """
        The Make Payment page shall display details about the account selected including:
           facility name, patient name, amount due and masked account number.
        The Make Payments page shall allow the user to return to the View Accounts page.
        """
        response = self.client.get(reverse('account_payment', args=['1234']))

        self.assertTemplateUsed(response, 'account_payment.html')
        self.assertContains(response, response.context['acct']['facility'])
        self.assertContains(response, response.context['acct']['patient_name'])
        self.assertContains(response, str(response.context['acct']['amount_due']))
        self.assertContains(response, response.context['acct']['masked_account_number'])
        self.assertContains(response, reverse('view_accounts'))

    def test_get_payment_form_amount(self):
        """
        The payment amount field shall be pre-populated with the account balance.
        """
        response = self.client.get(reverse('account_payment', args=['1234']))
        self.assertEqual(response.context['form'].initial['payment_amount'],
                         str(response.context['acct']['amount_due']))

    @patch('views.payments.get_supported_payment_types_and_merchant_id')
    def test_get_payment_form_card_types(self, get_payment_types):
        """
        The payment form shall display the images of the credit cards accepted by
        the organization.
        """
        get_payment_types.return_value = (
            {"mastercard": True, "visa": True, "american_express": True, "discover": True},
            '123456789'
        )

        response = self.client.get(reverse('account_payment', args=['1234']))
        self.assertContains(response, 'visa.png')
        self.assertContains(response, 'mastercard.png')
        self.assertContains(response, 'american-express.png')
        self.assertContains(response, 'discover.png')

    @patch('views.payments.get_supported_payment_types_and_merchant_id')
    def test_get_payment_form_card_types_for_american_express_and_discover(self, get_payment_types):
        """
        The payment form shall display only american express and discover images
        when those cards are only accepted.
        """
        get_payment_types.return_value = (
            {"mastercard": False, "visa": False, "american_express": True, "discover": False},
            '123456789'
        )

        response = self.client.get(reverse('account_payment', args=['11111111111111111111111111111']))
        self.assertNotContains(response, 'visa.png')
        self.assertNotContains(response, 'mastercard.png')
        self.assertContains(response, 'american-express.png')
        self.assertNotContains(response, 'discover.png')

    @patch('views.payments.get_supported_payment_types_and_merchant_id')
    def test_get_payment_form_card_types_for_visa_and_mastercard(self, get_payment_types):
        """
        The payment form shall display only visa and mastercard images
        when those cards are only accepted.
        """
        get_payment_types.return_value = (
            {"mastercard": True, "visa": True, "american_express": False, "discover": False},
            '123456789'
        )

        response = self.client.get(reverse('account_payment', args=['44442']))
        self.assertContains(response, 'visa.png')
        self.assertContains(response, 'mastercard.png')
        self.assertNotContains(response, 'american-express.png')
        self.assertNotContains(response, 'discover.png')

    @patch("views.payments.get_supported_payment_types_and_merchant_id")
    def test_get_payment_form_no_card_types(self, mock):
        """
        If there is an error with the service that returns the supported credit
        card types, the Make Payment page shall still load without images.
        """
        mock.return_value = ({}, None)

        response = self.client.get(reverse('account_payment', args=['1234']))
        assert response.status_code == 200
        self.assertNotContains(response, 'visa.png')
        self.assertNotContains(response, 'mastercard.png')
        self.assertNotContains(response, 'american-express.png')
        self.assertNotContains(response, 'discover.png')

    @patch('axiom_dates.parsers.datetime')
    def test_get_payment_form_edit_payment(self, dt):
        """
        If the user indicates to edit the payment, the Make Payment screen
        should set the user's previous payment amount, name, billing address, and expiration date.
        """
        dt.now.return_value = datetime.datetime(year=2014, month=12, day=31)
        dt.utcnow.return_value = datetime.datetime(year=2014, month=12, day=31)
        form_data = {
            'payment_amount': 1000,
            'expiration_date': '2016-01-01',
            'masked_card_number': '************1111',
            'payer_name': 'Jane Smith',
            'address': '200 1st St.',
            'city': 'Chicago',
            'state': 'IL',
            'postal_code': '99999'
        }
        self.set_payment_data_in_session(form_data)

        response = self.client.get(reverse('account_payment', args=['1234']))
        self.assertContains(response, form_data['payment_amount'])
        self.assertContains(response, form_data['payer_name'])
        self.assertContains(response, form_data['address'])
        self.assertContains(response, form_data['city'])
        self.assertContains(response, form_data['state'])
        self.assertContains(response, form_data['postal_code'])

        self.assertContains(response, '<option value="1" selected="selected">January</option>')
        self.assertContains(response, '<option value="2016" selected="selected">2016</option>')


class BillPayTokenRetrievalErrorTests(GuarantorLoggedinTestCase):

    def test_token_retrieval_system_error(self):
        """
        AccountPaymentView shall redirect user to the accounts page and display an error message
        if the error from the token retrieval service is a system error.
        """
        system_error_codes = ['S3', 'S4' 'S6', 'S8', 'S9', '50', '01', '401']
        for system_error_code in system_error_codes:
            self._assert_token_retrieval_system_error({'error_code': system_error_code})

    @patch('views.CaptchaMixin.increment_access_failures')
    def test_token_retrieval_non_system_or_credit_card_error(self, mock_increment_access_failures):
        """
        AccountPaymentView shall render the make payment page with an error message if the error from
        the token retrieval service is a non_system_error or a credit card error.
        """
        error_codes = ['S2', 'S7', '04']
        for error_code in error_codes:
            self._assert_token_retrieval_non_system_or_credit_error({'error_code': error_code})

        self._assert_token_retrieval_non_system_or_credit_error({'error_message': 'timeout'})
        mock_increment_access_failures.assert_called_once()

    @patch.object(messages, 'error')
    def test_token_retrieval_missing_sensitive_information(self, messages):
        """
        AccountPaymentView shall render the make payment page with NO error message if
        the error_message returned to the billpay application is 'sensitive_info_missing'.
        """
        self._build_response_for_account_payments_url({'error_message': 'sensitive_info_missing'})

        self.assertFalse(messages.called)
        self.assertEqual(resolve(urlparse(self.response.request['PATH_INFO'])[2]).url_name, "account_payment")

    @patch.object(messages, 'error')
    def test_tsep_server_error_code(self, messages):
        """
        AccountPaymentView shall redirect user to the accounts page and display an error message
        if the error from the tsep service is a system error.
        """
        self._assert_token_retrieval_system_error({'tsep_error_code': 'TSEPERR911'})

    def _build_response_for_account_payments_url(self, extra_post_data):
        """
        Sets the session data to do a post to the accounts payment url and
        does a post to the account_payment url.
        """
        post_data = {'payment_amount': '1',
                    'expiration_date': '2099-1-1',
                    'payer_name': 'abcd', 'address': '123', 'city': 'abcd',
                    'state': 'MO', 'postal_code': '12345'}
        post_data.update(extra_post_data)

        self.response = self.client.post(reverse('account_payment', args=['1234']), post_data)

    @patch.object(messages, 'error')
    def _assert_token_retrieval_system_error(self, extra_post_data, messages):
        """
        Does a post and asserts the user is redirected to the view accounts page
        and an error message is displayed when a system error code is present in the request.
        """
        self._build_response_for_account_payments_url(extra_post_data)

        self.assertTrue(messages.called)
        self.assertEqual(resolve(urlparse(self.response['location'])[2]).url_name, "view_accounts")

    @patch.object(messages, 'error')
    def _assert_token_retrieval_non_system_or_credit_error(self, extra_post_data, messages):
        """
        Does a post and asserts the user is redirected to the account payment form
        and an error message is displayed when a non system error code is present in the request.
        """
        self._build_response_for_account_payments_url(extra_post_data)

        self.assertTrue(messages.called)
        # assert the user was not redirected to a different page
        self.assertEquals(self.response.status_code, 200, 'User should not be redirected')
        self.assertIsNone(self.response.get('location'))

        self.assertEqual(resolve(urlparse(self.response.request['PATH_INFO'])[2]).url_name, "account_payment")
