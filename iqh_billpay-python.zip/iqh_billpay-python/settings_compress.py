# -*- coding: utf-8 -*-

"""
Static content LESS compilation, compression and minification.

To run:
1. Install NodeJS at http://nodejs.org/#download (needed for the LESS schtuff)
2. npm install less -g       (may need to do this with sudo)
3. pip install compress_now --extra-index-url http://popeye.cerner.corp/pypi
4. python manage.py compress_now [version] ~/path/to/statics/s/iqhbp/

"""

COMPILE_LESS = {
    'default-standard': {
        'source_filename': 'less/base_standard.less',
        'output_filename': 'css/default/standard.css',
    },
    'default-mobile': {
        'source_filename': 'less/base_mobile.less',
        'output_filename': 'css/default/mobile.css',
    },
}

COMPRESS_CSS = {
    'standard': {
        'source_filenames': ('css/default/standard.css',),
        'output_filename': 'css/default/s-?.css',
    },
    'mobile': {
        'source_filenames': ('css/default/mobile.css',),
        'output_filename': 'css/default/m-?.css',
    },
    'print': {
        'source_filenames': ('css/print.css',),
        'output_filename': 'css/print-?.css',
    },
}

COMPRESS_JS = {
    'standard': {
        'source_filenames': ('js/billpay.js',
                             'js/style_guide/date-picker.js',
                             'js/style_guide/info-box.js',
                             'js/style_guide/timeout-dialog.js',
                             'js/style_guide/alerts.js',
                             'js/style_guide/bootstrap-modal.js',
                             'js/style_guide/dialog.js',
                             'js/style_guide/spin.js',),
        'output_filename': 'js/s-?.js',
    },
    'mobile': {
        'source_filenames': ('js/billpay.js',
                             'js/style_guide/date-picker.js',),
        'output_filename': 'js/m-?.js',
    }
}
