
from axiom_dates.parsers import parse_datetime

from django.template import RequestContext
from django.template.loader import render_to_string
from unittest import TestCase
from bs4 import BeautifulSoup
from django.contrib.humanize.templatetags.humanize import intcomma
from tests.utils import BillpayRequestFactory


class BillPayBadDebtDisplayTest(TestCase):
    """
    Tests to check the bad debt alert display in views_accounts.html
    """
    bad_debt_amount = 2357.2360985

    def set_account_details(self, show_bad_debt_amount, accts_amount_due=None, accts_no_amount_due=None):
        self.factory = BillpayRequestFactory(guarantor_id='98765')
        self.request = self.factory.get('quickpay/accounts/')

        context = RequestContext(self.request, {'show_bad_debt_amount': show_bad_debt_amount,
            'accts_amount_due': [accts_amount_due],
            'accts_no_amount_due': [accts_no_amount_due]})

        html = render_to_string('view_accounts.html', context)
        soup = BeautifulSoup(html)

        #Finds the alert box displayed regarding the bad debt amount from the rendered html.
        self.alert_message_section = soup.find('div', {"class": "alert-message danger"})

    def test_when_bad_debt_in_collection_and_bad_debt_configuration_enabled(self):
        """
        Alert message should be displayed with the bad debt amount when the bad debt configuration is enabled and there
        is a bad debt in collection.
        """
        self.set_account_details(show_bad_debt_amount=True, accts_no_amount_due=self._mock_account_with_bad_debt_amount())

        #Gets the bad_debt_amount and forms the alert message to be displayed.
        bad_debt_message = "An additional $" + intcomma(str("%.2f" % self.bad_debt_amount)) + " has been turned over to collections. The current balance listed below does not include this collections amount. Online payment will be applied to non-collections amount due. Call to pay the collections amount directly."

        self.assertIsNotNone(self.alert_message_section)
        self.assertTrue(str(intcomma(str("%.2f" % self.bad_debt_amount))) in self.alert_message_section.get_text())
        self.assertEquals(bad_debt_message, self.alert_message_section.get_text("|", strip=True))

    def test_when_bad_debt_in_collection_and_bad_debt_configuration_disabled(self):
        """
        Alert message should not be displayed when the bad debt configuration is disabled but there is a bad debt in collection.
        """
        self.set_account_details(show_bad_debt_amount=False, accts_no_amount_due=self._mock_account_with_bad_debt_amount())

        self.assertIsNone(self.alert_message_section)

    def test_when_no_bad_debt_in_collection_and_bad_debt_configuration_enabled(self):
        """
        Alert message should not be displayed when the bad debt configuration is enabled but there are no bad debt in collection.
        """
        self.set_account_details(show_bad_debt_amount=True, accts_amount_due=self._mock_account_with_no_bad_debt())

        self.assertIsNone(self.alert_message_section)

    def test_when_no_bad_debt_in_collection_and_bad_debt_configuration_disabled(self):
        """
        Alert message should not be displayed when the bad debt configuration is disabled but there are no bad debt in collection.
        """
        self.set_account_details(show_bad_debt_amount=False, accts_amount_due=self._mock_account_with_no_bad_debt())

        self.assertIsNone(self.alert_message_section)

    def _mock_account_with_no_bad_debt(self):
        return {
                    'bad_debt_amount': 0.0,
                    'payment_receiver_id': 'scenario1',
                    'last_payment_date': None,
                    'masked_account_number': 'XXXXXX789',
                    'account_number': '123456789',
                    'facility': 'Baseline Accepts All Cards',
                    'last_payment_amount': 1234.56,
                    'amount_due': 1995.98,
                    'id': '1234',
                    'patient_name': 'John Smith'}

    def _mock_account_with_bad_debt_amount(self):
        return  {
                    'bad_debt_amount': self.bad_debt_amount,
                    'payment_receiver_id': 'scenario2',
                    'last_payment_date': parse_datetime('2011-07-21T17:36:21.000Z', ignoretz=False),
                    'masked_account_number': '****-****-ABC',
                    'account_number': '5432-1234-ABC',
                    'facility': 'Docs R Us',
                    'last_payment_amount': 1234.56,
                    'amount_due': 0,
                    'id': 'abcdefg',
                    'patient_name': 'Jane Smith'}