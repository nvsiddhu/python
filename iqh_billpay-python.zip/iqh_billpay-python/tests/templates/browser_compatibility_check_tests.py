from django.test.client import RequestFactory
from django.template import RequestContext
from django.template.loader import render_to_string
from unittest import TestCase
from bs4 import BeautifulSoup


class BrowserCompatibilityTests(TestCase):
    """
    Templates tests for the account_payment template components.
    """
    def setUp(self):
        self.request = RequestFactory(guarantor_id='98765', account_id='1234').get('/')
        self.upgrade_old_version_banner = 'Warning! This website requires a newer browser version. Upgrade to the latest version of one of our supported browsers (Google Chrome, Mozilla Firefox, Microsoft Internet Explorer, or Apple Safari).'

    def banner_for_ie10_or_below_test(self):
        """
        When user is using bill pay in Internet Explorer 10 or below, it should
        show alert banner.
        """
        context = RequestContext(self.request, {'IE10_OR_BELOW': True})
        html = render_to_string('browser_compatibility_check.html', context)
        self.soup = BeautifulSoup(html)
        banner_text = self.soup.get_text()
        self.assertTrue(self.upgrade_old_version_banner in banner_text)

    def no_banner_for_ie11_or_above_test(self):
        """
        When user is using bill pay in Internet Explorer 11 or above, it should
        not show alert banner.
        """
        context = RequestContext(self.request)
        html = render_to_string('browser_compatibility_check.html', context)
        self.soup = BeautifulSoup(html)
        banner_text = self.soup.get_text()
        self.assertFalse(self.upgrade_old_version_banner in banner_text)
