# -*- coding: utf-8 -*-

"""
Guarantor backend that uses memcached and Millennium REST guarantor APIs.
"""
import iqh_logging
from requests.exceptions import Timeout, SSLError
from base import BasePaymentBackend
from bill_pay_config.models import BillPayConfig
from client_utils.careaware_service_directory import (get_service_url,
                                                      OAUTH_SERVICE_KEY)
from dateutil.parser import parse
from decimal import Decimal
from django.conf import settings
from django.core.cache import get_cache
from iqh_configurations import configurations
from iqh_configurations import configuration_enums
from iqh_organizations.models import Organization
from iqh_payments.parsers import parse_payment_status
from iqh_payments.codes import *
from client_utils.oauth_util import SimpleOAuthClient
from client_utils import requests_metrics

import base64
import json
import urllib
import time
import requests

_MEMCACHED_NAMESPACE_FACILITIES = 'iqh.payments.facilities'
_MEMCACHED_NAMESPACE_SUBMITTER_PAYMENT_TYPES = 'iqh.payments.submitter_id_to_payment_types'
_MEMCACHED_NAMESPACE_ACCOUNT_TO_FACILITY = 'iqh.payments.account_id_to_facility_id'

logger = iqh_logging.get_logger(__name__)


# TODO Seperate EDI service calls from Patient Accounting
class PaymentBackend(BasePaymentBackend):

    def get_guarantor_id(self, org_slug, access_code, last_name, birth_date):
        if isinstance(birth_date, basestring):
            birth_date = parse(birth_date)
            if not birth_date:
                raise Exception("Invalid birth_date")
        birth_date = "{0:04d}{1:02d}{2:02d}".format(birth_date.year,
                                                    birth_date.month,
                                                    birth_date.day)

        base_service_url, config = self._get_careaware_config(org_slug)
        parameters = {'guarantorAccessCode': access_code,
                      'guarantorLastName': last_name,
                      'guarantorDOB': birth_date}

        oauth_client = self._get_oauth_client(org_slug, config)
        guarantor_service_url = u'{0}/guarantors'.format(base_service_url)
        headers = oauth_client.build_http_oauth_request_header(guarantor_service_url,
                                                               'GET', parameters)
        headers['Accept'] = 'application/json'
        guarantor_service_url = u'{0}?{1}'.format(guarantor_service_url,
                                                  urllib.urlencode(parameters))

        def exec_request():
            return requests.get(guarantor_service_url, headers=headers, timeout=18, verify=False)

        try:
            response = requests_metrics.exec_measured_request(
                    exec_request,
                    self._build_statsd_keys('hnam_rest_payments.get_guarantor_id', org_slug)
                    )
        except Timeout:
            raise Exception(u'Service timed out. Failed to retrieve resource at {0}'.format(guarantor_service_url))

        if response.status_code != 200:
            raise Exception(u'Service failed to retrieve resource at {0}. Response was: {1} {2}'.format(guarantor_service_url, response.status_code, response.text))

        resp_json = json.loads(response.text)
        if resp_json:
            # They return a list, but since we include access token there
            # should always only be 1
            guarantor_id = resp_json[0].get('guarantorID')  # guarantor id is an int
            # we must convert the id to a string or encryption will fail
            return str(guarantor_id) if guarantor_id else None
        return None

    def get_accounts(self, org_slug, guarantor_id):
        base_service_url, config = self._get_careaware_config(org_slug)
        accounts_url = u'{0}/guarantors/{1}/guarantorPatientAccounts'.format(base_service_url, guarantor_id)

        oauth_client = self._get_oauth_client(org_slug, config)
        headers = oauth_client.build_http_oauth_request_header(accounts_url, 'GET')
        headers['Accept'] = 'application/json'

        def exec_request():
            return requests.get(accounts_url, headers=headers, timeout=18, verify=False)

        try:
            response = requests_metrics.exec_measured_request(
                    exec_request,
                    self._build_statsd_keys('hnam_rest_payments.get_accounts', org_slug)
                    )
        except Timeout:
            raise Exception(u'Service timed out. Failed to retrieve resource at {0}.'.format(accounts_url))

        if response.status_code != 200:
            raise Exception(u'Service failed to retrieve resource at {0}. Response was: {1} {2}'.format(accounts_url, response.status_code, response.text))

        resp_json = json.loads(response.text)
        accounts = []
        for account_json in resp_json:
            account = self._build_account(account_json)
            accounts.append(account)

        return accounts

    def get_account(self, org_slug, guarantor_id, account_id):
        base_service_url, config = self._get_careaware_config(org_slug)
        account_url = u'{0}/guarantors/{1}/guarantorPatientAccounts/{2}'.format(base_service_url, guarantor_id, account_id)

        oauth_client = self._get_oauth_client(org_slug, config)
        headers = oauth_client.build_http_oauth_request_header(account_url, 'GET')
        headers['Accept'] = 'application/json'

        def exec_request():
            return requests.get(account_url, headers=headers, timeout=18, verify=False)

        try:
            response = requests_metrics.exec_measured_request(
                    exec_request,
                    self._build_statsd_keys('hnam_rest_payments.get_account', org_slug)
                    )
        except Timeout:
            raise Exception(u'Service timed out. Failed to retrieve resource at {0}.'.format(account_url))

        if response.status_code == 404:
            return None
        elif response.status_code != 200:
            raise Exception(u'Service failed to retrieve resource at {0}. Response was: {1}, content: {2}'.format(account_url, response.status_code, response.text))

        account_json = json.loads(response.text)
        account = self._build_account(account_json)
        facility = self._get_facility(account['facility_id'], oauth_client,
                                      base_service_url, org_slug)
        account['payment_receiver_id'] = facility['payment_receiver_id']

        cache = get_cache(_MEMCACHED_NAMESPACE_ACCOUNT_TO_FACILITY)
        cache_key = '{0}_{1}'.format(org_slug, account_id)
        cache.set(cache_key, account['facility_id'], timeout=1800)

        return account

    def _build_account(self, account_json):
        account = dict()
        # We get this as a number, but we should just treat it as a string.
        account['id'] = str(account_json.get('patientAccountId'))
        account['account_number'] = account_json.get('accountNumber')
        account['masked_account_number'] = account_json.get('maskAccountNumber')
        account['patient_name'] = account_json.get('patientName')
        account['facility'] = account_json.get('facility')
        account['facility_id'] = account_json.get('facilityId')
        # The service gives us a negative number in the case of a payment, but
        # we want to treat it as a positive value, so we have to multiply by -1
        last_payment_amount = account_json.get('lastPaymentAmount')
        account['last_payment_amount'] = last_payment_amount * -1 if last_payment_amount else None
        last_payment_date = account_json.get('lastPaymentDate')
        account['last_payment_date'] = parse(last_payment_date, ignoretz=True) if last_payment_date else None
        account['amount_due'] = account_json.get('patientResponsibilityAmount')
        account['bad_debt_amount'] = account_json.get('patientBadDebtBalance')
        return account

    def get_supported_payment_types_and_merchant_id(self, org_slug, payment_receiver_id, guarantor_id, account_id):

        cache = get_cache(_MEMCACHED_NAMESPACE_SUBMITTER_PAYMENT_TYPES)
        payment_types_and_merchant_id = cache.get(payment_receiver_id)
        if payment_types_and_merchant_id:
            return payment_types_and_merchant_id

        submitter_lookup_url = u'{0}reference/submitter/{1}/CREDIT_PROCESSING'.format(settings.EDI_SUBMITTER_LOOKUP_API_URL, payment_receiver_id)
        try:
            # Make sure that any problems with this service call don't cause
            # the application to fail
            def exec_request():
                return requests.get(submitter_lookup_url, verify=False, timeout=18)

            response = requests_metrics.exec_measured_request(
                    exec_request,
                    self._build_statsd_keys('hnam_rest_payments.get_supported_payment_types', org_slug)
                    )
            if response.status_code != 200:
                logger.error(u'Failed to retrieve resource at {0}. Org_Slug={1}, Guarantor_ID={2}, Account_ID={3}. Response was: {4} {5}'.format(submitter_lookup_url, org_slug, guarantor_id, account_id, response.status_code, response.text))
                return {}, None

            resp_json = json.loads(response.text).get('serviceAttributeResponse')
            if resp_json.get('error'):
                logger.error(u'An error was returned from {0}. Org_Slug={1}, Guarantor_ID={2}, Account_ID={3}. Response was:{4}'.format(submitter_lookup_url, org_slug, guarantor_id, account_id, response.text))
                return {}, None
            service_attributes = resp_json.get('service').get('serviceAttributes')[0].get('serviceAttribute')
        except:
            logger.exception(u'Failed to retrieve resource at {0}. Org_Slug={1}, Guarantor_ID={2}, Account_ID={3}.'.format(submitter_lookup_url, org_slug, guarantor_id, account_id))
            return {}, None

        payment_types = dict()
        merchant_id = None
        for attribute in service_attributes:
            name = attribute.get('name')
            value = attribute.get('value')
            if name == "VISA":
                payment_types['visa'] = (value.lower() == "true")
            elif name == "MASTERCARD":
                payment_types['mastercard'] = (value.lower() == "true")
            elif name == "DISCOVER":
                payment_types['discover'] = (value.lower() == "true")
            elif name == "AMEX":
                payment_types['american_express'] = (value.lower() == "true")
            elif name == "MERCHANT_ID":
                merchant_id = value

        cache.set(payment_receiver_id, (payment_types, merchant_id), timeout=86400)
        return payment_types, merchant_id

    def get_merchant(self, org_slug, payment_receiver_id, guarantor_id, account_id):
        authorization = base64.b64encode('{0}:{1}'.format(settings.EDI_API_USER, settings.EDI_API_PASSWORD))
        headers = {'Authorization': 'Basic {0}'.format(authorization), 'Content-Type': 'application/json'}
        request_data = {"merchantRequest": { "submitterId": payment_receiver_id, "generateManifest": "true"}}
        submitter_lookup_url = u'{0}merchant/'.format(settings.EDI_BILLPAY_API_URL)
        merchant = dict()
        merchant['payment_types'] = dict()

        def exec_request():
            return requests.post(submitter_lookup_url, data=json.dumps(request_data), headers=headers, verify=settings.VERIFY_SSL, timeout=20)

        try:
            response = requests_metrics.exec_measured_request(exec_request,
                self._build_statsd_keys('hnam_rest_payments.get_supported_payment_types_and_manifest_and_device_id',
                                         org_slug))
        except:
            logger.exception(u'Failed to retrieve resource at {0} for Org_Slug={1}, Payment_Receiver_ID={2}, Guarantor_ID={3}, Account_ID={4}'.format(
                                submitter_lookup_url, org_slug, payment_receiver_id, guarantor_id, account_id))
            return merchant

        if response.status_code != 200:
            logger.error(u'Failed to retrieve resource at {0} for Org_Slug={1}, Payment_Receiver_ID={2}, Guarantor_ID={3}, Account_ID={4}. Response was: {5} {6}'.format(
                            submitter_lookup_url, org_slug, payment_receiver_id, guarantor_id, account_id,response.status_code, response.text))
            return merchant

        resp_json = json.loads(response.text).get('ack')

        if resp_json.get('errors'):
            logger.error(u'An error was returned from {0}. Response was:{1}. Org_Slug={2}, Payment_Receiver_ID={3}, Guarantor_ID={4}, Account_ID={5}.'.format(
                            submitter_lookup_url, response.text, org_slug, payment_receiver_id, guarantor_id, account_id))
            return merchant

        merchant['manifest'] = resp_json.get('merchant').get('manifest')
        merchant['merchant_id'] = resp_json.get('merchant').get('merchantId')
        merchant['device_id'] = None
        for device in resp_json.get('merchant').get('devices'):
            if device.get('encryptionType')=='TSEP':
                merchant['device_id'] = device.get('deviceId')

        service_attributes = resp_json.get('merchant').get('serviceAttributes')

        for attribute in service_attributes:
            name = attribute.get('name')
            value = attribute.get('value')
            if name == "VISA":
                merchant['payment_types']['visa'] = (value.lower() == "true")
            elif name == "MASTERCARD":
                merchant['payment_types']['mastercard'] = (value.lower() == "true")
            elif name == "DISCOVER":
                merchant['payment_types']['discover'] = (value.lower() == "true")
            elif name == "AMEX":
                merchant['payment_types']['american_express'] = (value.lower() == "true")

        return merchant

    def create_payment(self, base_payment_url, oauth_client, org_slug,
                       guarantor_id, account_id, amount, payer_name):
        # TODO: It's sooo lame that we have to pass the service url and oauth
        # client to this function. It'll be much better when we change the
        # implementation of our clients such that when we create an instance of
        # the client, it would set these attributes (i.e oauth_client,
        # base_payment_url) without needing to call a function to retrieve
        # them.

        headers = oauth_client.build_http_oauth_request_header(base_payment_url, 'POST')
        headers['Content-Type'] = 'application/json'
        headers['Accept'] = 'application/json'

        # This service expects the amount as a number, so cast it to a float if
        # it's a Decimal so it will be json encoded correctly
        payment_content = {'amount': float(amount) if isinstance(amount, Decimal) else amount,
                           'paymentMethod': 'CREDIT CARD',
                           'paymentReason': 'ONLINEBILLPY',
                           'payerName': payer_name}

        def exec_request():
            return requests.post(base_payment_url, data=json.dumps(payment_content), headers=headers, timeout=15, verify=False)
        try:
            response = requests_metrics.exec_measured_request(
                        exec_request,
                        self._build_statsd_keys('hnam_rest_payments.patient_accounting_submit_credit_card_payment', org_slug)
                        )

        except Exception as e:
            logger.exception(u'Patient accounting service error when creating the payment for org_slug {0}, guarantor_id {1}, account_id {2}  at {3}.'.format(
                                org_slug, guarantor_id, account_id, base_payment_url))
            raise e

        try:
            # If we made a bad request (a 4XX client error or 5XX server error response),
            # then log an error and raise the same exception.
            # TODO: Extend HTTPErrorMixin once we move to iqh_logging so the mixin logs errors for us
            response.raise_for_status()
        except:
            logger.exception(u'Patient accounting service failed to create the payment at {0}. Received the following response text: {1}. - org_slug {2}, guarantor_id {3}, account_id {4}'.format(
                                base_payment_url, response.text, org_slug, guarantor_id, account_id))
            raise

        resp_json = json.loads(response.text)
        return str(resp_json.get('paymentId'))

    def charge_by_token(self, org_slug, guarantor_id, account_id, payment_receiver_id,
                        amount, payer_name, street_address, city, state, postal_code,
                        interchange_id, masked_card_number, card_type,
                        formatted_expiration_date, merchant_id, token_reference_id):

        # TODO: This function does not belong here. It should exist in a module
        # outside of the backend.
        base_service_url, config = self._get_careaware_config(org_slug)
        base_payment_url = u'{0}/guarantors/{1}/guarantorPatientAccounts/{2}/payment'.format(base_service_url, guarantor_id, account_id)
        oauth_client = self._get_oauth_client(org_slug, config)

        payment_content = {
            'cardNumber': masked_card_number,
            'cardType': card_type,
            'expirationDate': formatted_expiration_date,
            'merchantID': merchant_id
        }

        try:
            payment_id = self.create_payment(base_payment_url, oauth_client,
                                             org_slug, guarantor_id,
                                             account_id, amount, payer_name)
        except:
            payment_id = None

        if payment_id is None:
            return ('failure', {'error_code': 'submission_failure'})

        update_payment_url = u'{0}/{1}'.format(base_payment_url, payment_id)
        tsep_expiration_date = formatted_expiration_date.replace('/','')
        try:
            payment_status = self._submit_payment(payment_receiver_id, amount,
                                                  payer_name, street_address,
                                                  city, state, postal_code,
                                                  payment_id, interchange_id,
                                                  token_reference_id, org_slug,
                                                  guarantor_id, account_id,
                                                  tsep_expiration_date)
        except SSLError as e:
            if 'read operation timed out' in str(e):
                return self._update_payment_incase_timeout(update_payment_url, oauth_client, org_slug,
                    payment_id, payment_content, guarantor_id, account_id)
            return self._update_payment_incase_unexpected_error(update_payment_url, oauth_client,
                org_slug, payment_content, guarantor_id, account_id)

        except Timeout:
            return self._update_payment_incase_timeout(update_payment_url, oauth_client, org_slug,
                payment_id, payment_content, guarantor_id, account_id)

        except:
            return self._update_payment_incase_unexpected_error(update_payment_url, oauth_client,
                org_slug, payment_content, guarantor_id, account_id)

        payment_content['transactionId'] = payment_status.interchange_id

        if payment_status.charged:
            payment_content['paymentStatus'] = 'POST'
            payment_content['referenceNumber'] = payment_status.approval_code
            payment_content['amount'] = payment_status.amount_charged
            return_val = ('success', {'payment_id': payment_id})

        elif payment_status.code == 'S6':
            # No response from partner. Status of the transaction is unknown
            # and there is a risk the payment was successful. Client needs to
            # contact the Financial Hub for more information.
            return self._update_payment_incase_timeout(update_payment_url, oauth_client, org_slug,
                payment_id, payment_content, guarantor_id, account_id)

        else:
            payment_content['paymentStatus'] = 'CANCEL'
            payment_content['statusReason'] = self._get_status_reason(payment_status.code)
            return_val = ('failure', {'error_code': self._get_error_code(payment_status.code)})

        self._update_payment(update_payment_url, payment_content, oauth_client,
                             org_slug, guarantor_id, account_id)

        return return_val

    def _update_payment_incase_unexpected_error(self, update_payment_url, oauth_client, org_slug, payment_content, guarantor_id, account_id):
        # Incase there was an exception other than a Timeout or SSL Read timeout exception.
        payment_content['paymentStatus'] = 'CANCEL'
        payment_content['statusReason'] = 'GENERAL_SYSTEM_FAILURE'
        self._update_payment(update_payment_url, payment_content,
                             oauth_client, org_slug, guarantor_id, account_id)
        return ('failure', {'error_code': 'submission_failure'})

    def _update_payment_incase_timeout(self, update_payment_url, oauth_client, org_slug, payment_id, payment_content, guarantor_id, account_id):
        # there is a possibility the payment was successful but the service
        # timed out before getting the approval code.
        payment_content['statusReason'] = 'TIMEOUT'
        self._update_payment(update_payment_url, payment_content,
                             oauth_client, org_slug, guarantor_id, account_id)
        return ('timeout', {'payment_id': payment_id})

    def check_payment_status(self, org_slug, guarantor_id, account_id,
                             payment_id, payment_receiver_id, card_type):
        base_service_url, config = self._get_careaware_config(org_slug)
        oauth_client = self._get_oauth_client(org_slug, config)

        return self._get_payment_response(guarantor_id, account_id, payment_id,
                                          payment_receiver_id, oauth_client,
                                          base_service_url, card_type, org_slug)

    def _get_payment_response(self, guarantor_id, account_id,
                              payment_id, payment_receiver_id, oauth_client,
                              base_service_url, card_type, org_slug=None):
        authorization = base64.b64encode('{0}:{1}'.format(settings.EDI_API_USER,
                                                          settings.EDI_API_PASSWORD))
        headers = {'Authorization': 'Basic {0}'.format(authorization),
                   'Accept': 'application/json'}
        progress_url = u'{0}external/{1}/{2}'.format(settings.EDI_BILLPAY_API_URL,
                                                     payment_receiver_id, payment_id)

        def exec_request():
            return requests.get(progress_url, headers=headers,
                                verify=settings.VERIFY_SSL,
                                timeout=20)

        try:
            response = requests_metrics.exec_measured_request(
                    exec_request,
                    self._build_statsd_keys('hnam_rest_payments.edi_get_payment_response', org_slug)
                    )
        except:
            logger.exception(u'Get Payment Status Service error when requesting the status of '
                             'the payment for url {0}, org_slug: {1}, payment_id: {2}, payment_receiver_id: {3}, guarantor_id: {4}, account_id: {5}'.format(
                                 progress_url, org_slug, payment_id, payment_receiver_id, guarantor_id, account_id))
            return ('timeout', {'payment_id': payment_id})

        try:
            # If the service returns a response with a non valid json text then it will throw an exception
            # and return a timeout. A non valid json can be an empty text like that returned by a 204 response.
            resp_json = json.loads(response.text)
        except:
            logger.error(u'Service failed to get payment from {0}. Response was: {1} {2} - org_slug: {3}, payment_receiver_id: {4}, guarantor_id: {5}, account_id: {6} '.format(
                            progress_url, response.status_code, response.text, org_slug, payment_receiver_id, guarantor_id, account_id))
            return ('timeout', {'payment_id': payment_id})

         # If the processing completed, update the payment in hnam with the results
        if resp_json.get('ack', {}).get('errors'):
            logger.error(u'An error was returned from {0}. Response was:{1} - org_slug: {2}, payment_receiver_id: {3}, guarantor_id: {4}, account_id: {5}'.format(
                            progress_url, response.text, org_slug, payment_receiver_id, guarantor_id, account_id))
            error_code = resp_json.get('ack').get('errors').get('error')[0].get('errorCode')
            if error_code == 'S6':
                # No response from partner.  Status of the transaction is unknown and there is a
                # risk the payment was successful.  Client needs to contact the Financial Hub for
                # more information.
                return ('timeout', {'payment_id': payment_id})
            else:
                payment_content = {'paymentStatus': 'CANCEL',
                                   'statusReason': 'GENERAL_SYSTEM_FAILURE'}
                return_val = ('failure', {'error_code': 'submission_failure'})
        else:
            bill_pay_status = resp_json.get('billpayResponse').get('billpayStatus')
            status_code = bill_pay_status.get('statusCode')
            interchange_id = bill_pay_status.get('interchangeId')
            payment_content = {'referenceNumber': bill_pay_status.get('approvalCode'),
                               'transactionId': interchange_id}
            if status_code in ('00', '02'):
                payment_content['paymentStatus'] = 'POST'
                payment_content['amount'] = bill_pay_status.get('amount')
                payment_content['merchantID'] = bill_pay_status.get('merchantId')
                payment_content['cardNumber'] = bill_pay_status.get('cardNumber')
                payment_content['expirationDate'] = bill_pay_status.get('expirationDate')
                payment_content['cardType'] = card_type
                return_val = ('success', {'payment_id': payment_id})
            else:
                payment_content['paymentStatus'] = 'CANCEL'
                payment_content['statusReason'] = self._get_status_reason(status_code)
                return_val = ('failure', {'error_code': self._get_error_code(status_code)})

        payment_url = u'{0}/guarantors/{1}/guarantorPatientAccounts/{2}/payment/{3}'.format(base_service_url, guarantor_id, account_id, payment_id)
        self._update_payment(payment_url, payment_content, oauth_client,
                             org_slug, guarantor_id, account_id)
        return return_val

    def _update_payment(self, payment_url, payment_content, oauth_client, org_slug, guarantor_id, account_id):
        headers = oauth_client.build_http_oauth_request_header(payment_url, 'PUT')
        headers['Content-Type'] = 'application/json'

        def exec_request():
            return requests.put(payment_url, data=json.dumps(payment_content), headers=headers, timeout=30, verify=False)
        try:
            response = requests_metrics.exec_measured_request(
                    exec_request,
                    self._build_statsd_keys('hnam_rest_payments.update_payment', org_slug)
                    )
        except:
            logger.exception(u'Patient accounting service error when updating the payment for org_slug {0}, guarantor_id {1}, account_id {2} at {3}.'.format(
                    org_slug, guarantor_id, account_id, payment_url))
            return

        if response.status_code != 200:
            logger.error(u'Patient accounting service error when updating payment for org_slug {0}, guarantor_id {1}, account_id {2} at {3}. Response was: {4} {5}'.format(
                    org_slug, guarantor_id, account_id, payment_url, response.status_code, response.text))

    def get_payment(self, org_slug, guarantor_id, account_id, payment_id):
        base_service_url, config = self._get_careaware_config(org_slug)
        payment_url = u'{0}/guarantors/{1}/guarantorPatientAccounts/{2}/payment/{3}'.format(base_service_url, guarantor_id, account_id, payment_id)
        oauth_client = self._get_oauth_client(org_slug, config)
        headers = oauth_client.build_http_oauth_request_header(payment_url, 'GET')
        headers['Accept'] = 'application/json'

        def exec_request():
            return requests.get(payment_url, headers=headers, timeout=18, verify=False)

        try:
            response = requests_metrics.exec_measured_request(
                    exec_request,
                    self._build_statsd_keys('hnam_rest_payments.get_payment', org_slug)
                    )
        except Timeout:
            raise Exception(u'Service timed out. Failed to retrieve resource at {0}.'.format(payment_url))

        if response.status_code != 200:
            raise Exception(u'Service failed to retrieve resource at {0}. Response was: {1} {2}'.format(payment_url, response.status_code, response.text))

        resp_json = json.loads(response.text)
        payment = dict()
        payment['receipt_number'] = resp_json.get('receiptNumber')
        # The service gives us a negative number in the case of a payment, but
        # we want to treat it as a positive value, so we have to multiply by -1
        amount = resp_json.get('amount')
        payment['amount'] = amount * -1 if amount else None
        payment_date = resp_json.get('paymentDate')
        payment['payment_date'] = parse(payment_date, ignoretz=True) if payment_date else None
        payment['account_number'] = resp_json.get('accountNumber')
        payment['masked_account_number'] = resp_json.get('maskAccountNumber')
        payment['patient_name'] = resp_json.get('patientName')
        payment['payer_name'] = resp_json.get('payerName')
        payment['transaction_id'] = resp_json.get('transactionId')

        cache = get_cache(_MEMCACHED_NAMESPACE_ACCOUNT_TO_FACILITY)
        cache_key = '{0}_{1}'.format(org_slug, account_id)
        facility_id = cache.get(cache_key)
        if not facility_id:
            account = self.get_account(org_slug, guarantor_id, account_id)
            cache.set(cache_key, account['facility_id'], timeout=1800)
            facility_id = account['facility_id']

        facility = self._get_facility(facility_id, oauth_client,
                                      base_service_url, org_slug)
        payment['payee_name'] = facility.get('name')
        payment['payee_address_line_1'] = facility.get('address_line_1')
        payment['payee_address_line_2'] = facility.get('address_line_2')
        payment['payee_city'] = facility.get('city')
        payment['payee_state'] = facility.get('state')
        payment['payee_postal_code'] = facility.get('postal_code')
        payment['payee_phone'] = facility.get('phone')

        return payment

    def _get_careaware_config(self, org_slug):
        config = configurations.get(org_slug,
                                    configuration_enums.CAREAWARE_SERVICE)
        careaware_config = config[configuration_enums.CAREAWARE_SERVICE]
        if not careaware_config:
            raise Exception(u'No careaware_service config found for org {0}'.format(org_slug))

        service_host = get_service_url(org_slug, 'urn:cerner:api:financials.onlinebillpay-1.0')
        base_service_url = u'{0}service/{1}'.format(service_host,
                                                    careaware_config['domain'])

        return (base_service_url, careaware_config)

    def _get_oauth_client(self, org_slug, config):
        oauth_host = get_service_url(org_slug, OAUTH_SERVICE_KEY)
        oauth_url = u'{0}{1}/{2}/tokens'.format(oauth_host, config['client_mnemonic'],
                                                config['domain'])
        oauth_client = SimpleOAuthClient(oauth_url,
                                         config['consumer_key'],
                                         config['consumer_secret'])
        return oauth_client

    def _get_expiration_date(self, expiration_year, expiration_month):
        '''
        @param expiration_year: The 4 digit integer or String representing the
                                year the card expires.
        @param expiration_month: The integer or String representing the month
                                 the card expires. 1=January, ..., 12=December
        @return A string in the format YYYYMM corresponding to the expiration
                year and month.
        '''
        if isinstance(expiration_month, basestring):
            date = '{0}0{1}' if len(expiration_month) == 1 else '{0}{1}'
        else:
            date = '{0}0{1}' if expiration_month < 10 else '{0}{1}'
        return date.format(expiration_year, expiration_month)

    def _get_error_code(self, code):
        """
        Translate the EDI error codes into the error code returned by this
        backend.
        """
        if code == CARD_DECLINED:
            return 'declined'
        if code == INSUFFICIENT_FUNDS:
            return 'insufficient_funds'
        elif code in [INVALID_CARD, INVALID_ACCOUNT]:
            return 'invalid_account'
        elif code == ACCOUNT_CLOSED:
            return 'account_closed'
        elif code == EXPIRED_CARD:
            return 'card_expired'
        elif code == ADDRESS_VERIFICATION_FAILED:
            return 'incorrect_address'
        elif code == CVV_VERIFICATION_FAILED:
            return 'incorrect_security_code'
        elif code == ADDRESS_AND_CVV_VERIFICATION_FAILED:
            return 'incorrect_address_and_security_code'
        elif code in [INVALID_CHECK_NUMBER, INVALID_BANK_ROUTING_NUMBER, DUPLICATE_CHECK]:
            return 'bad_check'  # we should never get these codes b/c we don't process bank checks
        else:  # all other codes
            return 'submission_failure'

    def _get_status_reason(self, code):
        """
        Translate the EDI error codes into the status desired by the payment
        service.
        """
        if code in [INVALID_CHECK_NUMBER, INVALID_BANK_ROUTING_NUMBER, DUPLICATE_CHECK]:
            return 'DECLINED'
        elif code == INSUFFICIENT_FUNDS:
            return 'INSUFFICIENT_FUNDS'
        elif code in (INVALID_CARD, INVALID_ACCOUNT, ACCOUNT_CLOSED):
            return 'INVALID_CC_NUMBER'
        elif code == EXPIRED_CARD:
            return 'CARD_EXPIRED'
        elif code in (ADDRESS_VERIFICATION_FAILED, ADDRESS_AND_CVV_VERIFICATION_FAILED):
            return 'INVALID_ADDRESS'
        elif code == CVV_VERIFICATION_FAILED:
            return 'INVALID_CVV'
        else:
            return 'GENERAL_SYSTEM_FAILURE'

    def _get_facility(self, facility_id, oauth_client, base_service_url, org_slug):
        cache = get_cache(_MEMCACHED_NAMESPACE_FACILITIES)
        cache_key = '{0}_{1}'.format(org_slug, facility_id)
        facility = cache.get(cache_key)
        if facility:
            return facility

        facility_url = u'{0}/facility/{1}'.format(base_service_url, facility_id)
        headers = oauth_client.build_http_oauth_request_header(facility_url, 'GET')
        headers['Accept'] = 'application/json'

        def exec_request():
            return requests.get(facility_url, headers=headers, timeout=18, verify=False)
        try:
            response = requests_metrics.exec_measured_request(
                    exec_request,
                    self._build_statsd_keys('hnam_rest_payments.get_facility', org_slug)
                    )
        except Timeout:
            raise Exception('Service timed out. Failed to retrieve resource at {0}'.format(facility_url))

        if response.status_code != 200:
            raise Exception('Service failed to retrieve resource at {0} with status {1}, content: {2}'.format(facility_url, response.status_code, response.text))
        resp_json = json.loads(response.text)

        facility = dict()
        facility['payment_receiver_id'] = resp_json.get('submitterId')
        facility['name'] = resp_json.get('name')
        facility['address_line_1'] = resp_json.get('streetAddress1')
        facility['address_line_2'] = resp_json.get('streetAddress2')
        facility['address_line_3'] = resp_json.get('streetAddress3')
        facility['address_line_4'] = resp_json.get('streetAddress4')
        facility['city'] = resp_json.get('city')
        facility['state'] = resp_json.get('state')
        facility['postal_code'] = resp_json.get('zipCode')
        facility['country'] = resp_json.get('country')
        facility['phone'] = resp_json.get('phone')

        cache.set(cache_key, facility, timeout=86400)
        return facility

    def _submit_payment(self, payment_receiver_id, amount, payer_name,
                        street_address, city, state, postal_code, payment_id,
                        interchange_id, token_reference_id, org_slug, guarantor_id,
                        account_id, tsep_expiration_date):
        """
        Submits a payment by interchange_id and token_reference_id.
        Returns a PaymentStatus namedtuple.
        """
        authorization = base64.b64encode('{0}:{1}'.format(settings.EDI_API_USER,
                                                          settings.EDI_API_PASSWORD))
        headers = {'Authorization': 'Basic {0}'.format(authorization),
                   'Content-Type': 'application/json',
                   'Accept': 'application/json'}
        submit_request = self._build_payment_submission_request(payment_receiver_id, amount,
                                                                street_address, city, state,
                                                                postal_code, payment_id,
                                                                interchange_id, token_reference_id,
                                                                org_slug, tsep_expiration_date)
        submit_url = '{0}token/charge'.format(settings.EDI_BILLPAY_API_URL)
        def exec_request():
            return requests.post(submit_url, data=json.dumps(submit_request), headers=headers, verify=False, timeout=20)

        try:
            response = requests_metrics.exec_measured_request(
                    exec_request,
                    self._build_statsd_keys('hnam_rest_payments.edi_submit_credit_card_payment', org_slug)
                        )

        except Exception as e:
            logger.exception(u'Failed to call EDI ePayment service to submit a payment by token to {0} for interchange_id {1}, payment_id {2}, org_slug {3}, guarantor_id {4}, account_id {5}'.format(
                    submit_url, interchange_id, payment_id, org_slug, guarantor_id, account_id))
            raise e

        # EDI returns error codes for 4XX and 5XX status codes
        try:
            payment_status = parse_payment_status(json.loads(response.text))
        except:
            logger.exception(u'EDI ePayment service failed to submit payment by token to {0} for interchange_id {1}, payment_id {2}, org_slug {3}, guarantor_id {4}, account_id {5}. Response was: {6} - {7}'.format(
                             submit_url, interchange_id, payment_id, org_slug, guarantor_id, account_id,
                             response.status_code, response.text))
            raise

        # log an error if an EDI issue occured or a TSYS unexpected error occured. Credit card issues returned from TSYS should not be logged.
        # The only issue we should log from TSYS is CARD_DECLINED (01) and TOKENIZATION_SERVICE_NOT_ENABLED (50)
        # because it's not related to the codes returned from user and bank errors.
        if (not payment_status.charged and
                (payment_status.code not in BANK_AND_USER_ERROR_CODES or
                 payment_status.code in [CARD_DECLINED])):
            logger.error(u'EDI ePayment service return an error when submitting payment by token to {0} for interchange_id {1}, payment_id {2}, org_slug {3}, guarantor_id {4}, account_id {5}. Response was: {6} {7}'.format(
                         submit_url, interchange_id, payment_id, org_slug, guarantor_id, account_id,
                         response.status_code, response.text))

        return payment_status

    def _build_payment_submission_request(self, payment_receiver_id, amount,
                                          street_address, city, state,
                                          postal_code, payment_id,
                                          interchange_id, token_reference_id,
                                          org_slug, tsep_expiration_date):

        transaction = {'amount': str(amount),
                       'externalTransactionId': payment_id,
                       'token': interchange_id,
                       'tokenReferenceId': token_reference_id,
                       'submitterId': payment_receiver_id}
        billing_address = {'address1': street_address,
                           'city': city,
                           'state': state,
                           'country': 'US',
                           'zipCode': postal_code}

        request = {
            'tokenPaymentRequest': {
                'transaction': transaction,
                'payment': {
                    'card': {
                        'billingAddress': billing_address
                    }
                }
            }
        }

        org = Organization.objects.get(slug=org_slug)
        if BillPayConfig.is_tsep_enabled(org):
            request['tokenPaymentRequest']['payment']['card']['expirationDate'] = tsep_expiration_date
        return request

    def _build_statsd_keys(self, statsd_client_key, org_slug=None):
        # Build the statsd keys for all-orgs and the current org
        statsd_key_template = (u'quickpay.{org_slug}.clients.' +
                statsd_client_key)
        statsd_keys = [statsd_key_template.format(org_slug='all_orgs')]
        if org_slug:
            statsd_keys.append(statsd_key_template.format(org_slug=org_slug))

        return statsd_keys
