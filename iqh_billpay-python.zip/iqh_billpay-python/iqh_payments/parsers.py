# -*- coding: utf-8 -*-

import iqh_logging
from iqh_payments.codes import SUCCESSFUL, PARTIAL_AMOUNT_APPROVED
from types import PaymentStatus

logger = iqh_logging.get_logger(__name__)


def parse_payment_status(json_data):
    """
    Parses the json_data that represents a the payment status of the charge.
    Returns a PaymentStatus namedtuple with the following attributes:
     - interchange_id
     - approval_code: reference number
     - amount_charged: The actual amount charged
     - amount_requested: The amount requested by the user
     - code: status/error code returned from the service
     - charged: boolean that determines whether the payment was charged
     - error_message: error message returned from the service

    EDI has two types of codes:
     - error codes
     - status codes

    Error codes are set when EDI gets an error processing the payment request.

    Status codes are set by TSYS which provide information about the request made
    to charge the service.

    Both codes are never set at the same time on a response. So it's either
    one or the other.
    """

    ack = json_data.get('ack', {})

    charged = False
    error_message = None
    code = ack.get('statusCode')

    # if response has errors, EDI wants us to pull codes from errorCode
    # attribute rather than statusCode
    error = ack.get('errors', {}).get('error', {})
    if error:
        code = error[0].get('errorCode')
        error_message = error[0].get('errorMsg')

    charged = has_been_charged(ack)

    return PaymentStatus(
        interchange_id=ack.get('interchangeId'),
        approval_code=ack.get('approvalCode'),
        amount_charged=ack.get('amount'),
        amount_requested=ack.get('amountRequested'),
        code=code,
        charged=charged,
        error_message=error_message)


def has_been_charged(ack_data):
    """
    EDI says the only elements that deem the transaction to be successful
    are approvalCode, amount, and a successful statusCode.
    """
    approval_code = ack_data.get('approvalCode')
    amount_charged = ack_data.get('amount')
    code = ack_data.get('statusCode')

    if code in [SUCCESSFUL, PARTIAL_AMOUNT_APPROVED] and approval_code and amount_charged:
        return True

    return False
