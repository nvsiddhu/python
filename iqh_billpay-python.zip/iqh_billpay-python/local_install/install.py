# -*- coding: utf-8 -*-

#!/usr/bin/env python

"""
Installs and updates Bill Pay. Instructions are at
https://wiki.ucern.com/display/PH/Bill+Pay+Installation

This script is only tested on OS X 10.x
"""
import argparse
import os
import shlex
import subprocess
import sys


def main():
    """
    Method used to install/update Billpay.
    """
    parser = argparse.ArgumentParser(description='install billpay and tools')
    parser.add_argument('--branch', help='install this branch instead of trunk')
    parser.add_argument('--tag', help='Install this tag instead of trunk or branch')
    parser.add_argument('--release', help='Install this tag from release repo')
    parser.add_argument('--cwxrelease', help='Install this tag from the cwx release repo')
    parser.add_argument('--resetdb', action='store_true', help='delete all data before running syncdb', default=False)

    args = parser.parse_args(sys.argv[1:])

    try:
        from patient_portal_dependencies.patient_portal_dependencies import Installer
    except ImportError:
        #if an error occured during import we need to install the application
        install_app_location = 'http://scm.healthe-axiom.cerner.corp/svn/axiom-python-services/trunk/ext/tgz/patient-portal-dependencies-1.1.0.tar.gz'
        cmd = 'pip install {0}'.format(install_app_location)
        try:
            subprocess.check_call(shlex.split(cmd))
        except subprocess.CalledProcessError:
            raise Exception(u"Failed to install required patient_portal_dependencies package.")
        from patient_portal_dependencies.patient_portal_dependencies import Installer

    if args.tag:
        src_rel_path = 'src/tags/{0}/'.format(args.tag)
        svn_download_root = 'http://scm.iqhealth-emr.cerner.corp/svn/python/tags/{0}/'.format(args.tag)
    elif args.branch:
        src_rel_path = 'src/branches/{0}/'.format(args.branch)
        svn_download_root = 'http://scm.iqhealth-emr.cerner.corp/svn/python/branches/{0}/'.format(args.branch)
    elif args.release:
        src_rel_path = 'src/tags/{0}/'.format(args.release)
        svn_download_root = 'http://scm.iqhealth-release.cerner.corp/svn/iqhbp/tags/{0}/'.format(args.release)
    elif args.cwxrelease:
        src_rel_path = 'src/tags/{0}/'.format(args.cwxrelease)
        svn_download_root = 'http://cernciesvn01.cernerasp.com/iqhealth-release/iqhbp/tags/{0}/'.format(args.cwxrelease)
    else:
        src_rel_path = 'src/trunk/'
        svn_download_root = 'http://scm.iqhealth-emr.cerner.corp/svn/python/trunk/'
    app_name = 'iqh_billpay'

    installer = Installer(
            app_name=app_name,
            src_rel_path=src_rel_path,
            svn_download_root=svn_download_root,
            requirements_file=os.path.join(os.environ['VIRTUAL_ENV'], src_rel_path, app_name, 'install/local_requirements.txt'),
            svn_deps_path=os.path.join(os.environ['VIRTUAL_ENV'], src_rel_path, app_name, 'install'))

    #run the full installer on iqh_billpay because all dependency info is stored here
    installer()

    def cd_proj(project):
        os.chdir(os.path.join(os.environ['VIRTUAL_ENV'], installer.src_rel_path.lstrip('/'), project))

    cd_proj('iqh_billpay')
    if args.resetdb and os.path.isfile('sqlite3/iqh_bp.db'):
        subprocess.check_call(shlex.split('rm sqlite3/iqh_bp.db'))

    # build local data
    subprocess.check_call(shlex.split('python manage.py build_local_db'))
    subprocess.check_call(shlex.split('python manage.py compilejsi18n'))


    print 'Billpay install/update completed!'

if __name__ == '__main__':
    main()
