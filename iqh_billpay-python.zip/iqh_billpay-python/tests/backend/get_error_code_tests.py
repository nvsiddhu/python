# -*- coding: utf-8 -*-

from django.test import TestCase

from axiom_django.backends import get_backend

payments = get_backend('',
                       'iqh_payments.backends.hnam_rest_payments',
                       'PaymentBackend')


class TestGetErrorCode(TestCase):

    def test_declined(self):
        """
        _get_error_code should translate the declined
        error code to a readable format.
        """
        code = payments._get_error_code('01')
        self.assertEquals(code, 'declined')

    def test_insufficient_funds(self):
        """
        _get_error_code should translate the insufficient funds
        error code to a readable format.
        """
        code = payments._get_error_code('03')
        self.assertEquals(code, 'insufficient_funds')

    def test_invalid_card(self):
        """
        _get_error_code should translate the invalid card
        error code to a readable format.
        """
        code = payments._get_error_code('04')
        self.assertEquals(code, 'invalid_account')

    def test_invalid_account(self):
        """
        _get_error_code should translate the invalid account
        error code to a readable format.
        """
        code = payments._get_error_code('05')
        self.assertEquals(code, 'invalid_account')

    def test_account_closed(self):
        """
        _get_error_code should translate the account closed
        error code to a readable format.
        """
        code = payments._get_error_code('06')
        self.assertEquals(code, 'account_closed')

    def test_invalid_check_number(self):
        """
        _get_error_code should translate the invalid check number
        error code to a readable format.
        """
        code = payments._get_error_code('10')
        self.assertEquals(code, 'bad_check')

    def test_invalid_routing_number(self):
        """
        _get_error_code should translate the invalid routing number
        error code to a readable format.
        """
        code = payments._get_error_code('12')
        self.assertEquals(code, 'bad_check')

    def test_duplicate_check(self):
        """
        _get_error_code should translate the duplicate check
        error code to a readable format.
        """
        code = payments._get_error_code('13')
        self.assertEquals(code, 'bad_check')

    def test_card_expired(self):
        """
        _get_error_code should translate the card expired
        error code to a readable format.
        """
        code = payments._get_error_code('20')
        self.assertEquals(code, 'card_expired')

    def test_incorrect_address(self):
        """
        _get_error_code should translate the incorrect address
        error code to a readable format.
        """
        code = payments._get_error_code('21')
        self.assertEquals(code, 'incorrect_address')

    def test_incorrect_security_code(self):
        """
        _get_error_code should translate the incorrect cvv
        error code to a readable format.
        """
        code = payments._get_error_code('22')
        self.assertEquals(code, 'incorrect_security_code')

    def test_incorrect_address_and_security_code(self):
        """
        _get_error_code should translate the incorrect address and cvv
        error code to a readable format.
        """
        code = payments._get_error_code('23')
        self.assertEquals(code, 'incorrect_address_and_security_code')

    def test_submission_failure(self):
        """
        _get_error_code should return 'submission_failure' when the code given
        is not a code with a dedicated tsys error_code.
        """
        code = payments._get_error_code('S2')
        self.assertEquals(code, 'submission_failure')

        code = payments._get_error_code('S3')
        self.assertEquals(code, 'submission_failure')

        code = payments._get_error_code('S4')
        self.assertEquals(code, 'submission_failure')

        code = payments._get_error_code('S7')
        self.assertEquals(code, 'submission_failure')

        code = payments._get_error_code('S8')
        self.assertEquals(code, 'submission_failure')

        code = payments._get_error_code('S9')
        self.assertEquals(code, 'submission_failure')

        code = payments._get_error_code('401')
        self.assertEquals(code, 'submission_failure')
