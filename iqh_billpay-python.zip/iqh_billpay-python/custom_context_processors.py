# -*- coding: utf-8 -*-

"""
!!!WARNING!!! This file is uber sensitive to errors.
Anything that we set in request, session, settings, or anything for that matter
needs to be coded defensively.

The reasons for this is because this context processor is used by
even the 500 and 404 handlers.  So if a 500 error occurs, it'll run through
this, and if there is an error in here, the 500 error handler will error, and
the user won't be able to enjoy the error page, but rather a nasty ugly
webserver error screen.

If a 404 occurs, which happens after the request middlewares are processed, but
before any other middleware, then if anything in this code depends on things
set in the view middleware or later, this context processor could cause a 500,
which could go into the problem above.

Lesson is BE VERY CAREFUL IN THIS CODE

Use context processor when you are going to put things in to context used
by the templates.  Be very selective on whether to use context process or
middleware (request, response, etc...)
"""
from axiom_django.middleware.user_agent_detection import (build_mobile_uri,
                                                          build_standard_uri,
                                                          get_root_uri_standard)
from django.conf import settings
from django.utils.safestring import mark_safe
from ua_parser import user_agent_parser

from billpay_template_config.models import BillpayTemplateConfig


def site_pages(request):
    context = {'DEPLOYMENT_MODE': settings.DEPLOYMENT_MODE,
               'SESSION_COOKIE_AGE': settings.SESSION_COOKIE_AGE,
               'TSEP_TRANSIT_DOMAIN': settings.TSEP_TRANSIT_DOMAIN}

    if hasattr(request, 'base_template') and request.base_template:
        context['BASE_TEMPLATE'] = request.base_template
    else:
        request.base_template = "base_standard.html"
        context['BASE_TEMPLATE'] = request.base_template

    if hasattr(request, 'domain') and request.domain:
        context['domain'] = request.domain

        try:
            if hasattr(request, 'org'):
                template = BillpayTemplateConfig.objects.get(template_key='branding', org=request.org.get('id'))
                context['branding_template_content'] = mark_safe(template.template_html_content)
        except BillpayTemplateConfig.DoesNotExist:
            pass
    else:
        # If there is not a domain in the request, go ahead and return here.
        return context

    if hasattr(request, 'is_mobile') and request.is_mobile:
        context['STANDARD_LINK'] = build_standard_uri(request, ensure_ver=True)
    elif hasattr(request, 'is_tablet') and request.is_tablet:
        root_uri = get_root_uri_standard(request)
        context['MOBILE_LINK'] = build_mobile_uri(request, ensure_ver=True, root_uri=root_uri)
        context['STANDARD_LINK'] = build_standard_uri(request, ensure_ver=True)
    else:
        # Default to the standard view if nothing else is detected
        root_uri = get_root_uri_standard(request)
        context['MOBILE_LINK'] = build_mobile_uri(request, ensure_ver=True, root_uri=root_uri)

    if hasattr(request, 'org'):
        context['org'] = request.org

    # Check if user is using Internet Explorer version 10 or below. If yes, set
    # context variable 'IE10_OR_BELOW' to True.
    browser_user_agent = request.META.get('HTTP_USER_AGENT')
    if browser_user_agent:
        parsed_user_agent_string = user_agent_parser.Parse(browser_user_agent)
        browser_family = parsed_user_agent_string['user_agent']['family']
        browser_version_number = parsed_user_agent_string['user_agent']['major']

        if browser_family == 'IE' and int(browser_version_number) <= 10:
            context['IE10_OR_BELOW'] = True

    return context
