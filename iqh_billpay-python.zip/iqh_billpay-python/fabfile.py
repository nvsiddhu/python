# -*- coding: utf-8 -*-

"""
Usage:
Run this to fire up or update an instance of Billpay. Ideally we'd always have at least
two instances running in-house to simulate production.

1. create iqh_billpay virtual_env as per installation instructions and install billpay.
2. create a set of rhel 6 boxes
    2 app servers
    1 cache box
    (If needed less boxes can be used, just overlapp them)
3. Make sure your IP address is mapped properly in external or internal DNS (dox.hax/dns)
    Update envs.py with appropriate box names
4. Initial install and update
For dev:
   fab dev release
For cert:
   fab cert release
For sandbox:
   fab sandbox release
For prod:
   fab prod release
5. Enjoy!

To update the hosts file
  fab prod update_hosts_file
"""

import datetime
import os

from axiom_core.simpleids import random_id
from axiom_fabric.api import sudo_ve
from axiom_fabric.api import pip_install
from fab_updater import get_installer
from fabric import api
from fabric.api import hide
from fabric.api import settings
from fabric.api import env
from fabric.api import put

from fabric.decorators import runs_once
from fabric.decorators import task
from fabric.decorators import roles
from fabric.operations import local
from fabric.operations import sudo
from fabric.contrib.files import sed, append, exists
from fabric.contrib.project import upload_project

from release.envs import dev, cert, stage, prod
from release.utils import timed_execute
from portal_release.audit import audit_release

VIRTUAL_ENV = 'iqh_billpay'
PROJECT_NAME = 'iqh_billpay'


@task
def release(ve=VIRTUAL_ENV):
    """ Install or update all boxes """

    bootstrap = api.env.get('bootstrap')
    if not bootstrap:
        raise Exception('Please specify a bootstrapper script for {0}.'.format(api.env))

    start = datetime.datetime.utcnow()
    bootstrap(ve)
    timed_execute(_update_hosts_file, roles=['webapp'])

    result = timed_execute(ensure_aes_secret, roles=['first_webapp'])
    aes_secret = result.values()[0]

    # first webapp needs the new code to publish themes.
    # install the new code but do not start the app. The following update_app
    # function will restart it. We also need to set the aes_secret because the settings
    # are loaded when the update_themes management command runs.
    timed_execute(update_app, restart_app=False, aes_secret=aes_secret, roles=['first_webapp'])
    timed_execute(generate_staticfiles)
    timed_execute(push_staticfiles, roles=['static_proxy', 'webapp'])
    timed_execute(update_themes, roles=['first_webapp'])

    timed_execute(update_app, aes_secret=aes_secret, roles=['webapp'])
    timed_execute(configure_proxy, roles=['proxy'])

    end = datetime.datetime.utcnow()


@task
def update_hosts_file():
    """ Task to update the only the host files on the webapp boxes. """
    timed_execute(_update_hosts_file, roles=['webapp'])


@task
def quickpay_down_planned():
    """Start a planned downtime by copying the planned downtime nginx conf to /etc/nginx"""

    timed_execute(start_planned_downtime, roles=['proxy'])


@task
def quickpay_down():
    """Start an unplanned downtime by copying the unplanned downtime nginx conf to /etc/nginx"""
    timed_execute(start_downtime, roles=['proxy'])


@task
def quickpay_up():
    """Stop a downtime by copying the regular nginx conf to /etc/nginx"""
    timed_execute(stop_downtime, roles=['proxy'])


@task
@roles('webapp')
def update_db_connection_settings(old_param, new_param, file_path):
    """
    Updates the Databases settings in sensitive_settings.
    * Example usage: fab <env> update_connection_settings:<old_param>,<new_param>
    * So for changing user name of database settings in dev environment, run:
        fab dev update_db_connection_settings:"'USER': 'Billpay'","'USER': 'new_user'",\/opt\/djangoprojects\/iqh_billpay\/sensitive_settings.py
    NOTE: if the old_param/new_param/file_path has any special characters escape those.
    Example: fab dev update_db_connection_settings:'https:\/\/billpay.com\/oauth\/access',change_to_something,\/opt\/djangoprojects\/iqh_billpay\/sensitive_settings.py
    """
    stop_app()
    sudo("sed -i \"s/{0}/{1}/g\" {2}".format(old_param, new_param, file_path))
    start_app()


def start_downtime():
    conf = 'iqh_billpay_nginx_unplanned_downtime.conf'
    api.sudo('ln -fs /etc/nginx/down_sites/{0} /etc/nginx/conf.d/nginx.conf'.format(conf))
    reload_nginx()


def start_planned_downtime():
    conf = 'iqh_billpay_nginx_planned_downtime.conf'
    api.sudo('ln -fs /etc/nginx/down_sites/{0} /etc/nginx/conf.d/nginx.conf'.format(conf))
    reload_nginx()


def stop_downtime():
    conf = 'iqh_billpay_nginx.conf'
    api.sudo('ln -fs /etc/nginx/up_sites/{0} /etc/nginx/conf.d/nginx.conf'.format(conf))
    reload_nginx()


def update_app(restart_app=True, aes_secret=None):
    """
    Install or update code and settings for the app box.

    restart_app: If True, restart the app when the installation or update is complete.
                 If False, the app will remain stopped.
    aes_secret: The secret used to encrypt session data in billpay. If not None, then
                sets a new secret overwriting the previous key (if any).
    """

    stop_app()
    update_site_code()
    uninstall_old_deps()
    install_deps()
    configure_settings()
    configure_aes_secret(aes_secret)
    configure_iqh_billpay_logs()
    configure_gunicorn_logs()
    configure_supervisor()

    if restart_app:
        start_app()


def update_site_code():
    api.sudo('rm -rf /opt/djangoprojects/{0}'.format(PROJECT_NAME))
    api.sudo('mkdir -p /opt/djangoprojects/')
    with api.cd('/opt/djangoprojects/'):
        api.sudo('svn checkout {0}{1}/'.format(api.env['iqh_svn_root'],
                                               PROJECT_NAME))

def uninstall_old_deps(ve=VIRTUAL_ENV):
    with settings(warn_only=True):
        # example: sudo_ve('pip uninstall -y A_PACKAGE', ve)
        sudo_ve('pip uninstall -y axiom_django_recaptcha', ve)
        pass

def install_deps(ve=VIRTUAL_ENV, ve_base="/opt/.virtualenvs/"):
    """
    This function is used to update the svn deps for iqh_billpay.
    """
    pip_install('patient-portal-dependencies-1.1.0.tar.gz', ve)

    activate_env = 'source {ve_base}{ve}/bin/activate'.format(ve_base=ve_base, ve=VIRTUAL_ENV)
    fab_updater = "python /opt/djangoprojects/iqh_billpay/fab_updater.py"
    api.sudo('{0} && {1} --tar_gz_download_root "{2}"'.format(
        activate_env,
        fab_updater,
        api.env['http_download_root']
    ))

    #updated svn deps
    iqhbp_svn_projects = get_installer()._get_svn_deps()

    for project in iqhbp_svn_projects:
        with settings(warn_only=True):
            sudo_ve("pip uninstall -y {0}".format(project), ve)

    # Generate and execute the requirements file for svn dependencies
    reqs = ''.join(['svn+{0}{1}\n'.format(api.env['iqh_svn_root'], dep) for dep in iqhbp_svn_projects])

    with open('svn_requirements.txt', 'w') as f:
        f.write(reqs)
    put('svn_requirements.txt', remote_path='/opt/djangoprojects/iqh_billpay', use_sudo=True, mode=0755)
    sudo_ve('pip install --ignore-installed --no-dependencies -r /opt/djangoprojects/iqh_billpay/svn_requirements.txt', ve)


def configure_settings():
    """
    Configure deployment_settings.
    """

    config_dest_folder = '/opt/djangoprojects/{0}'.format(PROJECT_NAME)
    config_source_folder = '/opt/djangoprojects/{0}/config/{1}/*'.format(PROJECT_NAME,
                                                                         api.env.env_type)
    api.sudo('cp -r -s -f {source} {dest}'.format(source=config_source_folder,
                                                  dest=config_dest_folder))


def configure_aes_secret(aes_secret=None):
    """
    Overwrites the config file with the aes secret if secret is not None.
    Otherwise, don't do anything.
    """
    if aes_secret:
        aes_secret_path = '/etc/sysconfig/django-aes-secret'
        if exists(aes_secret_path, use_sudo=True):
            sudo('rm {0}'.format(aes_secret_path))

        with settings(hide('everything')):
            append(aes_secret_path, '[secrets]\nAES_SECRET_KEY: {0}'.format(aes_secret), use_sudo=True)

        # change group from root to nobody so gunicorn can access the secret
        sudo('chown :nobody {0}'.format(aes_secret_path))

        # don't allow others to read the secret besides the nobody user and root
        sudo('chmod 640 {0}'.format(aes_secret_path))


def configure_proxy(reload_nginx_on_change=True):
    """Uploads domain specific static files to the nginx server.

    Populates the /etc/nginx/up_sites and /etc/nginx/down_sites folder
    for iqh billpay config.

    The items in these folders can be symlinked into the /etc/nginx/ folder
    to take specific sites up and down.

    This method will not overwrite current up/down statuses and should be safe to use.

    Note that on an invalid nginx configuration, nginx will detect the error on reload
    and fail to restart.
    """
    upload_domain_specific_static_files()

    api.sudo('mkdir -p /etc/nginx/up_sites')
    api.sudo('mkdir -p /etc/nginx/down_sites')

    nginx_config = 'nginx_config/' + env['env_type']

    put('{0}/up_sites/*'.format(nginx_config), remote_path='/etc/nginx/up_sites', use_sudo=True, mode=0755)
    put('{0}/down_sites/*'.format(nginx_config), remote_path='/etc/nginx/down_sites', use_sudo=True, mode=0755)

    api.sudo('chkconfig nginx on')
    if reload_nginx_on_change:
        reload_nginx()


def configure_supervisor():
    """
    Configures supervisord
    """
    #ensure that supervisord is correctly configured
    supervisord_init = "/opt/djangoprojects/iqh_billpay/install/supervisord"
    sudo('cp -s -f {source} /etc/init.d'.format(source=supervisord_init))
    sudo('chmod +x /etc/init.d/supervisord')

    supervisord_conf = "/opt/djangoprojects/iqh_billpay/install/supervisord.conf"
    sudo('cp -s -f {source} /etc/'.format(source=supervisord_conf))

    sudo('/sbin/chkconfig --add supervisord')
    sudo('/sbin/chkconfig supervisord on')


def configure_iqh_billpay_logs():
    sudo('mkdir -p /var/log/web_apps')
    sudo('chmod -R 777 /var/log/web_apps')

    for solution in ['iqh_billpay', 'iqh_billpay_access']:
        sudo('touch /var/log/web_apps/{0}.log'.format(solution))
        sudo('chmod 777 /var/log/web_apps/{0}.log'.format(solution))

    sudo('mkdir -p /etc/rsyslog.d/')
    append('/etc/rsyslog.conf', '$IncludeConfig /etc/rsyslog.d/*.conf', use_sudo=True)
    put('install/rsyslog.conf', '/etc/rsyslog.d/billpay.conf', use_sudo=True)
    sudo('service rsyslog restart')

    put('install/logrotate/billpay', '/etc/logrotate.d/billpay', use_sudo=True)


def configure_gunicorn_logs():
    sudo('mkdir -p /var/log/gunicorn')

    sudo('touch /var/log/gunicorn/iqh_billpay_error.log')
    sudo('chmod 666 /var/log/gunicorn/iqh_billpay_error.log')

    put('install/logrotate/gunicorn', '/etc/logrotate.d/gunicorn', use_sudo=True)


@runs_once
def update_themes():
    """
    Generates and pushes billpay themes. Be sure the app has the updated site code or collectstatic will
    run on the old site code.
    """
    force_option = ''
    # force themes to be published in dev/cert because we don't actively bump up the moonpie.theming version after every deploy
    if api.env.env_type in ('dev', 'cert'):
        force_option = '--force'

    sudo_ve('python /opt/djangoprojects/iqh_billpay/manage.py release_themes iqh_billpay {0}'.format(force_option), VIRTUAL_ENV)


def stop_app():
    """
    Stops the app servers (Gunicorn).

    Note, supervisord is configured to run a graceful shutdown on gunicorn by sending
    a TERM signal.
    """
    # Attempt to stop, don't worry if there are issues, this may be the first
    # run or the app could already be down.
    with settings(warn_only=True):
        sudo('service supervisord stop')


def start_app():
    """
    Starts app servers (Gunicorn).
    """

    sudo('service supervisord start')


def reload_nginx():
    result = sudo('service nginx configtest')
    if 'test failed' not in result:
        with settings(warn_only=True):
            nginx_status = sudo('service nginx status')
        if 'stopped' in nginx_status or 'dead' in nginx_status:
            api.sudo('/sbin/service nginx start')
        else:
            api.sudo('/sbin/service nginx reload')
    else:
        raise Exception('ERROR. nginx configtest failed with result: ' + result)


def _update_hosts_file():
    '''
    Append the vision center ips to the hosts file due to dns issues
    '''
    sed('/etc/hosts', '39.159.157.21  uscert.vccerner.com', '39.159.157.21  vccustom.vccerner.com', use_sudo=True)
    append('/etc/hosts', '39.159.157.21  vccustom.vccerner.com', use_sudo=True)
    append('/etc/hosts', '39.159.157.27  uspres.vccerner.com', use_sudo=True)
    append('/etc/hosts', '39.159.157.19  ustest.vccerner.com', use_sudo=True)
    append('/etc/hosts', '39.159.157.84  sttestcert.vccerner.com', use_sudo=True)
    append('/etc/hosts', '39.159.157.85  stprod.vccerner.com', use_sudo=True)
    append('/etc/hosts', '39.159.157.80  sprod.vccerner.com', use_sudo=True)

    if api.env['env_type'] == 'stage':
        append('/etc/hosts', '2.83.0.14  cernpodr01.shmem.hosp', use_sudo=True)
        append('/etc/hosts', '2.83.0.20  cernpodr81.shmem.hosp', use_sudo=True)
        append('/etc/hosts', '2.83.0.21  Secureodr85.sheridanhospital.org', use_sudo=True)
        append('/etc/hosts', '2.83.0.20 cernpodr81.shmem.hosp cernpodr81', use_sudo=True)
        append('/etc/hosts', '2.83.0.14 cernpodr01.shmem.hosp', use_sudo=True)
        append('/etc/hosts', '2.83.0.20 cernpodr81.shmem.hosp', use_sudo=True)
        append('/etc/hosts', '2.83.0.21 Secureodr85.sheridanhospital.org', use_sudo=True)
        append('/etc/hosts', '2.192.7.44  mchmockodr02.mch.corp.int', use_sudo=True)
    elif api.env['env_type'] == 'prod':
        append('/etc/hosts', '2.83.0.15  cerpodr00.shmem.hosp', use_sudo=True)
        append('/etc/hosts', '2.83.0.21  cerpodr80.shmem.hosp cerpodr80', use_sudo=True)
        append('/etc/hosts', '2.83.0.17  cerpodr81.shmem.hosp cerpodr81', use_sudo=True)
        append('/etc/hosts', '2.192.7.43  mchprododr02.mch.corp.int', use_sudo=True)


def ensure_aes_secret():
    """
    Returns the first webapp's secret if it exists.
    Otherwise, generates a new secret.
    """
    aes_secret_path = '/etc/sysconfig/django-aes-secret'
    if exists(aes_secret_path, use_sudo=True):

        with settings(hide('everything'), warn_only=True):
            result = sudo('grep -rw AES_SECRET_KEY {0}'.format(aes_secret_path))

        if not result.failed:
            # ensure secret is 32 characters long
            secret = result.replace('AES_SECRET_KEY: ', '')
            if len(secret) == 32:
                return secret

    return random_id(32)


"""
commands for processing static assets
"""
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
LOCAL_STATIC_ROOT = os.path.join(APP_ROOT, 'static_deploy')


@runs_once
def generate_staticfiles():
    """
    Generate static files locally before pushing to the app and proxy boxes
    for the current environment.
    """
    local("mkdir -p {0}".format(LOCAL_STATIC_ROOT))
    #Compilejsi18n needs to run before collectstatic for the files to be hashed correctly
    #Extracts js translations, formats from the django jsi18n resource into static js files with django-staticjsi18n
    local("python manage.py compilejsi18n")
    local("cd {0} && python manage.py collectstatic --noinput -i *.less".format(APP_ROOT))


def push_staticfiles():
    """
    rsync staticfiles to the currently active fabric host with the currently
    active user and specified remote directory.
    """
    # Ensure remote target folders
    remote_static_dir = '/opt/djangoprojects/billpay-static'
    sudo("mkdir -p {0}".format(remote_static_dir))
    sudo("chmod -R 775 {0}".format(remote_static_dir))
    sudo("chgrp -R wheel {0}".format(remote_static_dir))

    # Deploy staticfiles!
    upload_project(local_dir=LOCAL_STATIC_ROOT)
    with api.cd("static_deploy"):
        sudo("cp -rf * {0}".format(remote_static_dir))

    api.run('rm -rf static_deploy')


def upload_domain_specific_static_files():
    """
    To serve the standard static files to the proxy boxes.
    robots.txt, apple-touch-icon.png, favicon.ico
    """
    api.sudo('mkdir -p /etc/nginx/static')
    api.sudo('mkdir -p /etc/nginx/static/img')
    put('static/maintenance/planned.html', remote_path='/etc/nginx/static/planned.html', use_sudo=True, mode=0755)
    put('static/maintenance/unplanned.html', remote_path='/etc/nginx/static/unplanned.html', use_sudo=True, mode=0755)
    put('static/robots.txt', remote_path='/etc/nginx/static/robots.txt', use_sudo=True, mode=0755)
    put('static/img/favicon.ico', remote_path='/etc/nginx/static/img/favicon.ico', use_sudo=True, mode=0755)
    put('static/img/apple-touch-icon.png', remote_path='/etc/nginx/static/img/apple-touch-icon.png', use_sudo=True, mode=0755)
