# -*- coding: utf-8 -*-

from fabric import api
from fabric.decorators import task
from bootstrap.rhel6 import bootstrap as rhel6

AXIOM_SVN_DOWNLOAD_ROOT = 'http://scm.healthe-axiom.cerner.corp/svn/axiom-python-services/trunk/'
RPM_DOWNLOAD_ROOT = AXIOM_SVN_DOWNLOAD_ROOT + 'ext/rpm_rhel6/'
TGZ_DOWNLOAD_ROOT = AXIOM_SVN_DOWNLOAD_ROOT + 'ext/tgz/'


@task
def dev():
    """For trunkiqhbp.hax """
    api.env['env_type'] = 'dev'
    api.env['iqh_svn_root'] = 'http://scm.iqhealth-emr.cerner.corp/svn/python/trunk/'
    api.env['axiom_svn_root'] = AXIOM_SVN_DOWNLOAD_ROOT
    api.env['bootstrap'] = rhel6

    _add_internal_download_env()

    api.env.roledefs.update({
        'first_webapp': ['bpapp01.dev.hax'],
        'webapp': ['bpapp01.dev.hax', 'bpapp02.dev.hax'],
        'cache': ['bpapp01.dev.hax'],
        'proxy': ['proxybp01.dev.hax', 'proxybp02.dev.hax'],
        'static_proxy': ['proxy.dev.hax']
    })
    _set_skyboxlabs_auth()


@task
def cert():
    """For certiqhbp.hax """
    api.env['env_type'] = 'cert'
    api.env['iqh_svn_root'] = 'http://scm.iqhealth-emr.cerner.corp/svn/python/branches/go/'
    api.env['axiom_svn_root'] = AXIOM_SVN_DOWNLOAD_ROOT
    api.env['bootstrap'] = rhel6

    _add_internal_download_env()

    api.env.roledefs.update({
        'first_webapp': ['bpapp01.cert.hax'],
        'webapp': ['bpapp01.cert.hax', 'bpapp02.cert.hax'],
        'cache': ['bpapp01.cert.hax'],
        'proxy': ['proxybp01.cert.hax', 'proxybp02.cert.hax'],
        'static_proxy': ['proxy.cert.hax']
    })
    _set_skyboxlabs_auth()


@task
def stage():
    api.env['env_type'] = 'stage'
    api.env['bootstrap'] = rhel6

    _add_internal_download_env()

    api.env.roledefs.update({
        'first_webapp': ['cerniqhqpapp101'],
        'webapp': ['cerniqhqpapp101', 'cerniqhqpapp102'],
        'cache': ['cerniqhqpapp101'],
        'proxy': ['cerniqhqpproxy101', 'cerniqhqpproxy102'],
        'static_proxy': ['CERNCWPPROXY01']
    })


@task
def prod():
    api.env['env_type'] = 'prod'
    api.env['bootstrap'] = rhel6
    api.env['audit_svn_location'] = 'http://scm.iqhealth-emr.cerner.corp/svn/python/branches/go/release_artifacts/iqh_billpay'

    _add_internal_download_env()

    api.env.roledefs.update({
        'first_webapp': ['cerniqhqpapp201'],
        'webapp': ['cerniqhqpapp201', 'cerniqhqpapp202', 'cerniqhqpapp203', 'cerniqhqpapp204'],
        'cache': ['cerniqhqpapp201'],
        'proxy': ['cerniqhqpproxy201', 'cerniqhqpproxy202'],
        'static_proxy': ['CERNCWPPROXY02', 'CERNCWPPROXY03']
    })


def _add_internal_download_env():
    api.env['tgz_download_root'] = TGZ_DOWNLOAD_ROOT
    api.env['http_download_root'] = TGZ_DOWNLOAD_ROOT
    api.env['rpm_download_root'] = RPM_DOWNLOAD_ROOT


def _set_skyboxlabs_auth():
    api.env.user = 'test'
    api.env.password = 'Cerner01'
