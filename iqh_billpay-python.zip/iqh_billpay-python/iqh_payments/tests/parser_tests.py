# -*- coding: utf-8 -*-

import unittest

from iqh_payments.parsers import parse_payment_status, has_been_charged
from iqh_payments.types import PaymentStatus


class TestParsePaymentStatus(unittest.TestCase):

    def parse_successful_payment_response_test(self):
        """
        parse_payment_status should return a paymentStatus object that has
        an interchanged_id, approval_code, amount_requested, amount_charged,
        and a successful code but no error_message when a successful payment
        response is returned.
        """
        json_data = {
            'ack': {
                'statusCode': '00',
                'interchangeId': '12345',
                'approvalCode': '67890',
                'amountRequested': '20.00',
                'amount': '10.00'
            }
        }

        status = parse_payment_status(json_data)
        self.assertEquals(type(status), PaymentStatus)
        self.assertEquals(status.code, '00')
        self.assertEquals(status.interchange_id, '12345')
        self.assertEquals(status.approval_code, '67890')
        self.assertEquals(status.amount_charged, '10.00')
        self.assertEquals(status.amount_requested, '20.00')
        self.assertTrue(status.charged)
        self.assertIsNone(status.error_message)

    def parse_unsuccessful_payment_response_test(self):
        """
        parse_payment_status should return a payment status with an error_message
        and an error code when a non successful payment response is returned.
        """
        json_data = {
            'ack': {
                'interchangeId': '12345',
                'errors': {
                    'error': [{
                        'errorCode': 'S3',
                        'errorMsg': 'Unacceptable Card type'
                    }]
                }
            }
        }

        status = parse_payment_status(json_data)
        self.assertEquals(type(status), PaymentStatus)
        self.assertEquals(status.code, 'S3')
        self.assertEquals(status.interchange_id, '12345')
        self.assertIsNone(status.approval_code)
        self.assertIsNone(status.amount_charged)
        self.assertIsNone(status.amount_requested)
        self.assertFalse(status.charged)
        self.assertEquals(status.error_message, 'Unacceptable Card type')


class TestIsSuccessfulPayment(unittest.TestCase):

    def test_successful_payment_status(self):
        """
        has_been_charged should return True when
        the response returns an approval code, an amount,
        and a status code of 00.
        """

        ack_data = {
            'interchangeId': '12345',
            'statusCode': '00',
            'approvalCode': '67890',
            'amountRequested': '20.00',
            'amount': '10.00'
        }

        self.assertTrue(has_been_charged(ack_data))

    def test_successful_payment_status_for_partial_amount_approved(self):
        """
        has_been_charged should return True when
        the response returns an approval code, an amount,
        and a status code of 02.
        """

        ack_data = {
            'interchangeId': '12345',
            'statusCode': '02',
            'approvalCode': '67890',
            'amountRequested': '20.00',
            'amount': '10.00'
        }

        self.assertTrue(has_been_charged(ack_data))

    def test_with_errors(self):
        """
        has_been_charged should return False when the
        response contains errors.
        """
        ack_data = {
            'interchangeId': '12345',
            'errors': {
                'error': [{
                    'errorCode': 'S3',
                    'errorMsg': 'declined'
                }]
            }
        }

        self.assertFalse(has_been_charged(ack_data))

    def test_no_interchange_id(self):
        """
        has_been_charged should return True when the data
        does not have an interchange_id but all the other data
        that deems the response as successful is present.
        """
        ack_data = {
            'statusCode': '00',
            'approvalCode': '67890',
            'amountRequested': '20.00',
            'amount': '10.00'
        }

        self.assertTrue(has_been_charged(ack_data))

    def test_no_status_code(self):
        """
        has_been_charged should return False when the data
        does not have a status code.
        """
        ack_data = {
            'interchangeId': '12345',
            'amountRequested': '20.00',
            'approvalCode': '67890',
            'amount': '10.00'
        }

        self.assertFalse(has_been_charged(ack_data))

    def test_non_successful_status_code(self):
        """
        has_been_charged should return False when the data
        does not have a successful status code.
        """
        ack_data = {
            'interchangeId': '12345',
            'statusCode': '01',  # declined
            'amountRequested': '20.00',
            'approvalCode': '67890',
            'amount': '10.00'
        }

        self.assertFalse(has_been_charged(ack_data))

    def test_no_amount_requested(self):
        """
        has_been_charged should return True when the data
        does not have amount requested but all the other data
        that deems the response as successful is present.
        """
        ack_data = {
            'interchangeId': '12345',
            'statusCode': '00',
            'approvalCode': '67890',
            'amount': '10.00'
        }

        self.assertTrue(has_been_charged(ack_data))

    def test_no_approval_code(self):
        """
        has_been_charged should return False when the data
        does not have a approval code.
        """
        ack_data = {
            'interchangeId': '12345',
            'statusCode': '00',
            'amountRequested': '20.00',
            'amount': '10.00'
        }

        self.assertFalse(has_been_charged(ack_data))

    def test_no_amount_charged(self):
        """
        has_been_charged should return False when the data
        does not have amount charged.
        """
        ack_data = {
            'interchangeId': '12345',
            'statusCode': '00',
            'approvalCode': '67890',
            'amountRequested': '20.00',
        }

        self.assertFalse(has_been_charged(ack_data))
