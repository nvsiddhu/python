# -*- coding: utf-8 -*-

from django.core.management import base
from iqh_configurations import configuration_enums
from iqh_configurations import configurations
from iqh_domains import domains
from iqh_organizations import organizations


domains_to_add = dict()
domains_to_add['localiqhbillpay.com'] = {
    'domain_name': 'localiqhbillpay.com',
    'res_domain': 'iqhbillpay.com',
    'text': 'Local Billpay',
    'description': 'Test site for Billpay',
    'keywords': 'billpay',
    'site_root_uri': 'http://localiqhbillpay.com:8019/',
    'ch_api_client_id': 'test',
    'ch_api_client_secret': 'test',
    'created_id': 'init_local_data.py',
    'support_email': 'support@localiqhbillpay.com',
    'support_phone': '1-877-621-8014',
    'notification_email': 'LocalIQHBillPay.com <noreply@localiqhbillpay.com>',
    'domain_id': 'localiqhbillpay.com',
    'default_org': 'baseline-south'
}

orgs = dict()
orgs['baseline-south'] = {
    'slug': 'baseline-south',
    'name': 'Baseline South',
    'domain': 'localiqhbillpay.com',
    'domain_id': 'localiqhbillpay.com',
    'java_context_root': 'iqh2',
    'small_logo_url': 'http://iqhwhiteboxphr.northamerica.cerner.net:8002/healthe/baseline-north-small.png',
    'large_logo_url': 'http://iqhwhiteboxphr.northamerica.cerner.net:8002/healthe/baseline-north-large.png',
    'time_zone': 'America/Chicago'
}

configs = dict()
configs['baseline-south'] = {
    configuration_enums.CAREAWARE_SERVICE: {
        'service_directory_url': 'https://directory.devcareaware.com/services-directory',
        'consumer_key': 'com.cerner.iqhealth',
        'consumer_secret': 'JOatjd/i5neMUviAsHgj+STA50wh6uFYKeZife4TdT1Uqo7yPeuUwnzEbpb9eizlP/0ASyW6F+hnMAyvW7N0xa01QYaI5WTQQ6zRrjsdqZdJIHSmvQT6vEN0BLfCCnAw8+XrbNNQmZPAZ5AXuel5xokL6Zm9uf2MB7OS3Im6fjs=',
        'domain': 'intgm.northamerica.cerner.net',
        'client_mnemonic': 'CERN_KCM'
    },
    configuration_enums.GLOBAL: {'time_zone': 'America/Chicago'}
}


class Command(base.NoArgsCommand):
    help = """Sets up starter data for local development."""

    def handle_noargs(self, **options):

        def ensure_domain_build():
            for d in domains_to_add.itervalues():
                domain_name = d['domain_name']
                domain = domains.get(domain_name)
                if domain:
                    # TODO: eventually probably want to do an update here
                    print 'Already built domain: {0}'.format(domain_name)
                else:
                    domains.add(d)
                    print 'Added domain: {0}'.format(domain_name)

        def ensure_config_build():
            for org_slug, org_config in configs.items():
                for config_type, config in org_config.items():
                    configurations.ensure(config_type, config, 'init_local_data.py', org_slug)
                    print 'Ensured {0} config for {1}'.format(config_type, org_slug)

        def ensure_org_build():
            for org in orgs.itervalues():
                org_obj = organizations.get_by_slug(org['slug'])
                try:
                    domain = domains.get(org['domain'])
                    org['domain_id'] = domain['id']
                except:
                    org['domain_id'] = None
                if org_obj:
                    # TODO: eventually probably want to do an update here
                    print 'Already built org: {0}'.format(org['slug'])
                else:
                    organizations.add(org)
                    print 'Added org: {0}'.format(org['slug'])

        ensure_domain_build()
        ensure_org_build()
        ensure_config_build()
