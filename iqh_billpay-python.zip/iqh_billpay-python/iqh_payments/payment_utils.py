# -*- coding: utf-8 -*-

from django.utils.translation import ugettext as _

"""
Utility methods for working with the payment backend.
"""


def parse_card_type(abbr_card_type):
    """
    Parses the abbreviated card type and returns the credit card type.

    @return the credit card type. Possible values are: 'Visa', 'Mastercard',
            'Discover' or 'American Express'. Returns None if the card type is
            not a recognized type.

    Example usage::

        >>> from iqh_payments.payment_utils import parse_card_type
        >>> parse_card_type('V')
        u'Visa'
        >>> parse_card_type('M')
        u'Mastercard'
        >>> parse_card_type('R')
        u'Discover'
        >>> parse_card_type('X')
        u'American Express'
        >>> parse_card_type('T') is None
        True

    """
    if abbr_card_type == 'V':
        return _('Visa')

    if abbr_card_type == 'M':
        return _('Mastercard')

    if abbr_card_type == 'X':
        return _('American Express')

    if abbr_card_type == 'R':
        return _('Discover')

    return None
