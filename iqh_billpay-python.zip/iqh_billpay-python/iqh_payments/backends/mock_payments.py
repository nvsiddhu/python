# -*- coding: utf-8 -*-

"""
Mock Implementation of IQHealth payments.

Configure this by adding the following to the django settings (likely your
my_settings.py file)::

    IQH_PAYMENTS_BACKEND = 'iqh_payments.backends.mock_payments'

# TODO: Add testing scenarios for mock_data when we have time to mock the request token service.
"""
from base import BasePaymentBackend

import datetime

# Mapping of payment_receiver_id values to supported credit card types
ALL_CREDIT_CARDS = {"mastercard": True, "visa": True, "american_express": True,
                    "discover": True}

ACCOUNT = {
    'id': '1234',
    'account_number': '123456789',
    'masked_account_number': 'XXXXXX789',
    'patient_name': 'John Smith',
    'facility': 'Baseline Accepts All Cards',
    'last_payment_amount': None,
    'last_payment_date': None,
    'amount_due': 1995.98,
    'bad_debt_amount': 0,
    'payment_receiver_id': 'SUBMITTER_TSEP'
}


class PaymentBackend(BasePaymentBackend):

    def __init__(self, **kwargs):
        pass

    def get_guarantor_id(self, org_slug, access_code, last_name, birth_date):
        return 'g_1'

    def get_accounts(self, org_slug, guarantor_id):
        return [ACCOUNT]

    def get_account(self, org_slug, guarantor_id, account_id):
        return ACCOUNT

    def get_supported_payment_types_and_merchant_id(self, org_slug, payment_receiver_id, guarantor_id, account_id):
        return ALL_CREDIT_CARDS, 'merchant_id'

    def get_merchant(self, org_slug, payment_receiver_id, guarantor_id, account_id):
        return {'merchant_id': '123',
                'manifest': '05a05a8d0e8470fc0f844a37e2a11c8f92623277e62d2a6dac468e6f1102fc6e3a82e139d156e99f663e13ba0c2509a3b21761996c4e7704bb80535eae99a7c5aac14063',
                'device_id': '88880000006804',
                'payment_types': ALL_CREDIT_CARDS}

    def create_payment(self, base_payment_url, oauth_client, org_slug, guarantor_id, account_id, amount, payer_name):
        return 'payment_id'

    def charge_by_token(self, org_slug, guarantor_id, account_id, payment_receiver_id, amount, payer_name,
                        street_address, city, state, postal_code, interchange_id, card_number, card_type,
                        expiration_date, merchant_id, token_reference_id):

        return ('success', {'payment_id': 'payment_id'})

    def check_payment_status(self, org_slug, guarantor_id, account_id,
                             payment_id, payment_receiver_id, card_type):
        return ('success', {'payment_id': payment_id})

    def get_payment(self, org_slug, guarantor_id, account_id, payment_id):

        return {'receipt_number': 'r' + payment_id,
                'amount': 997.44,
                'payment_date': datetime.datetime.utcnow(),
                'account_number': '4444-4444-442',
                'masked_account_number': 'XXXX-XXXX-442',
                'patient_name': 'Jane Smith',
                'payer_name': 'Smith, John',
                'payee_name': 'Baseline South',
                'payee_address_line_1': '123 Main St.',
                'payee_city': 'Kansas City',
                'payee_state': 'MO',
                'payee_postal_code': '64117',
                'payee_phone': '8165557654',
                'merchant_id': '123456789',
                'card_number': '************1234',
                'expiration_date': '05/2019',
                }

    def _validate_org(self, org_slug):
        if not org_slug:
            raise Exception("pass in an org slug yo!!!")

        org_slug = org_slug.strip()
        if not org_slug:
            raise Exception("pass in a non-empty org slug yo!!!")

    def _build_statsd_keys(self, statsd_client_key, org_slug=None):
        # Build the statsd keys for all-orgs and the current org
        statsd_key_template = (u'quickpay.{org_slug}.clients.' +
                statsd_client_key)
        statsd_keys = [statsd_key_template.format(org_slug='all_orgs')]
        if org_slug:
            statsd_keys.append(statsd_key_template.format(org_slug=org_slug))

        return statsd_keys
