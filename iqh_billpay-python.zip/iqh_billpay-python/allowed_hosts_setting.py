# -*- coding: utf-8 -*-

"ALLOWED_HOSTS in portal is dynamic and needs to be resolved at runtime from the domain model"
from django.conf import settings


class AllowedHosts(object):
    "Iterable for domain names that can serve requests."
    def __iter__(self):
        # import needs to be inside generator because settings cannot import models
        from iqh_domains.models import Domain
        for domain in Domain.objects.values('domain_name'):
            yield domain['domain_name']

        # allow the root domain to an allowed HTTP host so we can use the domain
        # to publish themes from moonpie. Any other url outside of /api/theming
        # will raise a 404
        if settings.DEPLOYMENT_MODE in ('stage'):
            yield 'sandboxpaymyhealthbill.com'

        elif settings.DEPLOYMENT_MODE in ('prod'):
            yield 'paymyhealthbill.com'


ALLOWED_HOSTS = AllowedHosts()
