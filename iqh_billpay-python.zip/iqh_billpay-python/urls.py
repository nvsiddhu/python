# -*- coding: utf-8 -*-

from axiom_django.dispatcher import dispatch
from django.conf import settings
from django.conf.urls.defaults import patterns, url, include
from django.core.urlresolvers import reverse
from django.shortcuts import redirect

from views import LogoutView, AccountPaymentView, ConfirmPaymentView, TSEPAccountPaymentView

handler500 = 'views.server_error'
handler404 = 'views.not_found'

urlpatterns = patterns('',
    url(r'^keep-alive/?$', dispatch(get='views.keep_alive'),
        name='keep_alive'),
    url(r'^health-check/?$', dispatch(get='views.health_check'),
        name='health_check'),
    url(r'^quickpay/accounts/?$', dispatch(get='views.view_accounts'),
        name='view_accounts'),
    url(r'^quickpay/accounts/(?P<account_id>.+)/pay/?$',
        AccountPaymentView.as_view(),
        name='account_payment'),
    url(r'^quickpay/accounts/(?P<account_id>.+)/tsep/?$',
        TSEPAccountPaymentView.as_view(),
        name='tsep'),
    url(r'^quickpay/accounts/(?P<account_id>.+)/confirm/?$',
        ConfirmPaymentView.as_view(),
        name='confirm_payment'),
    url(r'^quickpay/accounts/(?P<account_id>.+)/payment/(?P<payment_id>.+)/email/?$',
        dispatch(post='views.email_receipt'),
        name='email_receipt'),
    url(r'^quickpay/accounts/(?P<account_id>.+)/payment/(?P<payment_id>.+)/?$',
        dispatch(get='views.payment', post='views.payment'),
        name='payment'),
    url(r'^quickpay/?$', dispatch(get='views.home', post='views.home'),
        name='home'),
    (r'^api/theming', include('theming.api.urls')),

    url(r'^/?$', lambda request: redirect(reverse('home'))),
    url(r'^logout/?$', LogoutView.as_view(), name='logout'),
)

if settings.DEPLOYMENT_MODE == 'local':
    urlpatterns += patterns('',
        url(r'^filez/(?P<path>.*)$', 'django.views.static.serve',
                                    {'document_root': settings.MEDIA_ROOT}),
    )

import sys
if settings.DEBUG and 'test' not in sys.argv:
    import debug_toolbar
    urlpatterns += patterns('', url(r'^__debug__/', include(debug_toolbar.urls)),)
