# -*- coding: utf-8 -*-

from django.conf import settings
from django.http import Http404
from django.shortcuts import redirect, render_to_response
from django.template import RequestContext, loader, TemplateDoesNotExist


def safe_redirect(next_url, request, default_uri=None):
    """
    Redirects to next_url if next_url appears to be a legit resource for this
    domain. Otherwise, redirects to default_uri if not None or to '/'
    """
    if next_url and (settings.DEPLOYMENT_MODE == 'local' 
                 or is_legit_next_url(next_url, request)):
        return redirect(next_url)
    
    return redirect(default_uri) if default_uri else redirect('/')

def is_legit_next_url(next_url, request=None):
    """
    Call this function anytime you want to know if the 'next_url' URI is a 
    legit URI for the domain. e.g. We don't want to forward to 'next_url' if 
    it's on http://evil.com
    """
    if not next_url or next_url.startswith('//'):
        # Either no next_url or some //evil.com hackery, neither is legit
        return False
    
    if next_url.startswith('/'):
        # Relative path on this site, so it's cool
        return True

    #TODO when mobile and tablet are back, then we need to add them back here
    if request and hasattr(request, 'domain') and request.domain:
        if next_url.startswith(request.domain['site_root_uri']):
            return True  

    return False

def render_template(request, template_name, context_dict=None):
    """
    Renders a generic template if they exist.
    If no such template exists or there is no domain on the request a Http404 
    exception is raised.
    
    Parameters:
       request : HttpRequest
       template_name : template path without a beginning slash, e.g.
                       my_template.html or myapp/my_template.html
       context_dict: context dictionary
    
    Returns HttpResponse
    """
    if context_dict is None:
        context_dict = {}

    try:
        context_instance = RequestContext(request)

        return render_to_response(template_name, context_dict,
                                  context_instance=context_instance)
    except TemplateDoesNotExist:
        raise Http404

def render_to_string(request, template_name, context_dict=None):    
    """
    Renders generic template to a string. 

    Use this function when the http response code is not one of 2XX. 
    Parameters:
       request : HttpRequest
       template_name : template path without a beginning slash, e.g.
                       my_template.html or myapp/my_template.html
       context_dict: context dictionary

    Returns a string 
    """
    if context_dict is None:
        context_dict = {}

    context_instance = RequestContext(request)

    return loader.render_to_string(template_name, context_dict,
                                   context_instance=context_instance)


