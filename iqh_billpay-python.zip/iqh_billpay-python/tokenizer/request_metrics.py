# -*- coding: utf-8 -*-

import iqh_logging
from axiom_statsd import utils as statsd

logger = iqh_logging.get_logger(__name__)


def record_measured_request(statsd_keys, status_code, response_time, error=None):
    """
    Measures and records data about the request.

    statsd_keys: List of statsd keys
    status_code: string represenation of the http status code on the response
    response_time: string representation of how long the response took to complete in milliseconds
    error: The error returned from the client. The only valid errors that are deemed as
           metrics are 'unknown_error' and 'timeout'.

    Measurements taken include:
    * A timing which is recorded to all of the given keys.
    * Counter for the status code of the response on all of the given keys, by
      appending the status code to the key. E.g, for 'my.client.key' a 404
      response would increment 'my.client.key.404'.
    * A counter suffixed "timeout" in the case of a connection-level timeout.
    * A counter suffixed "unknown_error" in the case of unresolvable requests.

    NOTE: This function should only be used for requests made on the client side.
    Any requests made on the server side should use the exec_measured_request
    function.
    """

    def increment(sub_key=None):
        """
        Increment the count for the sub keys generated for all of statsd_keys.
        """
        for statsd_key in _gen_keys(statsd_keys, sub_key):
            statsd.increment(statsd_key)

    def record_time(timing):
        """
        Record the timing for the sub keys generated for all of statsd_keys.
        """
        for statsd_key in statsd_keys:
            statsd.timing(statsd_key, timing)

    if error in ('unknown_error', 'timeout'):
        increment(error)

    elif status_code:
        increment(status_code)

    # response time is in milliseconds
    try:
        response_time = int(response_time)
        record_time(response_time)
    except ValueError:
        logger.exception('Unable to record time into statsd due to response_time not being in the correct format. response_time: {0}'.format(
                response_time))


def _gen_keys(statsd_keys, sub_key=None):
    """
    Generate statsd keys by appending the subkey to each existing key in
    statsd_keys.

    sub_key must be a str or unicode value.
    """
    for statsd_key in statsd_keys:
        if sub_key:
            yield u'{0}.{1}'.format(statsd_key, sub_key)
        else:
            yield statsd_key

