# -*- coding: utf-8 -*-

import os
from fabric import api

from release.utils import timed_execute

from axiom_fabric.gcl import ensure_test_user
from axiom_fabric.rhel6 import ensure_m2crypto_0_21_1
from axiom_fabric.rhel6 import ensure_oracle_11_2
from axiom_fabric.rhel6 import ensure_prereqs_py27
from axiom_fabric.rhel6 import ensure_lib_installed
from axiom_fabric.linux import ensure_cron_job
from axiom_fabric.linux import ensure_virtual_env
from axiom_fabric.svn import svn_export
from fabric.api import hide
from fabric.api import run
from fabric.api import settings
from fabric.api import env
from fabric.api import put
from fabric.operations import sudo
from fabric.contrib.files import exists

VIRTUAL_ENV = 'iqh_billpay'
nginx_version = 'nginx-1.13.8-1.el6.ngx.x86_64'
RPM = '{0}.rpm'.format(nginx_version)


def bootstrap(ve):
    """ Main bootstrapper method for RHEL 6. """
    timed_execute(ensure_test_user, roles=['webapp', 'proxy'])
    timed_execute(__update_rhel, roles=['webapp', 'proxy'])
    timed_execute(__ensure_nginx, roles=['proxy'])
    timed_execute(ensure_prereqs_py27, install_mod_wsgi=False, roles=['webapp'])
    timed_execute(ensure_virtual_env, ve, roles=['webapp'])
    timed_execute(ensure_oracle_11_2, ve, roles=['webapp'])
    timed_execute(__ensure_node_0_8_16, roles=['webapp'])
    timed_execute(__ensure_node_deps, roles=['webapp'])
    timed_execute(__ensure_libmemcached, roles=['webapp'])
    timed_execute(ensure_m2crypto_0_21_1, ve, roles=['webapp'])
    timed_execute(__ensure_memcached, roles=['cache'])


def bootstrap_skybox_vm(ve):
    """ This method is used to handle any differneces between Skybox VM images."""
    timed_execute(ensure_test_user, roles=['webapp', 'proxy'])
    timed_execute(__update_rhel, roles=['webapp', 'proxy'])
    timed_execute(__update_etc_profile, roles=['webapp'])
    timed_execute(__ensure_nginx, roles=['proxy'])
    timed_execute(ensure_prereqs_py27, install_mod_wsgi=True, roles=['webapp'])
    timed_execute(ensure_virtual_env, ve, roles=['webapp'])
    timed_execute(ensure_oracle_11_2, ve, roles=['webapp'])
    timed_execute(__ensure_node_0_8_16, roles=['webapp'])
    timed_execute(__ensure_node_deps, roles=['webapp'])
    timed_execute(__ensure_libmemcached, roles=['webapp'])
    timed_execute(ensure_m2crypto_0_21_1, ve, roles=['webapp'])
    timed_execute(__ensure_memcached, roles=['cache'])


def __update_etc_profile():
    resource_path = "{0}/../resources/rhel6/".format(os.path.dirname(os.path.realpath(__file__)))

    # Workaround for use_sudo=True issue: https://github.com/fabric/fabric/pull/694
    # Move file to writable directory and then change ownership
    put('{0}profile'.format(resource_path), remote_path='~', mode=0644)
    sudo('mv /home/test/profile /etc')
    sudo('chown root:root /etc/profile')


def __update_rhel(ve=VIRTUAL_ENV):
    """
    Configures RHEL to clean up and update its cache every morning,
    downloads but does not install updates on a cronjob every morning.

    Installs but does not download updates every code push.

    To ensure that a package is not updated automatically by this method
    use the yum versionlock command, example:
    yum versionlock memcached
    """
    sudo("yum -y install yum-plugin-versionlock")

    ensure_cron_job('30 6 * * * root yum upgrade -y --downloadonly --randomwait 45', ve)
    sudo('yum upgrade -y')


def __ensure_node_0_8_16():
    """ Used to install redis on RHEL.  You must have rpm_download_root set.  """
    with settings(hide('everything'), warn_only=True):
        result = run('rpm -qa | grep nodejs-0.8.16')
    if result.failed:
        run('wget {0}nodejs-0.8.16-1.cerner.x86_64.rpm'.format(env['rpm_download_root']))
        sudo('yum -y localinstall --nogpgcheck nodejs-0.8.16-1.cerner.x86_64.rpm')
        sudo('yum -y versionlock nodejs')


def __ensure_node_deps():
    """ Ensures all of our node dependencies are installed. """

    unnecessary_packages = [
        'amdefine', 'source-map', 'tunnel-agent', 'punycode',
        'tough-cookie', 'qs', 'oauth-sign', 'node-uuid', 'json-stringify-safe',
        'ctype', 'assert-plus', 'asn1', 'http-signature', 'sntp', 'hoek', 'cryptiles',
        'boom', 'hawk', 'delayed-stream', 'combined-stream', 'async', 'form-data',
        'forever-agent', 'aws-sign2', 'request', 'mkdirp', 'mime', 'commander', 'clean-css',
        'amdefine', 'source-map', 'wordwrap', 'optimist', 'less', 'uglify-js'
    ]

    with settings(hide('everything'), warn_only=True):
        result = run('npm -g ls | grep iqh-node@0.0.0')

    if result.failed:
        npm_root_folder = run('npm -g root')

        # remove unnecessary node packages that we previously installed individually.
        # all of our dependencies will now be installed under iqh-node
        for package_name in unnecessary_packages:
            __npm_uninstall_tgz_package(npm_root_folder, package_name)

        tgz_package = '{0}iqh-node-0.0.0.tgz'.format(api.env['tgz_download_root'])
        run('wget {0}'.format(tgz_package))
        sudo('mkdir -p /tmp/nodecache')
        sudo('gzip -dc iqh-node-0.0.0.tgz | tar -xf - -C /tmp/nodecache')
        sudo('npm install -g --cache /tmp/nodecache/package/offline/cache --optional --cache-min 999999 --fetch-retries 0 --fetch-retry-factor 0 --fetch-retry-mintimeout 1 --fetch-retry-maxtimeout 2 {0}'.format(tgz_package))

        # clean up
        sudo('rm -rf /tmp/nodecache')
        sudo('rm iqh-node-0.0.0.tgz')


def __ensure_memcached():
    with settings(hide('everything'), warn_only=True):
        result = run('rpm -qa | grep memcached-1.4.15')
    if result.failed:
        run('wget {0}epel-release-6-7.noarch.rpm'.format(env['rpm_download_root']))
        sudo('yum -y localinstall --nogpgcheck epel-release-6-7.noarch.rpm')
        ensure_lib_installed('cyrus-sasl')
        ensure_lib_installed('libevent')
        run('wget {0}memcached-1.4.15-1.el6.cernersasl.x86_64.rpm'.format(env['rpm_download_root']))
        sudo('yum -y localinstall --nogpgcheck memcached-1.4.15-1.el6.cernersasl.x86_64.rpm')
        sudo('yum -y versionlock memcached')

    # Default memcached service will be replaced with custom service. The 'put' method does not
    # seem to replace pre-existing files.
    if exists('/etc/init.d/memcached', use_sudo=True):
        sudo('rm /etc/init.d/memcached')

    put('install/memcached', remote_path='/etc/init.d/', use_sudo=True, mode=0755)
    sudo('chkconfig memcached on')
    sudo('service memcached start')


def __ensure_libmemcached():
    with settings(hide('everything'), warn_only=True):
        result = run('rpm -qa | grep libmemcached-cerner-1.0.16-1')
    if result.failed:
        run('wget {0}libmemcached-cerner-1.0.16-1.el6.x86_64.rpm'.format(env['rpm_download_root']))
        sudo('yum -y localinstall --nogpgcheck libmemcached-cerner-1.0.16-1.el6.x86_64.rpm')

    with settings(hide('everything'), warn_only=True):
        result = run('rpm -qa | grep libmemcached-cerner-devel-1.0.16-1')
    if result.failed:
        run('wget {0}libmemcached-cerner-devel-1.0.16-1.el6.x86_64.rpm'.format(env['rpm_download_root']))
        sudo('yum -y localinstall --nogpgcheck libmemcached-cerner-devel-1.0.16-1.el6.x86_64.rpm')


def __ensure_nginx():
    with settings(api.hide('everything'), warn_only=True):
        result = api.run('rpm -qa | grep {0}'.format(nginx_version))

    if result.failed:
        __install_nginx()


def __install_nginx():
    sudo('yum -y install svn')
    sudo('yum -y install pcre*')
    url = '{0}{1}'.format(env['rpm_download_root'], RPM)
    svn_export(url)

    # Remove nginx versionlock if existing
    with settings(api.hide('everything'), warn_only=True):
        result_versionlock = sudo('yum versionlock list | grep nginx')
        if 'nginx' in result_versionlock:
            sudo('yum versionlock delete {}'.format(result_versionlock))

    sudo('yum -y localinstall --nogpgcheck {0}'.format(RPM))
    sudo('rm -f {0}'.format(RPM))
    sudo('yum -y versionlock nginx')

    # Remove the default nginx conf files that come with fresh install
    with settings(warn_only=True):
        sudo('rm -rf /etc/nginx/conf.d/default.conf')
        sudo('rm -rf /etc/nginx/conf.d/example_ssl.conf')

    sudo('mkdir -p /var/log/nginx')
    # Ensure permissions on nginx log directory
    sudo('chmod 0755 /var/log/nginx')


def __npm_uninstall_tgz_package(npm_root_folder, name):
    path = '{0}/{1}'.format(npm_root_folder, name)

    # Ensure the package exists before uninstalling it
    if exists(path, use_sudo=True):
        sudo('npm uninstall {0} -g'.format(name))
