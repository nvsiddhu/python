# -*- coding: utf-8 -*-

from django.test import TestCase

from forms import AccessForm


class AccessFormTests(TestCase):
    """
    Ensures payment form is functioning correctly.
    """
    whitebox = True

    def test_required_fields(self):
        """
        If the user indicates to continue without entering data in all search
        criteria fields, the system shall display a message, such as:
        "All fields are required."
        """
        post_data = {}
        form = AccessForm(post_data)
        form.full_clean()
        assert 'last_name' in form._errors
        assert 'date_of_birth' in form._errors
        assert 'access_code' in form._errors

        post_data = {'last_name': '', 'date_of_birth': '', 'access_code': ''}
        form = AccessForm(post_data)
        form.full_clean()
        assert 'last_name' in form._errors
        assert 'date_of_birth' in form._errors
        assert 'access_code' in form._errors

        post_data = {'last_name': 'smith', 'date_of_birth': '1/1/1970',
                     'access_code': 'test1'}
        form = AccessForm(post_data)
        form.full_clean()
        assert 'last_name' not in form._errors
        assert 'date_of_birth' not in form._errors
        assert 'access_code' not in form._errors

    def test_dob(self):
        """
        date should be entered in the form m/d/yyyy
        """
        post_data = {'date_of_birth': 'abc'}
        self._verify_dob(post_data)

        post_data = {'date_of_birth': 'a/b/c'}
        self._verify_dob(post_data)

        post_data = {'date_of_birth': '1/1'}
        self._verify_dob(post_data)

        post_data = {'date_of_birth': '1/1/1'}
        self._verify_dob(post_data)

        post_data = {'date_of_birth': '1/1/111'}
        self._verify_dob(post_data)

        post_data = {'date_of_birth': '1/1/11111'}
        self._verify_dob(post_data)

        post_data = {'date_of_birth': '111/1/1111'}
        self._verify_dob(post_data)

        post_data = {'date_of_birth': '1/111/1111'}
        self._verify_dob(post_data)

        post_data = {'date_of_birth': '1/a/2000'}
        self._verify_dob(post_data)

        post_data = {'date_of_birth': '1/1/2000/1'}
        self._verify_dob(post_data)

        post_data = {'date_of_birth': '1-1-2000'}
        self._verify_dob(post_data)

    def _verify_dob(self, post_data):
        form = AccessForm(post_data)
        form.full_clean()
        assert 'date_of_birth' in form._errors
