/** Makes a CORS request to the EDI request token service to retreive the token which
    is sent to the server.
**/

(function() {

  $.fn.tokenize = function(config) {

     var $form = this;

    function retrieveToken() {

      var ccn = $('#card_number').val(),
          cvv = $('#security_number').val(),
          expiration_date = $('.expiration_date'),
          year = expiration_date[1].value,
          month = expiration_date[0].value;

      if(expiration_date[0].value.length == 1){
        month = '0'+ expiration_date[0].value;
      }

      // Validates ccn and cvv and sends an error to the server
      if (ccn.length < 4 || cvv.length === 0) {
        var input = $('<input />').attr({
          'type': 'hidden',
          'name': 'error_message',
          'value': 'sensitive_info_missing'
        }).appendTo($form);

        $form.get(0).submit();
        return false;
      }

      window.CORSRequest.post(config.api_url, {
        headers: { 'Content-Type': 'text/plain' },
        context: $form,
        timeout: config.timeout,
        cancel: cancel,
        success: success,
        error: error,
        data: JSON.stringify({
          'number': ccn,
          'CVV2': cvv,
          'expirationDate': year + month,
          'submitterId': config.submitterID,
          'tokenReferenceId': config.tokenReferenceID
        })
      });

      return false;
    }

    function success(responseText, status, startTime) {
      var xmlDoc = $.parseXML(responseText),
          xml = $(xmlDoc);

      if (xml.find( "statusCode").text() == '00' || xml.find( "errorCode").length !== 0 || xml.find( "errorMsg").length !== 0){
        create_response_form_fields(xml);
      }

      else {
        create_unexpected_response_form_fields(responseText);
      }

      create_status_code_form_element(status);

      var responseTime = new Date().getTime() - startTime;
      create_response_time_form_element(responseTime);

      $form.get(0).submit();
      return false;
    }

    function error(err, startTime) {
      create_unexpected_response_form_fields(err);

      // if startTime was never set, the cors request was never made. So don't create the hidden input field.
      if (startTime){
        var responseTime = new Date().getTime() - startTime;
        create_response_time_form_element(responseTime);
      }

      $form.get(0).submit();
      return false;

    }

    function cancel() {
      create_unexpected_response_form_fields('cancelled');
      $form.get(0).submit();
      return false;
    }

    // Creates the hidden inputs for success and expected error scenarios,
    // to send the response text to the server.
    function create_response_form_fields(xml){
      var inputs = { 'cardType': 'card_type',
                  'interchangeId': 'interchange_id',
                  'cardNumber': 'masked_card_number',
                  'errorCode': 'error_code',
                  'errorMsg': 'error_message'};
      for (var name in inputs) {
        value = xml.find(name).text();
        if (value){
          $($('<input />').attr({
            'type': 'hidden',
            'name': inputs[name],
            'value': value
          })).appendTo($form);
        }
      }
    }

    // Creates the hidden inputs for unexpected errors(timeout and unknown errors)
    // to send error messages to the server.
    function create_unexpected_response_form_fields(err){
      if (err) {
          $('<input />').attr({
            'type': 'hidden',
            'name': 'error_message',
            'value': err
          }).appendTo($form);
        }
      else {
        $('<input />').attr({
          'type': 'hidden',
          'name': 'error_message',
          'value': 'unknown_error'
        }).appendTo($form);
      }
    }

    /** Creates an hidden input fields to pass them to the server:
        For status code. **/
    function create_status_code_form_element(status){
      if (status){
        var http_status_code = $('<input />').attr({
          'type': 'hidden',
          'name': 'http_status_code',
          'value': status
        }).appendTo($form);
      }
    }

    // Creates an hidden input field for response time
    function create_response_time_form_element(responseTime){
      $('<input />').attr({
          'type': 'hidden',
          'name': 'response_time',
          'value': responseTime
        }).appendTo($form);
    }

    // The callback event should be triggered only once.
    return this.one('submit', retrieveToken);
  };

})();
