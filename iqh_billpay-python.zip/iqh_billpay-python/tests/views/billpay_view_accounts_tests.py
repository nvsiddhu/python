# -*- coding: utf-8 -*-

from django.contrib import messages
from django.core.urlresolvers import reverse
from django.contrib.humanize.templatetags.humanize import intcomma
from django.utils.dateformat import format
from mock import patch

from tests.views.base_billpay_test import BaseBillPayTest


class BillPayViewAccountsTests(BaseBillPayTest):
    """ Tests Bill Pay view accounts page
    """
    functional = True

    def setUp(self):
        super(BillPayViewAccountsTests, self).setUp()

        self.login_user('g_4')

    def test_get_view_accounts(self):
        """
        The View Accounts page shall display all accounts for the matching guarantor.
        Each account shall display the facility name.
        Each account shall display the patient name.
        Each account shall display the amount due.
        Each account shall display the account number in a masked format that hides part of the account number.
        Each account shall display the last payment amount as a positive number.
            If no last payment amount exists, this field should not display.
        Each account shall display the date the last payment was received.
            If no last payment date exists, this field should not display.
        If the account has an outstanding balance, it shall display an option that links to the Make Payment page.
        If the account has a credit balance or zero balance, it shall not display an option that links to the Make Payment page.
        """
        response = self.client.get(reverse('view_accounts'))
        self.assertTemplateUsed(response, 'account.html')

        accts_due = response.context['accts_amount_due']
        accts_not_due = response.context['accts_no_amount_due']

        for acct in accts_due:
            self._verify_account_in_response(response, acct, True)

        for acct in accts_not_due:
            self._verify_account_in_response(response, acct, False)

    @patch.object(messages, 'warning')
    def test_cancel_status(self, messages):
        """
        A warning message should be displayed when a cancel status is passed as
        a query param to the view_accounts view.
        """
        url = "{0}?status=cancel".format(reverse('view_accounts'))
        self.client.get(url)
        self.assertTrue(messages.called)

    def _verify_account_in_response(self, response, acct, is_due):
        self.assertContains(response, acct['facility'])
        self.assertContains(response, acct['patient_name'])
        if is_due:
            self.assertGreater(acct['amount_due'], 0, 'amount_due on a due account should be more than 0')
            self.assertContains(response, intcomma(str(acct['amount_due'])))
            self.assertContains(response, reverse('account_payment', args=[acct['id']]))
        else:
            self.assertLessEqual(acct['amount_due'], 0, 'amount_due on a credit or zero balance account should be less than or equal to 0')
            self.assertNotContains(response, reverse('account_payment', args=[acct['id']]))

        self.assertContains(response, acct['masked_account_number'])
        if acct['last_payment_amount'] is not None:
            self.assertContains(response, intcomma(str(acct['last_payment_amount'])))
        else:
            self.assertNotContains(response, '<dt>Last payment</dt><dd></dd>')

        if acct['last_payment_date'] is not None:
            self.assertContains(response, format(acct['last_payment_date'], "F j, Y"))
        else:
            self.assertNotContains(response, '<dt>Date received</dt><dd></dd>')
