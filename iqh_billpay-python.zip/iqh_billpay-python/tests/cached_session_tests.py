# -*- coding: utf-8 -*-

from datetime import timedelta
import hashlib
import pickle
from django.test import TestCase

from cached_sessions import SessionStore
from django.conf import settings
from django.contrib.sessions.backends.cache import KEY_PREFIX
from django.core.cache import get_cache
from django.core.signing import b64_encode
from django.test.utils import override_settings
from django.utils import crypto
from django.utils import timezone
from iqh_backend_utils.encrypt_util import aes_decrypt


class CachedSessionTests(TestCase):
    """
    These tests cover the new functionality added to the session store.
    """

    backend = SessionStore

    def setUp(self):
        self.session = self.backend()
        self.cache = get_cache('default')

    def tearDown(self):
        self.session.delete()

    def test_encrypt_session_on_save(self):
        """
        Saving the session should encrypt the data before saving it in cache.
        """
        self.session['sensitive_data'] = '123'
        self.session['object'] = MockObject

        self.session.save()

        encrypted_data = self.cache.get(self.session.cache_key)
        session_data = aes_decrypt(encrypted_data, settings.SESSION_DATA_ENC_KEY)
        session_data = pickle.loads(session_data)

        self.assertEquals(session_data['sensitive_data'], self.session['sensitive_data'])
        self.assertEquals(session_data['object'], self.session['object'])

    def test_decrypt_session_on_load(self):
        """
        Load should decrypt the session data before returning it.
        """
        self.session['sensitive_data'] = '123'
        self.session['object'] = MockObject

        self.session.save()

        session_data = self.session.load()

        self.assertEquals(session_data['sensitive_data'], self.session['sensitive_data'])
        self.assertEquals(session_data['object'], self.session['object'])

    def test_dont_decrypt_new_session_on_load(self):
        """
        Load should not decrypt the session data if the data is empty. This is normally
        the case for new or empty sessions.
        """
        self.session.save()

        session_data = self.session.load()

        self.assertEquals(session_data, {})

    def test_get_cache_key(self):
        """
        _get_cache_key should return a hashed session key (HMAC-SHA256) along with a key prefix.
        """
        self.session.save()
        key = self.session._get_cache_key(self.session.session_key)

        self.assertNotIn(self.session.session_key, key)

        hashed_session_key = hashlib.sha256(settings.SESSION_SALT + self.session.session_key).hexdigest()

        self.assertEquals(len(hashed_session_key), 64)
        self.assertEquals(KEY_PREFIX + hashed_session_key, self.session.cache_key)

    def test_cycle_key(self):
        """
        cycle_key should cycle also update the _session_key.
        """
        self.session['sensitive_data'] = '123'
        self.session['_session_key'] = self.session.session_key
        self.session.save()

        prev_session_key = self.session.session_key

        self.session.cycle_key()

        self.assertEquals(self.session['sensitive_data'], '123')
        self.assertNotEquals(prev_session_key, self.session.session_key)
        self.assertEquals(self.session['_session_key'], self.session.session_key)


class SessionTests(TestCase):
    """
    Copied these tests from django's session store tests. Running through the same
    tests for the dedicated session store for billpay.

    https://github.com/django/django/blob/1.4.11/django/contrib/sessions/tests.py
    """

    backend = SessionStore

    def setUp(self):
        self.session = self.backend()

    def tearDown(self):
        self.session.delete()

    def test_new_session(self):
        self.assertFalse(self.session.modified)
        self.assertFalse(self.session.accessed)

    def test_get_empty(self):
        self.assertEqual(self.session.get('cat'), None)

    def test_store(self):
        self.session['cat'] = "dog"
        self.assertTrue(self.session.modified)
        self.assertEqual(self.session.pop('cat'), 'dog')

    def test_pop(self):
        self.session['some key'] = 'exists'
        # Need to reset these to pretend we haven't accessed it:
        self.accessed = False
        self.modified = False

        self.assertEqual(self.session.pop('some key'), 'exists')
        self.assertTrue(self.session.accessed)
        self.assertTrue(self.session.modified)
        self.assertEqual(self.session.get('some key'), None)

    def test_pop_default(self):
        self.assertEqual(self.session.pop('some key', 'does not exist'),
                         'does not exist')
        self.assertTrue(self.session.accessed)
        self.assertFalse(self.session.modified)

    def test_setdefault(self):
        self.assertEqual(self.session.setdefault('foo', 'bar'), 'bar')
        self.assertEqual(self.session.setdefault('foo', 'baz'), 'bar')
        self.assertTrue(self.session.accessed)
        self.assertTrue(self.session.modified)

    def test_update(self):
        self.session.update({'update key': 1})
        self.assertTrue(self.session.accessed)
        self.assertTrue(self.session.modified)
        self.assertEqual(self.session.get('update key', None), 1)

    def test_has_key(self):
        self.session['some key'] = 1
        self.session.modified = False
        self.session.accessed = False
        self.assertTrue('some key' in self.session)
        self.assertTrue(self.session.accessed)
        self.assertFalse(self.session.modified)

    def test_values(self):
        self.assertEqual(self.session.values(), [])
        self.assertTrue(self.session.accessed)
        self.session['some key'] = 1
        self.assertEqual(self.session.values(), [1])

    def test_iterkeys(self):
        self.session['x'] = 1
        self.session.modified = False
        self.session.accessed = False
        i = self.session.iterkeys()
        self.assertTrue(hasattr(i, '__iter__'))
        self.assertTrue(self.session.accessed)
        self.assertFalse(self.session.modified)
        self.assertEqual(list(i), ['x'])

    def test_itervalues(self):
        self.session['x'] = 1
        self.session.modified = False
        self.session.accessed = False
        i = self.session.itervalues()
        self.assertTrue(hasattr(i, '__iter__'))
        self.assertTrue(self.session.accessed)
        self.assertFalse(self.session.modified)
        self.assertEqual(list(i), [1])

    def test_iteritems(self):
        self.session['x'] = 1
        self.session.modified = False
        self.session.accessed = False
        i = self.session.iteritems()
        self.assertTrue(hasattr(i, '__iter__'))
        self.assertTrue(self.session.accessed)
        self.assertFalse(self.session.modified)
        self.assertEqual(list(i), [('x', 1)])

    def test_clear(self):
        self.session['x'] = 1
        self.session.modified = False
        self.session.accessed = False
        self.assertEqual(self.session.items(), [('x', 1)])
        self.session.clear()
        self.assertEqual(self.session.items(), [])
        self.assertTrue(self.session.accessed)
        self.assertTrue(self.session.modified)

    def test_save(self):
        self.session.save()
        self.assertTrue(self.session.exists(self.session.session_key))

    def test_delete(self):
        self.session.save()
        self.session.delete(self.session.session_key)
        self.assertFalse(self.session.exists(self.session.session_key))

    def test_flush(self):
        self.session['foo'] = 'bar'
        self.session.save()
        prev_key = self.session.session_key
        self.session.flush()
        self.assertFalse(self.session.exists(prev_key))
        self.assertNotEqual(self.session.session_key, prev_key)
        self.assertTrue(self.session.modified)
        self.assertTrue(self.session.accessed)

    def test_cycle(self):
        self.session['a'], self.session['b'] = 'c', 'd'
        self.session.save()
        prev_key = self.session.session_key
        prev_data = self.session
        self.session.cycle_key()
        self.assertNotEqual(self.session.session_key, prev_key)
        self.assertEqual(self.session['a'], prev_data['a'])
        self.assertEqual(self.session['b'], prev_data['b'])

    def test_invalid_key(self):
        # Submitting an invalid session key (either by guessing, or if the db has
        # removed the key) results in a new key being generated.
        try:
            session = self.backend('1')
            try:
                session.save()
            except AttributeError:
                self.fail("The session object did not save properly.  Middleware may be saving cache items without namespaces.")
            self.assertNotEqual(session.session_key, '1')
            self.assertEqual(session.get('cat'), None)
            session.delete()
        finally:
            # Some backends leave a stale cache entry for the invalid
            # session key; make sure that entry is manually deleted
            session.delete('1')

    def test_session_key_is_read_only(self):
        def set_session_key(session):
            session.session_key = session._get_new_session_key()
        self.assertRaises(AttributeError, set_session_key, self.session)

    # Custom session expiry
    def test_default_expiry(self):
        # A normal session has a max age equal to settings
        self.assertEqual(self.session.get_expiry_age(), settings.SESSION_COOKIE_AGE)

        # So does a custom session with an idle expiration time of 0 (but it'll
        # expire at browser close)
        self.session.set_expiry(0)
        self.assertEqual(self.session.get_expiry_age(), settings.SESSION_COOKIE_AGE)

    def test_custom_expiry_seconds(self):
        # Using seconds
        self.session.set_expiry(10)
        delta = self.session.get_expiry_date() - timezone.now()
        self.assertTrue(delta.seconds in (9, 10))

        age = self.session.get_expiry_age()
        self.assertTrue(age in (9, 10))

    def test_custom_expiry_timedelta(self):
        # Using timedelta
        self.session.set_expiry(timedelta(seconds=10))
        delta = self.session.get_expiry_date() - timezone.now()
        self.assertTrue(delta.seconds in (9, 10))

        age = self.session.get_expiry_age()
        self.assertTrue(age in (9, 10))

    def test_custom_expiry_datetime(self):
        # Using fixed datetime
        self.session.set_expiry(timezone.now() + timedelta(seconds=10))
        delta = self.session.get_expiry_date() - timezone.now()
        self.assertTrue(delta.seconds in (9, 10))

        age = self.session.get_expiry_age()
        self.assertTrue(age in (9, 10))

    def test_custom_expiry_reset(self):
        self.session.set_expiry(None)
        self.session.set_expiry(10)
        self.session.set_expiry(None)
        self.assertEqual(self.session.get_expiry_age(), settings.SESSION_COOKIE_AGE)

    def test_get_expire_at_browser_close(self):
        # Tests get_expire_at_browser_close with different settings and different
        # set_expiry calls
        with override_settings(SESSION_EXPIRE_AT_BROWSER_CLOSE=False):
            self.session.set_expiry(10)
            self.assertFalse(self.session.get_expire_at_browser_close())

            self.session.set_expiry(0)
            self.assertTrue(self.session.get_expire_at_browser_close())

            self.session.set_expiry(None)
            self.assertFalse(self.session.get_expire_at_browser_close())

        with override_settings(SESSION_EXPIRE_AT_BROWSER_CLOSE=True):
            self.session.set_expiry(10)
            self.assertFalse(self.session.get_expire_at_browser_close())

            self.session.set_expiry(0)
            self.assertTrue(self.session.get_expire_at_browser_close())

            self.session.set_expiry(None)
            self.assertTrue(self.session.get_expire_at_browser_close())

    def test_decode(self):
        # Ensure we can decode what we encode
        data = {'a test key': 'a test value'}
        encoded = self.session.encode(data)
        self.assertEqual(self.session.decode(encoded), data)


class MockObject(object):

    attr1 = False
    attr2 = 100000
    attr3 = 'string'
    attr4 = u'%Ö'
    attr5 = [1, 2, 3, 4, 5]
    attr6 = {'key': 'value'}
    attr7 = None
