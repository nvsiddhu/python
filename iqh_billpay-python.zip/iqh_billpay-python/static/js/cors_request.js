/***
* Creates the cors request.
* Accepts url and settings as parameters
  url: the url to do the post or get to
  settings: Settings required for the get or post.
          settings.timeout: Number of milliseconds to wait for the CORS request.
          settings.success: The callback function to be called on load from a successful CORS request,
                            callback function parameters are: response text, http status code, and an integer
                                which represents the number of milliseconds before since 1970/01/01.
                                http://www.w3schools.com/jsref/jsref_gettime.asp
          settings.error: The callback function to be called on error or on timeout from a failed CORS request.
                          callback function parameters are: response text and startTime. On timeout the responseText is sent as
                          timeout. startTime may not be defined due to not being able to send the cors request.
          settings.data: Data for the CORS request.
          settings.method: Specifies the CORS request method( get or a post).
          settings.headers: Header information to make the CORS request.
          settings.cancel: A callback function to be called when the request does not trigger the expected
                           handlers (onload, ontimeout, onerror). As a precaution, it's recommended to implement this function
                           if you still support IE 8 & 9. The function does not pass any parameters when called.
          settings.context: This object will be made the context of all CORS-related callbacks except cancel. By default,
                            the context is the HTML DOM.
* Handles the CORS event handlers
***/

(function() {

  function request(url, settings) {

    var context = settings.context || document;
    var xhr = new XMLHttpRequest();

    // default timeout is 20 seconds
    var timeout = settings.timeout || 20000;

    var timeoutID;
    if (typeof(settings.cancel) == 'function') {
      /** Set a delay that will allow the request to error out in the off chance the
          CORS request unexpectedly aborts and doesn't call the expected handler.
          The issue tends to be IE 8/9 related. We thought it would be best
          to implement a safe way of timing out the request when such an issue occurs.
          Adding a buffer of 5 additional seconds from the timeout setting to give enough
          time for the success function to completely run in the off chance the cors request
          took the full amount of time allowed.
      **/
      timeoutID = window.setTimeout(settings.cancel, timeout + 5000);
    }

    // Modern browser
    if ("withCredentials" in xhr) {

      xhr.open(settings.method, url, true);
      xhr.timeout = timeout;
      for (var key in settings.headers) {
        xhr.setRequestHeader(key, settings.headers[key]);
      }

    // IE8 & IE9
    } else if (typeof XDomainRequest != "undefined") {
      xhr = new XDomainRequest();

      /** XDomainRequest is wrapped around try catch to
          catch Access Denied errors. Access Denied is thrown
          in IE 8 and IE 9 when the browser is not allowed to open
          a connection to the server due to internet/intranet settings.
      **/
      try{
        xhr.open(settings.method, url);
        xhr.timeout = settings.timeout;
      }

      catch (err){
        if (typeof(settings.error) == 'function') {
          settings.error.call(context, err);
        }
        return null;
      }

    // No CORS support
    } else {
      return null;
    }

    // mark the start time so we can determine how long the resopnse takes
    var startTime = new Date().getTime();

    // Attach event handlers
    if (typeof(settings.success) == 'function') {
      xhr.onload = function() {
        window.clearTimeout(timeoutID);
        settings.success.call(context, xhr.responseText, xhr.status, startTime);
      };
    }

    if (typeof(settings.error) == 'function') {

      xhr.onerror = function() {
        window.clearTimeout(timeoutID);
        settings.error.call(context, xhr.responseText, startTime);
      };

      xhr.ontimeout = function() {
        window.clearTimeout(timeoutID);
        settings.error.call(context, 'timeout', startTime);
      };
    }

    /** This is required for IE 9. Since it aborts the XDomainRequest.
        Source for the fix:
        https://social.msdn.microsoft.com/Forums/ie/en-US/30ef3add-767c-4436-b8a9-f1ca19b4812e/ie9-rtm-xdomainrequest-issued-requests-may-abort-if-all-event-handlers-not-specified
    **/
    xhr.onprogress = function() {};

    if (settings.data) {
      // There is a weird bug in IE 8 & 9 where the request may get blocked and not send. The fix is to set
      // a short delay before sending the request.
      // http://cypressnorth.com/programming/internet-explorer-aborting-ajax-requests-fixed/
      window.setTimeout(function(){
          xhr.send(settings.data);
        }, 0);
    } else {
      window.setTimeout(function(){
          xhr.send();
        }, 0);
    }

    return xhr;
  }


  window.CORSRequest = {

    ajax: function(url, settings) {
      return request(url, settings);
    },

    /**
     * Make a CORS request using GET.
     * @param url {String} The url of the request.
     * @param settings {object} An object that may consist of
     *      information regarding timeout, method( get or post),
     *      header information, callback function name
     *      and data for get or post request.
     */
    get: function(url, settings) {
      settings = settings || {};
      settings.method = 'GET';

      return CORSRequest.ajax(url, settings);
    },

    /**
     * Make a CORS request using GET.
     * @param url {String} The url of the request.
     * @param settings {object} An object that may consist of
     *      information regarding timeout, method( get or post),
     *      header information, callback function name
     *      and data for get or post request.
     */
    post: function(url, settings) {
      settings = settings || {};
      settings.method = 'POST';

      return CORSRequest.ajax(url, settings);
    }
  };

}());
