$(function() {
	var activeTarget,
      $window = $(window),
      offsets = [],
      targets = [],
      $nav = $('header nav a').each(function() {
				if (this.hash) {
					targets.push(this.hash);
        	offsets.push($(this.hash).offset().top);
				}
      });

  function processScroll(e) {
    var scrollTop = $window.scrollTop() + 50,
        i = offsets.length;

    for (i; i--;) {
      if (activeTarget != targets[i] && scrollTop >= offsets[i] && (!offsets[i + 1] || scrollTop <= offsets[i + 1])) {
        $nav.removeClass("sel").filter("[href=" + (activeTarget = targets[i]) + "]").addClass("sel");
        break;
      }
    }
  }

  $nav.click(function(e) {
		if (!this.hash)
			return;
		
    $('html, body').stop().animate({
        scrollTop: $(this.hash).offset().top - 50
    }, 1000,'easeInOutExpo');

    processScroll();
    e.preventDefault();
  });

  $window.scroll(processScroll).trigger("scroll");
});