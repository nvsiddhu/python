# -*- coding: utf-8 -*-

from django.core.urlresolvers import reverse

from decorators import GUARANTOR_SESSION_KEY
from forms import AccessForm, AccessFormTerms, RecaptchaForm
from iqh_domains import domains
from mock import MagicMock, patch
from tests.views.base_billpay_test import BaseBillPayTest, BaseBillPayCustomDomainTest
from views import PAYMENT_DATA_SESSION_KEY


class BillPayHomeTests(BaseBillPayTest):
    """ Tests default Bill Pay home page flows (without terms of use) """
    functional = True

    def test_root_redirect(self):
        """
        The root url (/) should redirect to quickpay home (/quickpay)
        """
        response = self.client.get('/')

        redirect_url = 'http://testserver' + reverse('home')

        self.assertEqual(response.status_code, 302)
        self.assertEqual(response['location'], redirect_url)

    def test_get_home_is_cms_from_model(self):
        """
        When cms is used from model
        The home url should load the find accounts page with no guarantor or
        card info in session.
        The page shall display a block of text with the organization's name.
        The page shall allow the user to search for accounts by entering the
        following required search criteria:
            guarantor's last name
            guarantor's date of birth
            access code.
        """
        # Verify if there is data in session, it gets wiped out
        self.login_user()
        self.set_payment_data_in_session()

        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)

        session = self.client.session
        self.assertIsNone(session[GUARANTOR_SESSION_KEY])
        self.assertIsNone(session[PAYMENT_DATA_SESSION_KEY])

        self.assertContains(response, self.org['name'])

        self.assertIsNotNone(response.context['form'])
        self.assertTrue(isinstance(response.context['form'], AccessForm))

        self.assertTemplateUsed(response, 'index.html')

    @patch('views.guarantor_login')
    def test_login_with_correct_data(self, mock_login):
        """
        The user should login when the data is entered correctly.
        """
        self.client.post(reverse('home'), {'last_name': 'Smith',
                                           'date_of_birth': '1/1/1970',
                                           'access_code': 'test1'})
        self.assertTrue(mock_login.called)

    @patch('views.guarantor_authenticate')
    def test_post_home_correct_data(self, guarantor_authenticate):
        """
        The user should not have to accept any terms of use if the client has
        not configured any.
        If all data is entered correctly on the find accounts page, the list of
        accounts should display.
        """
        guarantor_authenticate.return_value = 'g_1'

        response = self.client.post(reverse('home'), {'last_name':
            'Smith', 'date_of_birth': '1/1/1970', 'access_code': 'test1'})
        self.assertRedirects(response, reverse('view_accounts'))

        response = self.client.post(reverse('home'),
                                    {'last_name': 'Smith',
                                     'date_of_birth': '1/1/1970',
                                     'access_code': 'test1'}, follow=True)

        self.assertTemplateUsed(response, 'view_accounts.html')
        self.assertEqual(len(response.context['accts_amount_due']), 1)
        self.assertEqual(len(response.context['accts_no_amount_due']), 0)

    @patch('views.guarantor_authenticate')
    def test_post_home_incorrect_data(self, guarantor_authenticate):
        """
        If the user indicates to continue and the entered search criteria does
        not match data in the database, the system shall re-display the search
        form along with an error message.
        """
        guarantor_authenticate.return_value = None  # unable to authenticate user
        response = self.client.post(reverse('home'),
                                    {'last_name': 'smith',
                                     'date_of_birth': '1/1/1970',
                                     'access_code': 'wrong!'}, follow=True)
        self.assertTemplateUsed(response, 'index.html')
        self.assertContains(response, 'class="alert-message error"')

    @patch('views.guarantor_authenticate')
    def test_post_home_incorrect_birth_date_before_1900(self, guarantor_authenticate):
        """
        If the user indicates to continue and the entered search criteria does
        not match data in the database and the birth date entered is before 1900,
        the system shall re-display the search form along with an error message.
        """
        guarantor_authenticate.return_value = None  # unable to authenticate user
        response = self.client.post(reverse('home'),
                                    {'last_name': 'smith',
                                     'date_of_birth': '1/1/1890',
                                     'access_code': 'wrong!'}, follow=True)
        self.assertTemplateUsed(response, 'index.html')
        self.assertContains(response, 'class="alert-message error"')

    def test_domain_not_found(self):
        """
        If the domain cannot be located, the user should be directed to a 404
        not found page.
        """
        domains.delete(self.domain['domain_name'])
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 404)
        self.assertTemplateUsed(response, '404.html')


class BillPayHomeCustomizedTests(BaseBillPayCustomDomainTest):
    """
    Tests Bill Pay home page flows with customized terms and branding content.
    """
    functional = True

    def test_get_home_cms_from_model(self):
        """
        The home url should load the find accounts page with no guarantor or
        card info in session.
        The page shall display a block of text with the organization's name.
        The page shall allow the user to search for accounts by entering the
        following required search criteria:
            guarantor's last name
            guarantor's date of birth
            access code.
        If client terms of use are provided in model, display them face up in the search
        form.
        """
        # Verify if there is data in session, it gets wiped out
        self.login_user()
        self.set_payment_data_in_session()
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)

        session = self.client.session
        self.assertIsNone(session[GUARANTOR_SESSION_KEY])
        self.assertIsNone(session[PAYMENT_DATA_SESSION_KEY])

        self.assertContains(response, self.org['name'])

        self.assertIsNotNone(response.context['form'])
        self.assertTrue(isinstance(response.context['form'], AccessForm))
        self.assertIsNotNone(response.context['terms_form'])
        self.assertTrue(isinstance(response.context['terms_form'], AccessFormTerms))

        self.assertContains(response, 'quickpay terms content')
        self.assertTemplateUsed(response, 'index.html')

    def test_post_home_correct_data(self):
        """
        The user is required to accept the terms of use if the client has
        configured them.
        If all data is entered correctly on the find accounts page, the list of
        accounts should display.
        """
        response = self.client.post(reverse('home'),
                                    {'last_name': 'Smith', 'date_of_birth': '1/1/1970',
                                     'access_code': 'test1', 'quickpay_terms': True})
        self.assertRedirects(response, reverse('view_accounts'))

        response = self.client.post(reverse('home'),
                                    {'last_name': 'Smith', 'date_of_birth': '1/1/1970',
                                     'access_code': 'test1', 'quickpay_terms': True},
                                    follow=True)

        self.assertTemplateUsed(response, 'view_accounts.html')
        self.assertEqual(len(response.context['accts_amount_due']), 1)
        self.assertEqual(len(response.context['accts_no_amount_due']), 0)

    def test_post_home_correct_data_terms_not_accepted(self):
        """
        The user is required to accept the terms of use if the client has
        configured them.
        If all data is entered correctly on the find accounts page but the
        terms of use aren't accepted, the user should stay on the home page.
        """
        response = self.client.post(reverse('home'),
                                    {'last_name': 'Smith', 'date_of_birth': '1/1/1970',
                                     'access_code': 'test1', 'quickpay_terms': False})
        self.assertTemplateUsed(response, 'index.html')

    @patch('views.guarantor_authenticate')
    def test_post_home_incorrect_data(self, guarantor_authenticate):
        """
        If the user indicates to continue and the entered search criteria does
        not match data in the database, the system shall re-display the search
        form along with an error message and the terms of use if the client
        has configured them.
        """
        guarantor_authenticate.return_value = None  # unable to authenticate user

        response = self.client.post(reverse('home'),
                                    {'last_name': 'smith', 'date_of_birth': '1/1/1970',
                                     'access_code': 'wrong!', 'quickpay_terms': True},
                                    follow=True)

        self.assertTemplateUsed(response, 'index.html')
        self.assertContains(response, 'class="alert-message error"')
        self.assertIsNotNone(response.context['terms_form'])

    @patch('views.guarantor_authenticate')
    def test_captcha_displayed_after_5_failures(self, guarantor_authenticate):
        """
        home view should return context with recaptcha_form when the access_failures is equal to 5.
        """
        guarantor_authenticate.return_value = None
        for i in range(5):
            response = self.client.post(reverse('home'),
                                     {'last_name': 'jones', 'date_of_birth': '2/2/1971',
                                      'access_code': 'bad', 'quickpay_terms': True},
                                     follow=True)

        self.assertIsNotNone(response.context['form'])
        self.assertIsNotNone(response.context['terms_form'])
        self.assertIsNotNone(response.context['recaptcha_form'])

    @patch('views.guarantor_authenticate')
    def test_valid_captcha_when_captcha_not_displayed(self, guarantor_authenticate):
        """
        home view should return context without recaptcha_form when the captcha is not displayed
        (access_failures<5).
        """
        guarantor_authenticate.return_value = None
        response = self.client.post(reverse('home'),
                                     {'last_name': 'brown', 'date_of_birth': '2/2/1971',
                                      'access_code': 'code', 'quickpay_terms': True},
                                     follow=True)
        self.assertIsNotNone(response.context['form'])
        self.assertIsNotNone(response.context['terms_form'])
        self.assertFalse('recaptcha_form' in response.context)
        self.assertFalse('captcha_autofocus' in response.context)

    @patch('views.guarantor_authenticate')
    def test_valid_captcha_when_captcha_displayed_and_checked(self, guarantor_authenticate):
        """
        home view should return context without recaptcha_form when the captcha is displayed and checked by user.
        (access_failures<5).
        """
        guarantor_authenticate.return_value = None
        response = self.client.post(reverse('home'),
                                     {'last_name': 'brown', 'date_of_birth': '2/2/1971',
                                      'access_code': 'code', 'quickpay_terms': True, 'g-recaptcha-response': 'abcd'},
                                     follow=True)
        self.assertIsNotNone(response.context['form'])
        self.assertIsNotNone(response.context['terms_form'])
        self.assertFalse('recaptcha_form' in response.context)
        self.assertFalse('captcha_autofocus' in response.context)

    @patch('views.guarantor_authenticate')
    def test_valid_captcha_when_captcha_displayed_and_not_checked(self, guarantor_authenticate):
        """
        home view should return context with recaptcha_form when the captcha is displayed and not checked by user.
        (access_failures<5).
        """
        guarantor_authenticate.return_value = None
        response = self.client.post(reverse('home'),
                                     {'last_name': 'brown', 'date_of_birth': '2/2/1971',
                                      'access_code': 'code', 'quickpay_terms': True, 'g-recaptcha-response': ''},
                                     follow=True)
        self.assertIsNotNone(response.context['form'])
        self.assertIsNotNone(response.context['terms_form'])
        self.assertIsNotNone(response.context['recaptcha_form'])
        self.assertTrue(response.context['captcha_autofocus'])

