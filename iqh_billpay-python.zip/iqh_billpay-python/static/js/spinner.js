$(function(){
    $('.spinner-class').click(function(){

        if (this.clicked) {
            return false;
        }
        this.clicked = true;
        $(this).find('>:first-child').text(gettext('Please Wait'));
        $(this).addClass('disabled');
        $('#edit-payment-link').hide();
        $('#cancel-link').hide();
        setTimeout(function() {
            var opts = {lines: 10, length: 5, width: 4, radius: 5, color: '#fff', speed: 1, trail: 40, shadow: false};
            new Spinner(opts).spin($('.spinner-class')[0]);
        }, (1));
    });
});