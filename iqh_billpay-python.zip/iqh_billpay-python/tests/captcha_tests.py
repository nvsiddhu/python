# -*- coding: utf-8 -*-

from django.test import TestCase
from django.views.generic.edit import FormView
from mixins import CaptchaMixin
from mock import patch, MagicMock
from tests.utils import BillpayRequestFactory


class MockView(CaptchaMixin, FormView):

    template_name = 'confirm_payment.html'

    def get_captcha_key(self):
        return 'payment_failures'


@patch('mixins.get_cache')
class CaptchaMixinTests(TestCase):

    def setUp(self):
        self.view = MockView()
        self.request = BillpayRequestFactory().get('/')
        self.view.request = self.request

    def test_failures_in_context(self, get_cache):
        """
        get_context_data should return all the access failure attempts by the
        captcha key and set it into context.
        """
        cache = MagicMock()
        cache.get.return_value = 4
        get_cache.return_value = cache

        context = self.view.get_context_data()

        self.assertEquals(context['access_failures'], 4)
        self.assertIsNotNone(context['recaptcha_form'])

    @patch('mixins.CaptchaMixin.get_context_data')
    @patch.object(MockView, 'render_to_response')
    def test_form_invalid_when_access_failure_greater_than_5(self, render_to_response, mock_context, get_cache):
        """
        form_invalid should set the 'recaptcha_form' when the form is invalid and access failures is greater than 5.
        """
        cache = MagicMock()
        cache.get.return_value = 6
        get_cache.return_value = cache
        mock_context.return_value = {}

        self.view.form_invalid(MagicMock())
        self.assertIsNotNone(render_to_response.call_args[0][0].get('recaptcha_form'))

    @patch('mixins.CaptchaMixin.get_context_data')
    @patch.object(MockView, 'render_to_response')
    def test_form_invalid_when_access_failure_is_5(self, render_to_response, mock_context, get_cache):
        """
        form_invalid should not set the 'recaptcha_form' when the form is invalid and access failures is equal to 5.
        """
        cache = MagicMock()
        cache.get.return_value = 5
        get_cache.return_value = cache
        mock_context.return_value = {}

        self.view.form_invalid(MagicMock())
        self.assertIsNone(render_to_response.call_args[0][0].get('recaptcha_form'))

    def test_increment_access_failures(self, get_cache):
        """
        increment_access_failures should set a cache with the captcha key returned by get_captcha_key and a failure
        count incremented by 1.
        """
        cache = MagicMock()
        failure_count = 2
        cache.get.return_value = failure_count
        get_cache.return_value = cache

        self.view.increment_access_failures()

        cache.set.assert_called_once_with(self.view.get_captcha_key(), failure_count+1)

    def test_delete_access_failures_cache(self, get_cache):
        """
        delete_access_failures_cache should delete a cache with the captcha key returned by get_captcha_key.
        """
        cache = MagicMock()
        failure_count = 2
        cache.get.return_value = failure_count
        get_cache.return_value = cache

        self.view.delete_access_failures_cache()

        cache.delete.assert_called_once_with(self.view.get_captcha_key())

    def test_is_human_when_recaptcha_not_selected(self, get_cache):
        """
        is_human should return false when the recaptcha is not selected.
        """
        post_data = {'g-recaptcha-response': ''}
        self.view.request=BillpayRequestFactory().post('', post_data)
        self.assertFalse(self.view.is_human())

    def test_is_human_when_recaptcha_selected(self, get_cache):
        """
        is_human should return true when the recaptcha is selected.
        """
        post_data = {'g-recaptcha-response': 'abcd'}
        self.view.request=BillpayRequestFactory().post('', post_data)
        self.assertTrue(self.view.is_human())
