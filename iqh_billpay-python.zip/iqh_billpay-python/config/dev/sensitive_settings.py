# -*- coding: utf-8 -*-

# Oracle db for in-house dev deployments of iqh
DATABASES = {
    'default': {
        'ENGINE': 'axiom_oracle',
        'NAME': '(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=cerniqhdevorcl01.northamerica.cerner.net)(PORT=1521))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME = hlthlifdev)))',
        'USER': 'Billpay',
        'PASSWORD': 'bpdev',
    }
}

MEMCACHED_DATA_ENC_KEY = 'vn3cV8SC5Xp3sR6n'
IQH_SECRET = '5e4ffb2dff1643238975f808994520e7'

EDI_API_USER = 'IQHEALTH'
EDI_API_PASSWORD = '2018Cerner'

CC_OAUTH_CONSUMER_SECRET_IQH = '_ALSsaqoKlg0oMMbcQOzRr22TIJNhtCc'

SECRET_KEY = "b#-v!0m7)29u+va&3j&y==%ob+5worr_&k_yz0%bp*%u9an^&%"
SESSION_SALT = 'e70a3d51-610b-11e3-ae39-14109fdf6c31'

# iqh_dev user for S3 buckets
AWS_ACCESS_KEY_ID = 'AKIAI3A2ZGX6CGAH5OAA'
AWS_SECRET_ACCESS_KEY = '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'

# ReCaptcha v2 settings
G_RECAPTCHA_SITE_KEY = '6LclDk4UAAAAAMLslu9oxZE1_gvyvoDji860fG1S'
G_RECAPTCHA_SECRET_KEY = '6LclDk4UAAAAAB2LaOzqc15gDP9EDETnELPeprxn'
