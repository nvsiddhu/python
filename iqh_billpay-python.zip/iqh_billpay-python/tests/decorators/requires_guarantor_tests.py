# -*- coding: utf-8 -*-

from mock import Mock

from django.core.urlresolvers import reverse
from django.test import TestCase

from decorators import GUARANTOR_SESSION_KEY, requires_guarantor
from tests.utils import BillpayRequestFactory


class RequiresGuarantorTests(TestCase):

    def requires_guarantor_with_id_test(self):
        """
        requires_guarantor should set guarantor_id on the request
        when the user has an guarantor_id in session.
        """
        func = Mock()
        decorated_func = requires_guarantor(func)
        request = BillpayRequestFactory().get('/')
        request.session[GUARANTOR_SESSION_KEY] = 'g_1'

        decorated_func(request)

        self.assertEquals(request.guarantor_id, 'g_1')

    def requires_guarantor_with_no_id_test(self):
        """
        requires_guarantor should redirect the user to the home page if the
        user does not have an guarantor_id in session.
        """
        func = Mock()
        decorated_func = requires_guarantor(func)
        request = BillpayRequestFactory().get('/')

        response = decorated_func(request)

        self.assertEquals(response['location'], reverse('home'))
        self.assertFalse(hasattr(request, 'guarantor_id'))
