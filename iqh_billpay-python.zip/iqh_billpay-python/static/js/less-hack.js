/*
 * Fixes broken relative urls for local.
 * This should not be used when pushed to dev/cert/prod.
 * 
 */

var ss = document.getElementsByTagName("style");
for(var i=0;i<ss.length;i++) {
	ss[i].innerHTML = ss[i].innerHTML.replace('/static/less/default/../img', '/static/less/../img');
}