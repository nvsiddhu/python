# -*- coding: utf-8 -*-

from django.test import TestCase
from django.core.urlresolvers import reverse


class DomainMiddlewarePathTest(TestCase):
    """ Tests for the domain middleware's path exceptions. """

    def test_health_check_path_ignored(self):
        """
        A 200 response should occur when navigating to a path specified
        in the domain middleware ignore list for an unknown domain.
        """
        response = self.client.get(reverse('health_check'), SERVER_NAME="unknown.domain.com")
        self.assertEquals(200, response.status_code)

    def test_keep_alive_dependent_on_domain(self):
        """
        A 404 response should occur when navigating to a path not specified
        in the domain middleware ignore list for an unknown domain.
        """
        response = self.client.get(reverse('keep_alive'), SERVER_NAME="unknown.domain.com")
        self.assertEquals(404, response.status_code)
