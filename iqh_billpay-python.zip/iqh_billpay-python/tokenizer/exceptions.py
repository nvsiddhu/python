# -*- coding: utf-8 -*-

class EDISystemException(Exception):
    """
    A system error is returned from the EDI service.

    Return the user to the accounts page and display an error message asking the user try later.
    """
    pass

class MissingInfoException(Exception):
    """
    Return the user to the payments page and not display an error message.
    """
    pass

class GenericTokenException(Exception):
    """
    Return the user to the payments page and display an error message asking the user try again
    """
    pass

class TSEPSystemException(Exception):
    """
    A system error is returned from TSEP.

    Return the user to the accounts page and display an error message asking the user try later.
    """
    pass