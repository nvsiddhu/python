# -*- coding: utf-8 -*-

from django.test import TestCase
import json
import datetime
from mock import patch, MagicMock
from requests.exceptions import Timeout

from axiom_django.backends import get_backend

payments = get_backend('',
                       'iqh_payments.backends.hnam_rest_payments',
                       'PaymentBackend')

class TestGetPaymentResponse(TestCase):
    """
    Test that the _get_payment_response function handles all scenarios correctly
    """
    functional = True

    def setUp(self):
        self.guarantor_id = 'g1'
        self.account_id = '1234'
        self.payment_id = '9999'
        self.payment_receiver_id = 'BASELINE'
        self.oauth_client = MagicMock()
        self.base_service_url = 'http://mock-service.com'
        self.org_slug = 'baseline'

    @patch('iqh_payments.backends.hnam_rest_payments.PaymentBackend._update_payment')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.get')
    def get_payment_response_successful_test(self, MockGet, MockUpdatePayment):
        """
        when edi returns a BillpayResponse the payment should be updated in patient accounting
        when the payment is successful, the payment in patient accounting should be updated with
        the amount of the payment
        """

        amount = '304.23'
        interchange_id = '747474'

        response = MagicMock
        response.status_code = 200
        response.headers = {'content-length': 4}
        response.text = json.dumps({
                'billpayResponse': {
                    'billpayStatus': {
                        'statusCode': '00',
                        'interchangeId': interchange_id,
                        'amount': amount,
                        'amountRequested': amount
                    }
                }
            })
        response.elapsed = datetime.timedelta(0)
        MockGet.return_value = response

        payment_response = payments._get_payment_response(
                self.guarantor_id,
                self.account_id,
                self.payment_id,
                self.payment_receiver_id,
                self.oauth_client,
                self.base_service_url,
                self.org_slug)

        self.assertEquals(payment_response, ('success', {'payment_id': self.payment_id}))
        self.assertTrue(MockUpdatePayment.called)
        self.assertEquals(MockUpdatePayment.call_args[0][0],
                u'{0}/guarantors/{1}/guarantorPatientAccounts/{2}/payment/{3}'.format(
                        self.base_service_url,
                        self.guarantor_id,
                        self.account_id,
                        self.payment_id))
        payment_content = MockUpdatePayment.call_args[0][1]
        self.assertEquals(payment_content['paymentStatus'], 'POST')
        self.assertEquals(payment_content['transactionId'], interchange_id)
        self.assertEquals(payment_content['amount'], amount)

    @patch('iqh_payments.backends.hnam_rest_payments.PaymentBackend._update_payment')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.get')
    def get_payment_response_edi_success_payment_fail_test(self, MockGet, MockUpdatePayment):
        """
        when edi returns a BillpayResponse the payment should be updated in patient accounting
        when the payment fails, the payment in patient accounting should be cancelled with
        the reason for cancellation
        """

        amount = '304.23'
        interchange_id = '747474'

        response = MagicMock
        response.status_code = 200
        response.headers = {'content-length': 4}
        response.text = json.dumps({
                'billpayResponse': {
                    'billpayStatus': {
                        'statusCode': '03',
                        'interchangeId': interchange_id,
                        'amount': amount,
                        'amountRequested': amount
                    }
                }
            })
        response.elapsed = datetime.timedelta(0)
        MockGet.return_value = response

        payment_response = payments._get_payment_response(
                self.guarantor_id,
                self.account_id,
                self.payment_id,
                self.payment_receiver_id,
                self.oauth_client,
                self.base_service_url,
                self.org_slug)

        self.assertEquals(payment_response, ('failure', {'error_code': 'insufficient_funds'}))
        self.assertTrue(MockUpdatePayment.called)
        payment_content = MockUpdatePayment.call_args[0][1]
        self.assertEquals(payment_content['paymentStatus'], 'CANCEL')
        self.assertEquals(payment_content['transactionId'], interchange_id)
        self.assertEquals(payment_content['statusReason'], 'INSUFFICIENT_FUNDS')

    @patch('iqh_payments.backends.hnam_rest_payments.PaymentBackend._update_payment')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.get')
    def get_payment_response_edi_error_test(self, MockGet, MockUpdatePayment):
        """
        when edi returns an ack response containing errors the payment should be cancelled
        in patient accounting
        """

        response = MagicMock
        response.status_code = 200
        response.headers = {'content-length': 4}
        response.text = json.dumps({
                'ack': {
                    'errors': {
                        'error': [{'errorCode': 'S9'}],
                    }
                }
            })
        response.elapsed = datetime.timedelta(0)
        MockGet.return_value = response

        payment_response = payments._get_payment_response(
                self.guarantor_id,
                self.account_id,
                self.payment_id,
                self.payment_receiver_id,
                self.oauth_client,
                self.base_service_url,
                self.org_slug)

        self.assertEquals(payment_response, ('failure', {'error_code': 'submission_failure'}))
        self.assertTrue(MockUpdatePayment.called)
        payment_content = MockUpdatePayment.call_args[0][1]
        self.assertEquals(payment_content['paymentStatus'], 'CANCEL')
        self.assertEquals(payment_content['statusReason'], 'GENERAL_SYSTEM_FAILURE')

    @patch('iqh_payments.backends.hnam_rest_payments.PaymentBackend._update_payment')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.get')
    def get_payment_response_edi_error_S6_test(self, MockGet, MockUpdatePayment):
        """
        when edi returns an ack response containing the S6 error a timeout should be returned
        as we don't know if the payment was successful or not
        """

        response = MagicMock
        response.status_code = 200
        response.headers = {'content-length': 4}
        response.text = json.dumps({
                'ack': {
                    'errors': {
                        'error': [{'errorCode': 'S6'}],
                    }
                }
            })
        response.elapsed = datetime.timedelta(0)
        MockGet.return_value = response

        payment_response = payments._get_payment_response(
                self.guarantor_id,
                self.account_id,
                self.payment_id,
                self.payment_receiver_id,
                self.oauth_client,
                self.base_service_url,
                self.org_slug)

        self.assertEquals(payment_response, ('timeout', {'payment_id': self.payment_id}))
        self.assertFalse(MockUpdatePayment.called)

    @patch('iqh_payments.backends.hnam_rest_payments.PaymentBackend._update_payment')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.get')
    def get_payment_response_204_test(self, MockGet, MockUpdatePayment):
        """
        when edi returns a 204 response a timeout should be returned and the client should be called
        only once.
        """
        response = MagicMock
        response.status_code = 204
        response.headers = {'content-length': 4}
        response.elapsed = datetime.timedelta(0)
        response.text = ''
        MockGet.return_value = response
        payment_response = payments._get_payment_response(
                self.guarantor_id,
                self.account_id,
                self.payment_id,
                self.payment_receiver_id,
                self.oauth_client,
                self.base_service_url,
                self.org_slug)

        self.assertEquals(payment_response, ('timeout', {'payment_id': self.payment_id}))
        self.assertFalse(MockUpdatePayment.called)
        self.assertEquals(MockGet.call_count, 1)

    @patch('iqh_payments.backends.hnam_rest_payments.PaymentBackend._update_payment')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.get')
    def get_payment_response_timeout_test(self, MockGet, MockUpdatePayment):
        """
        when edi service call times out a timeout should be returned and the client
        should be called only once.
        """
        MockGet.side_effect = Timeout('A timeout has occured')
        payment_response = payments._get_payment_response(
                self.guarantor_id,
                self.account_id,
                self.payment_id,
                self.payment_receiver_id,
                self.oauth_client,
                self.base_service_url,
                self.org_slug)

        self.assertEquals(payment_response, ('timeout', {'payment_id': self.payment_id}))
        self.assertFalse(MockUpdatePayment.called)
        self.assertEquals(MockGet.call_count, 1)

    @patch('iqh_payments.backends.hnam_rest_payments.PaymentBackend._update_payment')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.get')
    def get_payment_response_exception_test(self, MockGet, MockUpdatePayment):
        """
        when edi service call raises an exception a timeout should be returned and we do not
        want to continue requesting edi for the status of the payment.
        """
        MockGet.side_effect = Exception('A error has occured')
        payment_response = payments._get_payment_response(
                self.guarantor_id,
                self.account_id,
                self.payment_id,
                self.payment_receiver_id,
                self.oauth_client,
                self.base_service_url,
                self.org_slug)

        self.assertEquals(payment_response, ('timeout', {'payment_id': self.payment_id}))
        self.assertFalse(MockUpdatePayment.called)
        self.assertEquals(MockGet.call_count, 1)

    @patch('iqh_payments.backends.hnam_rest_payments.PaymentBackend._update_payment')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.get')
    def get_payment_response_edi_error_status_test(self, MockGet, MockUpdatePayment):
        """
        when edi returns a status other than 200 a timeout should be returned
        as we weren't able to get the payment status
        """

        response = MagicMock
        response.status_code = 500
        response.text = 'internal server error'
        response.headers = {'content-length': 4}
        response.elapsed = datetime.timedelta(0)
        MockGet.return_value = response

        payment_response = payments._get_payment_response(
                self.guarantor_id,
                self.account_id,
                self.payment_id,
                self.payment_receiver_id,
                self.oauth_client,
                self.base_service_url,
                self.org_slug)

        self.assertEquals(payment_response, ('timeout', {'payment_id': self.payment_id}))
        self.assertFalse(MockUpdatePayment.called)
        self.assertEquals(MockGet.call_count, 1)
