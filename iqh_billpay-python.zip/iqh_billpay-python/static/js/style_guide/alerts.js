/* 
 * Alerts
 * Copyright(c) 2011- Cerner Corporation 
 * 
 * alerts.js v1.0
 */

!function($) {
	$(window).delegate(".alert-message .close-button", "click", function closeAlert(e) {
		e.preventDefault();
		var alert = $(this).closest(".alert-message");
    alert.fadeOut(300, function() {alert.remove()});
  });
	
	$.fn.alertBox = function(options) {
		var settings = {
			type : null,
			duration: 300,
			message: null,
			show_close: true
		};
		
		return this.each(function() {
			if (options)
				$.extend(settings, options);
			
			var alert_box = $('<div class="alert-message"><div>').hide();
			if (settings.show_close)
				$(alert_box).append('<a class="close-button" href="#">Close</a>'); 
			
			if (settings.message)
				$(alert_box).append('<p>' + settings.message + '</p>');
			
			if (settings.type)
				$(alert_box).addClass(settings.type);
				
			$(this).prepend(alert_box);
			$(alert_box).fadeIn(settings.duration);
		});	
	};
	
}(window.jQuery);
