# -*- coding: utf-8 -*-

from django.test import TestCase

from axiom_django.backends import get_backend

payments = get_backend('',
                       'iqh_payments.backends.hnam_rest_payments',
                       'PaymentBackend')


class TestGetStatusReason(TestCase):

    def test_declined(self):
        """
        _get_status_reason should return "GENERAL_SYSTEM_FAILURE"
        when the code given is card declined.
        """
        code = payments._get_status_reason('01')
        self.assertEquals(code, 'GENERAL_SYSTEM_FAILURE')

    def test_insufficient_funds(self):
        """
        _get_status_reason should translate the insufficient funds
        error code to a valid status reason for the payment service.
        """
        code = payments._get_status_reason('03')
        self.assertEquals(code, 'INSUFFICIENT_FUNDS')

    def test_invalid_card(self):
        """
        _get_status_reason should translate the invalid card
        error code to a valid status reason for the payment service.
        """
        code = payments._get_status_reason('04')
        self.assertEquals(code, 'INVALID_CC_NUMBER')

    def test_invalid_account(self):
        """
        _get_status_reason should translate the invalid account
        error code to a valid status reason for the payment service.
        """
        code = payments._get_status_reason('05')
        self.assertEquals(code, 'INVALID_CC_NUMBER')

    def test_account_closed(self):
        """
        _get_status_reason should translate the account closed
        error code to a valid status reason for the payment service.
        """
        code = payments._get_status_reason('06')
        self.assertEquals(code, 'INVALID_CC_NUMBER')

    def test_invalid_check_number(self):
        """
        _get_status_reason should translate the invalid_check_number
        error code to a valid status reason for the payment service.
        """
        code = payments._get_status_reason('10')
        self.assertEquals(code, 'DECLINED')

    def test_invalid_routing_number(self):
        """
        _get_status_reason should translate the invalid_routing_number
        error code to a valid status reason for the payment service.
        """
        code = payments._get_status_reason('12')
        self.assertEquals(code, 'DECLINED')

    def test_duplicate_check(self):
        """
        _get_status_reason should translate the duplicate_check
        error code to a valid status reason for the payment service.
        """
        code = payments._get_status_reason('13')
        self.assertEquals(code, 'DECLINED')

    def test_card_expired(self):
        """
        _get_status_reason should translate the card expired
        error code to a valid status reason for the payment service.
        """
        code = payments._get_status_reason('20')
        self.assertEquals(code, 'CARD_EXPIRED')

    def test_incorrect_address(self):
        """
        _get_status_reason should translate the incorrect address
        error code to a valid status reason for the payment service.
        """
        code = payments._get_status_reason('21')
        self.assertEquals(code, 'INVALID_ADDRESS')

    def test_incorrect_security_code(self):
        """
        _get_status_reason should translate the incorrect cvv
        error code to a valid status reason for the payment service.
        """
        code = payments._get_status_reason('22')
        self.assertEquals(code, 'INVALID_CVV')

    def test_incorrect_address_and_security_code(self):
        """
        _get_status_reason should translate the incorrect address and cvv
        error code to a valid status reason for the payment service.
        """
        code = payments._get_status_reason('23')
        self.assertEquals(code, 'INVALID_ADDRESS')

    def test_other_codes(self):
        """
        _get_status_reason should return 'GENERAL_SYSTEM_FAILURE' when the
        code given is not code with a dedicated reason.
        """
        code = payments._get_status_reason('S2')
        self.assertEquals(code, 'GENERAL_SYSTEM_FAILURE')

        code = payments._get_status_reason('S3')
        self.assertEquals(code, 'GENERAL_SYSTEM_FAILURE')

        code = payments._get_status_reason('S4')
        self.assertEquals(code, 'GENERAL_SYSTEM_FAILURE')

        code = payments._get_status_reason('S7')
        self.assertEquals(code, 'GENERAL_SYSTEM_FAILURE')

        code = payments._get_status_reason('S8')
        self.assertEquals(code, 'GENERAL_SYSTEM_FAILURE')

        code = payments._get_status_reason('S9')
        self.assertEquals(code, 'GENERAL_SYSTEM_FAILURE')

        code = payments._get_status_reason('401')
        self.assertEquals(code, 'GENERAL_SYSTEM_FAILURE')
