# -*- coding: utf-8 -*-

import unittest

from mock import patch

from tokenizer.request_metrics import _gen_keys
from tokenizer.request_metrics import record_measured_request


@patch('tokenizer.request_metrics.statsd')
class RecordMeasuredRequestTests(unittest.TestCase):

    def test_timeout(self, statsd_client):
        """
        record_measured_request should increment the 'timeout' metric and record the
        time when the error is 'timeout'.
        """
        record_measured_request(['key1'], None, '1000', error='timeout')
        statsd_client.increment.assert_called_with('key1.timeout')
        self.assertTrue(statsd_client.timing.called)

    def test_unknown_error(self, statsd_client):
        """
        record_measured_request should increment the 'unknown_error' metric and record the
        time when the error is 'unknown_error'.
        """
        record_measured_request(['key1'], None, '1000', error='unknown_error')
        statsd_client.increment.assert_called_with('key1.unknown_error')
        self.assertTrue(statsd_client.timing.called)

    def test_no_error_code(self, statsd_client):
        """
        record_measured_request should not increment a invalid metric when the error is
        neither 'unknown_error' or 'timeout'. Regardless, of the error, the time should
        still be recorded.
        """
        record_measured_request(['key1'], None, '1000', 'random_error')
        self.assertFalse(statsd_client.increment.called)
        self.assertTrue(statsd_client.timing.called)

    def test_status_code(self, statsd_client):
        """
        record_measured_request should increment the status code when the status code is not none.
        """
        record_measured_request(['key1'], '200', '1000')
        statsd_client.increment.assert_called_with('key1.200')

    def test_status_code_set_to_none(self, statsd_client):
        """
        record_measured_request should not increment the status code when code is set
        to None. This occurs when the response times out or unexpectectly fails. The errors
        'unknown_error' and 'timeout' will cover for this status code.
        """
        record_measured_request(['key1'], None, '1000')
        self.assertFalse(statsd_client.increment.called)

    def test_invalid_response_time(self, statsd_client):
        """
        record_measured_request should NOT record the response time when the time is NOT a string representation
        of an integer.
        """
        record_measured_request(['key1'], '200', 'abc')
        self.assertFalse(statsd_client.timing.called)

    def test_record_response_time(self, statsd_client):
        """
        record_measured_request should record the response time when the time is a string representation
        of an integer.
        """
        record_measured_request(['key1'], '200', '1000')
        statsd_client.timing.assert_called_with('key1', 1000)


class GenKeysTests(unittest.TestCase):

    def test_one_key_no_sub_keys(self):
        """
        _gen_keys should simply yield the given single key when no sub-key is given.
        """
        keys = ['key1']
        self.assertEquals(['key1'], list(_gen_keys(keys)))

    def test_multiple_keys_no_sub_keys(self):
        """
        _gen_keys should simply yield the given multiple keys when no sub-key is given.
        """
        keys = ['key1', 'key2']
        self.assertEquals(['key1', 'key2'], list(_gen_keys(keys)))

    def test_one_key_with_sub_keys(self):
        """
        _gen_keys should yield the single key enhanced by the sub-key when a sub-key is given.
        """
        keys = ['key1']
        self.assertEquals(['key1.sub'], list(_gen_keys(keys, 'sub')))

    def test_multiple_keys_with_sub_keys(self):
        """
        _gen_keys should yield the multiple keys enhanced by the sub-key when a sub-key is given.
        """
        keys = ['key1', 'key2']
        self.assertEquals(['key1.sub', 'key2.sub'], list(_gen_keys(keys, 'sub')))
