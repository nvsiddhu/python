# -*- coding: utf-8 -*-

from sensitive_settings import *
import os

# Temporarily set to True to investigate slowness
DEBUG = False
DEPLOYMENT_MODE = "dev"

STATIC_URL = 'https://devcrnst.hax/s/billpay/'
STATIC_ROOT =  os.environ.get('STATIC_ROOT', '/opt/djangoprojects/billpay-static/')

# Disable Requests verififcation of SSL certs in local/dev/cert, Enable in staging/prod
VERIFY_SSL = False

# Mongo is used to write logs. This is the "dev" mongo instance.
MONGODB_CONNECTION_URI = 'mongodb://mongo01.dev.hax,mongo02.dev.hax,admin.dev.hax'

# Session cookie for 15 minutes.
SESSION_COOKIE_AGE = 60 * 15
SESSION_COOKIE_SECURE = True

DATABASE_CONNECTION_POOL_SIZE = 5
DATABASE_CONNECTION_MAX_OVERFLOW = 10
DATABASE_CONNECTION_TIMEOUT = 30

CC_OAUTH_ACCESS_TOKEN_URL = 'https://api.devcernercare.com/oauth/access'
CC_OAUTH_CONSUMER_KEY_IQH = '4f813eda-d402-4db1-b05c-432b78f505e2'

EMAIL_HOST = 'smtprr.cerner.com'

EDI_SUBMITTER_LOOKUP_API_URL = 'http://vipercert.edi.cerner.corp/edi/'
EDI_BILLPAY_API_URL = 'https://ipedipcicrt101.northamerica.cerner.net/edi/epayment/'

EDI_TOKEN_REQUEST_API_URL = 'https://ipedipcicrt101.northamerica.cerner.net/edi/epayment/cors/token'
TOKENIZATION_SERVICE_TIMEOUT = 40000

TSEP_TRANSIT_DOMAIN = 'https://stagegw.transnox.com'

STATSD_HOST = 'statsd.dev.hax'
STATSD_PORT = 8125

#connection timeout for caches in milliseconds
CACHE_CONNECTION_TIMEOUT = 70

CACHE_HOSTS = ['devcache.dev.hax', 'devcache02.dev.hax']

# TODO: look into making Django's cache session backend use a specific
    # memcached namespace. If it supports it, then this default should
    # use Quiescent and we need to config up a billpay.django_sessions cache.
    # Otherwise, we'll continue to use 'default', but should submit a patch
    # to Django to allow for a specific cache namespace to be used.
DEFAULT_CACHE = {
    'default': {
        'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
        'LOCATION': 'bpapp01.dev.hax:11700',
        'VERSION': '1',
        'OPTIONS':{
            'connect_timeout': CACHE_CONNECTION_TIMEOUT,
            'hash': 'murmur',
            'distribution': 'consistent',
        }
    }
}

DEFAULT_FILE_STORAGE = 'storages.backends.s3boto.S3BotoStorage'
AWS_STORAGE_BUCKET_NAME = 'cerner-healthelife-iqh-public-dev'
AWS_S3_CUSTOM_DOMAIN = 'dyp8fyf0zqbqv.cloudfront.net'
AWS_S3_FILE_OVERWRITE = False
AWS_QUERYSTRING_AUTH = False

AWS_HEADERS = {
    'x-amz-server-side-encryption': 'AES256',
}

THEMING_ACCESS_TOKEN = '5292e2c3-3a28-49b4-89fd-5ab3c6a78551'
VIRTUAL_ENV_BIN = '/opt/.virtualenvs/iqh_billpay/bin'
