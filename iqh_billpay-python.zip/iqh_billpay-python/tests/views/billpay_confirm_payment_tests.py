# -*- coding: utf-8 -*-

from urlparse import urlparse

from django.core.urlresolvers import reverse, resolve
from django.test import TestCase
from mock import patch, MagicMock
from tests.utils import BillpayRequestFactory
from tests.views.base_billpay_test import GuarantorLoggedinTestCase
from views import ConfirmPaymentView


class BillpayConfirmPaymentTests(GuarantorLoggedinTestCase):
    """ Tests Bill Pay confirm payment flows """

    def setUp(self):
        super(BillpayConfirmPaymentTests, self).setUp()

        self.form_data = {
                'payment_amount': 999, 'interchange_id': '123', 'masked_card_number': '************1111',
                'card_type': 'Visa', 'expiration_date': '2099-1-1', 'payer_name': 'Jane Smith',
                'address': '200 1st St.', 'city': 'Chicago', 'state': 'IL', 'postal_code': '99999',
                'merchant_id': '123456789'}
        self.set_payment_data_in_session(self.form_data)
        self.set_token_reference_id_session()

    @patch('views.BillpayTemplateConfig.objects.get')
    def test_get_confirm_payment_default_content(self, template_model_objects_get):
        """
        When we use default template payment_terms.html
        The Confirm Payment page should display the following details about the account:
            facility name, patient name and masked account number.
        The Confirm Payment page should display the following details about the payment:
            payment amount, masked card number, card type, expiration date,
            name on credit card and billing address.
        The Confirm Payment page should display the balance after payment.
        The Confirm Payment page shall allow the user to return to the View Accounts page.
        The Confirm Payment page shall allow the user to return to the Make Payment page to edit the payment.
        The Confirm Payment page shall display payment terms that the user accepts by confirming payment
        """
        quickpay_template_object = MagicMock()
        quickpay_template_object.template_html_content = 'payment terms content'
        template_model_objects_get.return_value = quickpay_template_object

        response = self.client.get(reverse('confirm_payment', args=['1234']))

        self.assertContains(response, response.context['acct']['facility'])
        self.assertContains(response, response.context['acct']['patient_name'])
        self.assertContains(response, response.context['acct']['masked_account_number'])
        self.assertContains(response, self.form_data['payment_amount'])
        self.assertContains(response, '************1111')
        self.assertContains(response, 'Visa')
        self.assertContains(response, '01/2099')
        self.assertContains(response, self.form_data['payer_name'])
        self.assertContains(response, self.form_data['address'])
        self.assertContains(response, self.form_data['city'])
        self.assertContains(response, self.form_data['state'])
        self.assertContains(response, self.form_data['postal_code'])
        amount_left = response.context['acct']['amount_due'] - self.form_data['payment_amount']
        self.assertContains(response, 'payment-terms')
        self.assertContains(response, amount_left)
        self.assertContains(response, reverse('view_accounts'))
        self.assertContains(response, reverse('account_payment', args=['1234']))
        self.assertTrue(template_model_objects_get.called)
        self.assertContains(response, "payment terms content")

    @patch('views.BillpayTemplateConfig.objects.get')
    def test_get_confirm_payment_custom(self, template_model_objects_get):
        """
        When we use model to get custom payment terms content
        The Confirm Payment page should display the following details about the account:
            facility name, patient name and masked account number.
        The Confirm Payment page should display the following details about the payment:
            payment amount, masked card number, card type, expiration date,
            name on credit card and billing address.
        The Confirm Payment page should display the balance after payment.
        The Confirm Payment page shall allow the user to return to the View Accounts page.
        The Confirm Payment page shall allow the user to return to the Make Payment page to edit the payment.
        The Confirm Payment page shall display payment terms that was configured by client
            and that the user accepts by confirming payment
        """
        quickpay_template_object = MagicMock()
        quickpay_template_object.template_html_content = 'payment terms content'
        template_model_objects_get.return_value = quickpay_template_object

        response = self.client.get(reverse('confirm_payment', args=['1234']))
        self.assertContains(response, response.context['acct']['facility'])
        self.assertContains(response, response.context['acct']['patient_name'])
        self.assertContains(response, response.context['acct']['masked_account_number'])
        self.assertContains(response, self.form_data['payment_amount'])
        self.assertContains(response, '************1111')
        self.assertContains(response, 'Visa')
        self.assertContains(response, '01/2099')
        self.assertContains(response, self.form_data['payer_name'])
        self.assertContains(response, self.form_data['address'])
        self.assertContains(response, self.form_data['city'])
        self.assertContains(response, self.form_data['state'])
        self.assertContains(response, self.form_data['postal_code'])
        amount_left = response.context['acct']['amount_due'] - self.form_data['payment_amount']
        self.assertContains(response, 'payment terms content')
        self.assertContains(response, amount_left)
        self.assertContains(response, reverse('view_accounts'))
        self.assertContains(response, reverse('account_payment', args=['1234']))

    @patch('views.payments.charge_by_token')
    def test_post_confirm_payment_failure(self, charge_by_token):
        """
        The user should be redirected back to the Make Payment page with
        the payment amount, name, and billing address being prepopulated when
        the submission of the payment failed.
        """
        charge_by_token.return_value = ('failure', {'error_code': 'declined'})

        response = self.client.post(reverse('confirm_payment', args=['1234']), {}, follow=True)
        self.assertRedirects(response, reverse('account_payment', args=['1234']))

        self.assertContains(response, self.form_data['payment_amount'])
        self.assertContains(response, self.form_data['payer_name'])
        self.assertContains(response, self.form_data['address'])
        self.assertContains(response, self.form_data['city'])
        self.assertContains(response, self.form_data['state'])
        self.assertContains(response, self.form_data['postal_code'])


class ConfirmPaymentViewGetTests(TestCase):

    def setUp(self):

        self.request = BillpayRequestFactory(guarantor_id='98765', account_id='12345').get('/')

        self.view = ConfirmPaymentView()
        self.view.request = self.request
        self.view.kwargs = {'account_id': '12345'}

    def test_no_token_reference_id(self):
        """
        ConfirmPaymentView should redirect the user back to the account payment
        page when the token reference id that is needed to submit a payment is
        not in session.
        """
        BillpayRequestFactory.set_payment_data_in_session(self.request)
        response = self.view.get(self.request)

        self.assertEquals(response.status_code, 302)
        self.assertEquals(resolve(urlparse(response['location'])[2]).url_name, "account_payment")

    def test_no_payment_data(self):
        """
        ConfirmPaymentView should redirect the user back to the account payment
        page when the required payment data to submit a payment is not in session.
        """
        BillpayRequestFactory.set_token_reference_id_session(self.request)

        response = self.view.get(self.request)

        self.assertEquals(response.status_code, 302)
        self.assertEquals(resolve(urlparse(response['location'])[2]).url_name, "account_payment")


class ConfirmPaymentViewPostTests(TestCase):

    def setUp(self):
        self.request = BillpayRequestFactory(guarantor_id='98765', account_id='1234').post('/', {})
        self.payment_data = {
            'payment_amount': 1000, 'interchange_id': '123', 'masked_card_number': 'xxxx-xxxx-xxxx-1111',
            'card_type': 'Visa', 'expiration_date': '11/2014', 'payer_name': 'Jane Smith',
            'address': '123 Main St.', 'city': 'Chicago', 'state': 'IL', 'postal_code': '64117',
            'merchant_id': '123456789'
        }

        BillpayRequestFactory.set_payment_data_in_session(self.request, self.payment_data)
        BillpayRequestFactory.set_token_reference_id_session(self.request)

        self.view = ConfirmPaymentView()
        self.view.request = self.request
        self.view.kwargs = {'account_id': '1234'}

    @patch('views.get_cache')
    @patch('views.payments.charge_by_token')
    def test_post_confirm_payment_success(self, charge_by_token, get_cache):
        """
        The user should be redirected to the receipt page when the payment
        is submitted successfully. The failure counter should also be cleared
        from cache.
        """
        cache = MagicMock()
        get_cache.return_value = cache

        charge_by_token.return_value = ('success', {'payment_id': '600'})

        response = self.view.post(self.request)

        # assert the user was redirected to the payment receipt page
        self.assertEquals(response.status_code, 302)
        self.assertEquals(resolve(urlparse(response['location'])[2]).url_name, "payment")
        # assert the redirected url should not have any url query params
        self.assertEquals(urlparse(response['location']).query, '')

        # assert the charge by token was called and we passed the correct values to the function
        self.assertTrue(charge_by_token.called)
        charge_by_token.assert_called_with(self.request.org['slug'], self.request.guarantor_id,
                self.view.kwargs['account_id'], self.request.acct['payment_receiver_id'],
                self.payment_data['payment_amount'], self.payment_data['payer_name'],
                self.payment_data['address'], self.payment_data['city'],
                self.payment_data['state'], self.payment_data['postal_code'],
                self.payment_data['interchange_id'], self.payment_data['masked_card_number'],
                self.payment_data['card_type'], self.payment_data['expiration_date'],
                self.payment_data['merchant_id'], '999')

        # should clear payment failed cache since the payment was successful
        self.assertTrue(cache.delete.called)

    @patch('views.get_cache')
    @patch('views.payments.charge_by_token')
    def test_post_confirm_payment_timeout(self, charge_by_token, get_cache):
        """
        The user should be redirected to the receipt page with a url param of i=t
        when the charging of the payment timed out.
        """
        mock_cache = MagicMock()
        get_cache.return_value = mock_cache
        charge_by_token.return_value = ('timeout', {'payment_id': '600'})

        response = self.view.post(self.request)

        # assert the user was redirected to the payment receipt page
        self.assertEquals(response.status_code, 302)
        self.assertEquals(resolve(urlparse(response['location'])[2]).url_name, "payment")
        # assert the redirected url has the query param that signifies the charge timed out
        self.assertEquals(urlparse(response['location']).query, 'i=t')
        # assert the timeout payment status was set in cache. This ensures we approriately
        # clear the cache when payment is successfully charged.
        self.assertTrue(mock_cache.set.called)

    @patch('views.get_cache')
    @patch('views.messages')
    @patch('views.payments.charge_by_token')
    def test_post_confirm_payment_submission_failure(self, charge_by_token, messages, get_cache):
        """
        The user should be redirected to the Make Payment page with text explaining
        that something went wrong when the submission raised an unexpected error.
        """
        cache = MagicMock()
        get_cache.return_value = cache

        charge_by_token.return_value = ('failure', {'error_code': 'submission_failure'})
        response = self.view.post(self.request)

        error_message = messages.add_message.call_args[0][2]
        self.assertEquals(error_message,
                '<h3>Submission Failure</h3><p>We were unable to process your payment. Please try again.</p>')

        self.assertEquals(resolve(urlparse(response['location'])[2]).url_name, "account_payment")

        # should not update the payment failed cache since the payment did not go through
        self.assertFalse(cache.set.called)

    @patch('views.get_cache')
    @patch('views.messages')
    @patch('views.payments.charge_by_token')
    def test_post_confirm_payment_card_declined(self, charge_by_token, messages, get_cache):
        """
        The user should be redirected to the Make Payment page with text explaining
        that something went wrong when the declined status is returned.
        The system should also increment a counter that tracks the number of failed attempts.
        """
        cache = MagicMock()
        cache.get.return_value = 0
        get_cache.return_value = cache

        charge_by_token.return_value = ('failure', {'error_code': 'declined'})
        response = self.view.post(self.request)

        error_message = messages.add_message.call_args[0][2]
        self.assertEquals(error_message,
                '<h3>Submission Failure</h3><p>We were unable to process your payment. Please try again.</p>')

        self.assertEquals(resolve(urlparse(response['location'])[2]).url_name, "account_payment")
        self._assert_failed_counter_has_incremented(cache)

    @patch('views.get_cache')
    @patch('views.messages')
    @patch('views.payments.charge_by_token')
    def test_post_confirm_payment_invalid_security_code(self, charge_by_token, messages, get_cache):
        """
        The user should be redirected to the Make Payment page with text explaining
        a proccessing error occured when security code is invalid. The system should
        also increment a counter that tracks the number of failed attempts.
        """
        cache = MagicMock()
        cache.get.return_value = 0
        get_cache.return_value = cache

        charge_by_token.return_value = ('failure', {'error_code': 'incorrect_security_code'})
        self._assert_bank_error_message_and_make_payment_page(messages)
        self._assert_failed_counter_has_incremented(cache)

    @patch('views.get_cache')
    @patch('views.messages')
    @patch('views.payments.charge_by_token')
    def test_post_confirm_payment_invalid_address_and_security_code(self, charge_by_token, messages, get_cache):
        """
        The user should be redirected to the Make Payment page with text explaining
        a proccessing error occured when the address and security code is invalid.
        The system should also increment a counter that tracks the number of failed attempts.
        """
        cache = MagicMock()
        cache.get.return_value = 0
        get_cache.return_value = cache

        charge_by_token.return_value = ('failure', {'error_code': 'incorrect_address_and_security_code'})
        self._assert_bank_error_message_and_make_payment_page(messages)
        self._assert_failed_counter_has_incremented(cache)

    @patch('views.get_cache')
    @patch('views.messages')
    @patch('views.payments.charge_by_token')
    def test_post_confirm_payment_invalid_address(self, charge_by_token, messages, get_cache):
        """
        The user should be redirected to the Make Payment page with text explaining
        a proccessing error occured when the address is invalid.
        The system should also increment a counter that tracks the number of failed attempts.
        """
        cache = MagicMock()
        cache.get.return_value = 0
        get_cache.return_value = cache

        charge_by_token.return_value = ('failure', {'error_code': 'incorrect_address'})
        self._assert_bank_error_message_and_make_payment_page(messages)
        self._assert_failed_counter_has_incremented(cache)

    @patch('views.get_cache')
    @patch('views.messages')
    @patch('views.payments.charge_by_token')
    def test_post_confirm_payment_invalid_account(self, charge_by_token, messages, get_cache):
        """
        The user should be redirected to the Make Payment page with text explaining
        a proccessing error occured when the account is invalid.
        The system should also increment a counter that tracks the number of failed attempts.
        """
        cache = MagicMock()
        cache.get.return_value = 0
        get_cache.return_value = cache

        charge_by_token.return_value = ('failure', {'error_code': 'invalid_account'})
        self._assert_bank_error_message_and_make_payment_page(messages)
        self._assert_failed_counter_has_incremented(cache)

    @patch('views.get_cache')
    @patch('views.messages')
    @patch('views.payments.charge_by_token')
    def test_post_confirm_payment_insufficient_funds(self, charge_by_token, messages, get_cache):
        """
        The user should be redirected to the Make Payment page with text explaining
        a proccessing error occured when there are insufficient funds on the account.
        The system should also increment a counter that tracks the number of failed attempts.
        """
        cache = MagicMock()
        cache.get.return_value = 0
        get_cache.return_value = cache

        charge_by_token.return_value = ('failure', {'error_code': 'insufficient_funds'})
        self._assert_bank_error_message_and_make_payment_page(messages)
        self._assert_failed_counter_has_incremented(cache)

    @patch('views.get_cache')
    @patch('views.messages')
    @patch('views.payments.charge_by_token')
    def test_post_confirm_payment_card_expired(self, charge_by_token, messages, get_cache):
        """
        The user should be redirected to the Make Payment page with text explaining
        a proccessing error occured when the account is expired.
        The system should also increment a counter that tracks the number of failed attempts.
        """
        cache = MagicMock()
        cache.get.return_value = 0
        get_cache.return_value = cache

        charge_by_token.return_value = ('failure', {'error_code': 'card_expired'})
        self._assert_bank_error_message_and_make_payment_page(messages)
        self._assert_failed_counter_has_incremented(cache)

    @patch('views.get_cache')
    @patch('views.messages')
    @patch('views.payments.charge_by_token')
    def test_post_confirm_payment_account_closed(self, charge_by_token, messages, get_cache):
        """
        The user should be redirected to the Make Payment page with text explaining
        a proccessing error occured when the account is closed.
        The system should also increment a counter that tracks the number of failed attempts.
        """
        cache = MagicMock()
        cache.get.return_value = 0
        get_cache.return_value = cache

        charge_by_token.return_value = ('failure', {'error_code': 'account_closed'})
        self._assert_bank_error_message_and_make_payment_page(messages)
        self._assert_failed_counter_has_incremented(cache)

    @patch('views.get_cache')
    @patch('views.messages')
    @patch('views.payments.charge_by_token')
    def test_post_confirm_payment_bad_check(self, charge_by_token, messages, get_cache):
        """
        The user should be redirected to the Make Payment page with text explaining
        a proccessing error occured when the bank check is bad.
        The system should also increment a counter that tracks the number of failed attempts.
        """
        cache = MagicMock()
        cache.get.return_value = 0
        get_cache.return_value = cache

        charge_by_token.return_value = ('failure', {'error_code': 'bad_check'})
        self._assert_bank_error_message_and_make_payment_page(messages)
        self._assert_failed_counter_has_incremented(cache)

    def _assert_bank_error_message_and_make_payment_page(self, mock_messages):
        """
        Asserts that the invalid data text is shown to the user.
        """
        response = self.view.post(self.request)
        error_message = mock_messages.add_message.call_args[0][2]
        self.assertEquals(error_message,
                '<h3>Unable to process payment</h3><p>If you believe this is an error, please contact your bank, '
                'otherwise, please select another method of payment.</p>')
        self.assertEquals(resolve(urlparse(response['location'])[2]).url_name, "account_payment")

    def _assert_failed_counter_has_incremented(self, cache):
        """
        Asserts that the payment failed encounter has been incremented by one.
        """
        cache.get.return_value = 0

        # should increment the payment failed cache value for the account by 1
        self.assertTrue(cache.set.called)
        cache.set.assert_called_with(u'payment_failed_{0}_{1}'.format(self.request.org['slug'], self.view.kwargs['account_id']), 1, 86400)
