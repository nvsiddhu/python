from django.utils import simplejson as json
from datetime import datetime, timedelta

test_facility = dict()
test_facility['payment_receiver_id'] = '444'
test_facility['name'] = 'baseline'
test_facility['address_line_1'] = '123 Fake Street'
test_facility['address_line_2'] = 'Suite 103'
test_facility['address_line_3'] = ''
test_facility['address_line_4'] = ''
test_facility['city'] = 'Kansas City'
test_facility['state'] = 'MO'
test_facility['postal_code'] = '64117'
test_facility['country'] = 'USA'
test_facility['phone'] = '888-123-4567'
test_facility['merchant_id'] = '123456789'

test_account_1 = dict()
test_account_1['id'] = '1234'
test_account_1['account_number'] = '1234'
test_account_1['masked_account_number'] = '***4'
test_account_1['patient_name'] = 'fred smith'
test_account_1['facility'] = 'baseline'
test_account_1['facility_id'] = '123'
test_account_1['last_payment_amount'] = 0.49
test_account_1['last_payment_date'] = datetime(2012, 2, 21)
test_account_1['amount_due'] = 1000
test_account_1['bad_debt_amount'] = 100

test_account_2 = dict()
test_account_2['id'] = '1235'
test_account_2['account_number'] = '1235'
test_account_2['masked_account_number'] = '***5'
test_account_2['patient_name'] = 'jane smith'
test_account_2['facility'] = 'baseline'
test_account_2['facility_id'] = '123'
test_account_2['last_payment_amount'] = 1.49
test_account_2['last_payment_date'] = datetime(2012, 2, 20)
test_account_2['amount_due'] = 2000
test_account_2['bad_debt_amount'] = 200

test_account_3 = dict()
test_account_3['id'] = '1236'
test_account_3['account_number'] = '1236'
test_account_3['masked_account_number'] = '***6'
test_account_3['patient_name'] = 'kane smith'
test_account_3['facility'] = 'baseline'
test_account_3['facility_id'] = '123'
test_account_3['last_payment_amount'] = 2.49
test_account_3['last_payment_date'] = datetime(2012, 2, 22)
test_account_3['amount_due'] = 3000
test_account_3['bad_debt_amount'] = 300

temp1 = '"patientAccountId": "{0}","accountNumber": "{1}","maskAccountNumber": "{2}","patientName": "{3}","facility": "{4}","facilityId": "{5}","lastPaymentAmount": {6},"lastPaymentDate": "{7}","patientResponsibilityAmount": {8},"patientBadDebtBalance":{9}'.format(
            test_account_1['id'], test_account_1['account_number'], test_account_1['masked_account_number'],
            test_account_1['patient_name'], test_account_1['facility'], test_account_1['facility_id'],
            test_account_1['last_payment_amount'] * -1, test_account_1['last_payment_date'].strftime('%m/%d/%Y'), test_account_1['amount_due'],test_account_1['bad_debt_amount'])
temp2 = '"patientAccountId": "{0}","accountNumber": "{1}","maskAccountNumber": "{2}","patientName": "{3}","facility": "{4}","facilityId": "{5}","lastPaymentAmount": {6},"lastPaymentDate": "{7}","patientResponsibilityAmount": {8},"patientBadDebtBalance":{9}'.format(
            test_account_2['id'], test_account_2['account_number'], test_account_2['masked_account_number'],
            test_account_2['patient_name'], test_account_2['facility'], test_account_2['facility_id'],
            test_account_2['last_payment_amount'] * -1, test_account_2['last_payment_date'].strftime('%m/%d/%Y'), test_account_2['amount_due'],test_account_2['bad_debt_amount'])
temp3 = '"patientAccountId": "{0}","accountNumber": "{1}","maskAccountNumber": "{2}","patientName": "{3}","facility": "{4}","facilityId": "{5}","lastPaymentAmount": {6},"lastPaymentDate": "{7}","patientResponsibilityAmount": {8},"patientBadDebtBalance":{9}'.format(
            test_account_3['id'], test_account_3['account_number'], test_account_3['masked_account_number'],
            test_account_3['patient_name'], test_account_3['facility'], test_account_3['facility_id'],
            test_account_3['last_payment_amount'] * -1, test_account_3['last_payment_date'].strftime('%m/%d/%Y'), test_account_3['amount_due'],test_account_3['bad_debt_amount'])

account1 = '{' + temp1 + '}'
account2 = '{' + temp2 + '}'
account3 = '{' + temp3 + '}'


def fake_get_careaware_service_url(org_slug, service_key):
    return ('baseserviceurl.com')


def fake_get_oauth_client(self, org_slug, config):
    return (oauth_client())


def fake_get_facility(self, facility_id, oauth_client, base_service_url, org_slug):
    return test_facility


def fake_submit_credit_payment(self, payment_receiver_id, amount, payer_name,
                               card_number, security_code,
                               expiration_year, expiration_month, street_address,
                               city, state, postal_code, payment_id, org_slug):
    if payment_id == '123456789' and payer_name == 'John Smith':
        return 123456789, True
    elif payment_id == '234567890' and payer_name == 'Ken Smith':
        return 234567890, True
    elif payment_id == '555555555' and payer_name == 'Brad Smith':
        return 555555555, True
    elif payment_id == '666666666' and payer_name == 'Jim Smith':
        return None, True
    return None, False


def fake_get_payment(self, org_slug, guarantor_id, account_id, payment_id):
    payment = dict()
    payment['receipt_number'] = '10221'
    payment['amount'] = 0.49
    payment['payment_date'] = datetime(2012, 2, 22, 0, 0)
    payment['account_number'] = '1234'
    payment['masked_account_number'] = '***4'
    payment['patient_name'] = 'John Smith'
    payment['payer_name'] = 'John Smith'
    payment['transaction_id'] = '111111'

    payment['payee_name'] = 'Baseline'
    payment['payee_address_line_1'] = '123 Fake Street'
    payment['payee_address_line_2'] = ''
    payment['payee_city'] = 'Kansas City'
    payment['payee_state'] = 'MO'
    payment['payee_postal_code'] = '64117'
    payment['payee_phone'] = '999-999-9999'

    if guarantor_id == 'g_1' and account_id == '1234' and payment_id == '111111':
        return payment
    if guarantor_id == 'g_1' and account_id == '1234' and payment_id == '111112':
        payment['receipt_number'] = '12331'
        payment['patient_name'] = 'Kim Smith'
        payment['transaction_id'] = '111112'
        return payment
    if guarantor_id == 'g_1' and account_id == '1235' and payment_id == '111113':
        payment['receipt_number'] = '10232'
        payment['account_number'] = '1235'
        payment['masked_account_number'] = '***5'
        payment['patient_name'] = 'Kim Smith'
        payment['transaction_id'] = '111113'
        return payment
    if guarantor_id == 'g_1' and account_id == '1236' and payment_id == '111114':
        payment['receipt_number'] = '10232'
        payment['account_number'] = '1236'
        payment['masked_account_number'] = '***6'
        payment['patient_name'] = 'Eric Smith'
        payment['transaction_id'] = '111114'
        return payment
    if guarantor_id == 'g_1' and account_id == '1234' and payment_id == '111115':
        payment['receipt_number'] = '10277'
        payment['payment_date'] = datetime(2012, 2, 23, 0, 0)
        payment['transaction_id'] = '111115'
        return payment
    if guarantor_id == 'g_2' and account_id == '1235' and payment_id == '111116':
        payment['receipt_number'] = '92833'
        payment['payment_date'] = datetime(2012, 2, 19, 0, 0)
        payment['account_number'] = '1235'
        payment['masked_account_number'] = '***5'
        payment['patient_name'] = 'Janet Smith'
        payment['payer_name'] = 'Ken Smith'
        payment['transaction_id'] = '111116'
        return payment
    return None


def fake_get_payment_response(self, guarantor_id, account_id, payment_id, payment_receiver_id, oauth_client,
                              base_service_url, org_slug):
    if payment_id == '123456789':
        return ('success', {'payment_id': payment_id})
    elif payment_id == '234567890':
        return ('timeout', {'payment_id': payment_id})
    elif payment_id == '666666666':
        return ('success', {'payment_id': payment_id})
    return ('failure', {'error_code': 'submission_failure'})


def fake_get_account(self, org_slug, guarantor_id, account_id):
    account = dict()
    account['id'] = '1234'
    account['account_number'] = '1234'
    account['masked_account_number'] = '***4'
    account['patient_name'] = 'John Smith'
    account['facility'] = 'baseline'
    account['facility_id'] = '444'
    account['last_payment_amount'] = 0.49
    account['last_payment_date'] = datetime(2012, 2, 22, 0, 0)
    account['amount_due'] = 1000
    return account


def fake_update_payment(self, payment_url, payment_content, oauth_client, org_slug, guarantor_id, account_id):
    """Just mock this so it doesn't call through to the real service"""
    pass


def fake_http_put(url, data=None, headers=None, timeout=6,
                  allowed_statuses=None, verify=False):
    resp = response()
    payment_content = json.loads(data)
    if 'referenceNumber' in payment_content:
        if payment_content['referenceNumber'] == 'ok':
            resp.text = 'success'
            return resp

    resp.status_code = 404
    resp.text = 'failure'
    return resp


def fake_get_payment_http_get(url, headers=None, timeout=6,
                              allowed_statuses=None, verify=False):
    resp = response()
    urlList = url.split('/')
    if len(urlList) >= 8:
        if urlList[5] == '1234' and urlList[7] == '0001':
            resp.status_code = 200
            resp.text = '{"receiptNumber":"123221","amount":-0.49,"paymentDate":"2/22/2012","accountNumber":"1234","maskAccountNumber":"***4","patientName":"John Smith","payerName":"John Smith","transactionId":"000001"}'
            return resp


def fake_payment_response_http_get(url, headers=None, timeout=6,
                                   allowed_statuses=None, verify=False):
    resp = response()
    urlList = url.split('/')
    if urlList[7] == '111111':
        resp.status_code = 200
        resp.text = '{"billpayResponse":{"billpayStatus":{"statusCode":"00","approvalCode":"111111","amount":0.49}}}'
        return resp
    if urlList[7] == '111112':
        resp.status_code = 200
        resp.text = '{"billpayResponse":{"billpayStatus":{"statusCode":"01"}}}'
        return resp
    if urlList[7] == '111113':
        resp.status_code = 200
        resp.text = '{"ack":{"errors":{"error":[{"errorCode":"S6"}]}}}'
        return resp
    if urlList[7] == '111114':
        resp.status_code = 200
        resp.text = '{"ack":{"errors":{"error":[{"errorCode":"S4"}]}}}'
        return resp
    if urlList[7] == '111115':
        resp.status_code = 204
        resp.text = 'content'
        return resp
    resp.status_code = 404
    return resp


def fake_get_guarantor_http_get(url, headers=None, timeout=6,
                                allowed_statuses=None, verify=False):
    resp = response()
    if 'guarantorAccessCode' in headers and 'guarantorLastName' in headers and 'guarantorDOB' in headers:
        if headers['guarantorAccessCode'] == '12345' and headers['guarantorLastName'] == 'smith' and headers['guarantorDOB'] == '19700101':
            resp.status_code = 200
            resp.text = '[{"guarantorID": "g_1"}]'
            return resp
        if headers['guarantorAccessCode'] == '54321' and headers['guarantorLastName'] == 'smith' and headers['guarantorDOB'] == '19700101':
            resp.status_code = 200
            resp.text = '[{"guarantorID": "g_2"}]'
            return resp
        if headers['guarantorAccessCode'] == '67890' and headers['guarantorLastName'] == 'smith' and headers['guarantorDOB'] == '18900101':
            resp.status_code = 200
            resp.text = '[{"guarantorID": "g_3"}]'
            return resp
        if headers['guarantorAccessCode'] == '99999' and headers['guarantorLastName'] == 'smith' and headers['guarantorDOB'] == '19700101':
            resp.status_code = 200
            resp.text = '[{}]'
            return resp
    resp.status_code = 404
    return resp


def fake_get_payment_types_http_get(url, headers=None, timeout=6,
                                    allowed_statuses=None, verify=False):
    resp = response()
    merchant_id = '123456789'
    urlList = url.split('/')

    if urlList[6] == '444':
        resp.status_code = 200
        resp.text = '{"serviceAttributeResponse":{"service":{"serviceAttributes":[{"serviceAttribute":[{"name":"VISA","value":"TRUE"},{"name":"MASTERCARD","value":"TRUE"},{"name":"DISCOVER","value":"TRUE"},{"name":"AMEX","value":"TRUE"},{"name":"MERCHANT_ID","value":"123456789"}]}]}}}'
        return resp
    if urlList[6] == '445':
        resp.status_code = 200
        resp.text = '{"serviceAttributeResponse":{"service":{"serviceAttributes":[{"serviceAttribute":[{"name":"VISA","value":"FALSE"},{"name":"MASTERCARD","value":"FALSE"},{"name":"DISCOVER","value":"FALSE"},{"name":"AMEX","value":"FALSE"},{"name":"MERCHANT_ID","value":"123456789"}]}]}}}'
        return resp
    if urlList[6] == '555':
        resp.status_code = 200
        resp.text = '{"serviceAttributeResponse":{"error":{"code":"S3", "description":"there was an error"}}}'
        return resp
    if urlList[6] == '666':
        raise Exception('get request error')
    resp.status_code = 404
    return resp

def fake_get_payment_types_manifest_device_id(url, data, headers=None, verify=False, timeout=20):
    resp = response()
    payment_receiver_id = json.loads(data).get('merchantRequest').get('submitterId')

    if payment_receiver_id == '111':
        resp.status_code = 200
        resp.text = '{"ack": {"merchant": {"serviceAttributes": [{"name": "AMEX", "value": "true"}, {"name": "DISCOVER", "value": "true"}, {"name": "MASTERCARD", "value": "true"}, {"name": "VISA", "value": "true"}], "devices": [{"deviceId": "8888", "encryptionType": "TSEP"}], "manifest": "a1a1a1a1"}}}'
        return resp

    if payment_receiver_id == '222':
        resp.status_code = 200
        resp.text = '{"ack": {"merchant": {"serviceAttributes": [{"name": "AMEX", "value": "false"}, {"name": "DISCOVER", "value": "false"}, {"name": "MASTERCARD", "value": "false"}, {"name": "VISA", "value": "false"}], "devices": [{"deviceId": "8888", "encryptionType": "TSEP"}], "manifest": "a1a1a1a1"}}}'
        return resp

    if payment_receiver_id == '333':
        resp.status_code = 200
        resp.text = '{"ack": {"errors": {"error": [{"errorCode": "401", "errorMsg": "401 - 401 - Invalid submitter or password"}]}}}'
        return resp

    if payment_receiver_id == '444':
        raise Exception('get request error')

    resp.status_code = 404
    return resp

def fake_accounts_http_get(url, headers=None, timeout=6,
                           allowed_statuses=None, verify=False):
    resp = response()
    if 'guarantor' in headers:
        if headers['guarantor'] == 'g_1':
            resp.status_code = 200
            resp.text = '[{0},{1},{2}]'.format(account1, account2, account3)
            return resp
        if headers['guarantor'] == 'g_2':
            resp.status_code = 200
            resp.text = '[{0}]'.format(account2)
            return resp
        if headers['guarantor'] == 'g_3':
            resp.status_code = 200
            resp.text = '[]'
            return resp
    resp.status_code = 404
    return resp


def fake_account_http_get(url, headers=None, timeout=6,
                          allowed_statuses=None, verify=False):
    resp = response()
    if 'account' in headers and 'guarantor' in headers:
        if headers['account'] == '1234' and headers['guarantor'] == 'g_1':
            resp.status_code = 200
            resp.text = '{0}'.format(account1)
            return resp
        if headers['account'] == '1235' and headers['guarantor'] == 'g_2':
            resp.status_code = 200
            resp.text = '{0}'.format(account2)
            return resp
        if headers['account'] == '1234' and headers['guarantor'] == 'g_3':
            resp.status_code = 404
            return resp
    resp.status_code = 500
    return resp


def fake_get_facility_http_get(url, headers=None, timeout=6,
                               allowed_statuses=None, verify=False):
    resp = response()
    urlList = url.split('/')
    if urlList >= 3:
        if urlList[2] == '1111':
            resp.status_code = 200
            temp = '"submitterId":"{0}","name":"{1}","streetAddress1":"{2}","streetAddress2":"{3}","streetAddress3":"{4}","streetAddress4":"{5}","city":"{6}","state":"{7}","zipCode":"{8}","country":"{9}","phone":"{10}"'.format(
                        test_facility['payment_receiver_id'], test_facility['name'],
                        test_facility['address_line_1'], test_facility['address_line_2'],
                        test_facility['address_line_3'], test_facility['address_line_4'],
                        test_facility['city'], test_facility['state'], test_facility['postal_code'],
                        test_facility['country'], test_facility['phone'])
            resp.text = '{' + temp + '}'
            return resp

    resp.status_code = 404
    resp.text = '{}'
    return resp


def fake_submit_credit_payment_http_post(url, data=None, headers=None,
                                         timeout=6, allowed_statuses=None, verify=False):
    resp = response()
    content = json.loads(data)
    payment_receiver_id = content.get('billpayRequest', {}).get('device', []).get('submitterId')
    if payment_receiver_id == '444':
        resp.status_code = 200
        resp.text = '{"ack":{"interchangeId":"000001"}}'
        return resp
    if payment_receiver_id == '445':
        resp.status_code = 200
        resp.text = '{"errors":"some_error"}'
        return resp
    if payment_receiver_id == '446':
        return None
    resp.status_code = 404
    return resp


def fake_http_post(url, data=None, headers=None, timeout=6,
                   allowed_statuses=None, verify=False):
    if headers is None:
            headers = dict()
            headers['url'] = url
    else:
        if 'url' not in headers:
            headers['url'] = url

    content = json.loads(data)

    resp = response()
    if 'payerName' in content:
        if content['payerName'] == 'John Smith':
            resp.status_code = 201
            resp.text = '{"paymentId":123456789}'
            return resp
        if content['payerName'] == 'Ken Smith':
            resp.status_code = 201
            resp.text = '{"paymentId":234567890}'
            return resp
        if content['payerName'] == 'Brad Smith':
            resp.status_code = 201
            resp.text = '{"paymentId":555555555}'
            return resp
        if content['payerName'] == 'Ron Smith':
            resp.status_code = 201
            resp.text = '{"paymentId":555555555}'
            return resp
        if content['payerName'] == 'Jim Smith':
            resp.status_code = 201
            resp.text = '{"paymentId":666666666}'
            return resp
    resp.status_code = 404
    return resp


class response():
    status_code = 200
    text = ''
    headers = {'content-length': 4}
    content = ''
    elapsed = timedelta(0)


class oauth_client():

    def build_http_oauth_request_header(self, url, action, params=None):
        headers = dict()
        headers['url'] = url
        urlList = url.split('/')
        if len(urlList) >= 4:
            headers['guarantor'] = urlList[3]
        if len(urlList) >= 6:
            headers['account'] = urlList[5]
        headers['action'] = action
        if params is not None:
            headers.update(params)
        return headers
