# -*- coding: utf-8 -*-

import unittest

from django.contrib.sessions.middleware import SessionMiddleware
from django.core.urlresolvers import reverse
from django.test import RequestFactory
from middleware import ValidateUserSessionMiddleware


class ValidateUserSessionMiddlewareTests(unittest.TestCase):

    def test_setting_session_id(self):
        """
        Middlware should set _session_id in session if it hasn't been set yet already.
        """
        request = RequestFactory().get('/')
        session_middleware = SessionMiddleware()
        validate_session_middlware = ValidateUserSessionMiddleware()

        session_middleware.process_request(request)

        validate_session_middlware.process_request(request)

        self.assertEquals(request.session['_session_key'], request.session.session_key)

    def test_valid_session_id(self):
        """
        Middlware should validate _session_id in session if _session_id
        has already been set. If _session_id matches the session id on the user's
        cookie, then don't do anything.
        """
        request = RequestFactory().get('/')
        session_middleware = SessionMiddleware()
        validate_session_middlware = ValidateUserSessionMiddleware()

        session_middleware.process_request(request)
        request.session['_session_key'] = request.session.session_key
        request.session.save()
        prev_session_key = request.session.session_key

        response = validate_session_middlware.process_request(request)

        # session should not be deleted
        self.assertTrue(request.session.exists(prev_session_key))

        # session key and cache key should be the same
        self.assertEquals(request.session.session_key, prev_session_key)
        self.assertEquals(request.session.cache_key, request.session._get_cache_key(prev_session_key))

        # None should be returned which means to continue to the next middleware.
        self.assertEquals(response, None)

    def test_invalid_session_id(self):
        """
        Middlware should validate _session_id in session if _session_id
        has already been set. If _session_id does not matches the session id on the user's
        cookie, then flush the session and redirect the user to the home page.
        """
        request = RequestFactory().get('/')
        session_middleware = SessionMiddleware()
        validate_session_middlware = ValidateUserSessionMiddleware()

        session_middleware.process_request(request)
        request.session['_session_key'] = 'anothersessionid'
        request.session.save()
        prev_session_key = request.session.session_key

        response = validate_session_middlware.process_request(request)

        # session should be deleted
        self.assertFalse(request.session.exists(prev_session_key))

        # new session should have a different session key and cache key
        self.assertNotEquals(request.session.session_key, prev_session_key)
        self.assertNotEquals(request.session.cache_key, request.session._get_cache_key(prev_session_key))

        # User should be redirected back to home page
        self.assertEquals(response['location'], reverse('home'))
