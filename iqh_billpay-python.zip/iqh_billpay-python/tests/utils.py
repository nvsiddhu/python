# -*- coding: utf-8 -*-

from iqh_billpay.decorators import GUARANTOR_SESSION_KEY
from django.conf import settings
from django.test.client import RequestFactory
from django.utils.importlib import import_module
from iqh_billpay.views import PAYMENT_DATA_SESSION_KEY, TOKEN_REFERENCE_ID_SESSION_KEY
from iqh_domains.replicators import domain
from iqh_organizations.replicators import build_organization

from mock import MagicMock


class BillpayRequestFactory(RequestFactory):
    """
    A Request Factory that builds a dedicated request for billpay.

    NOTE: If using this request factory, ensure your tests extend django's
    TestCase class because the factory adds data in the test db.
    """

    def __init__(self, org_slug=None, guarantor_id=None, account_id=None):
        RequestFactory.__init__(self)

        self.org = build_organization(slug=org_slug)  # use OrganizationFactory when we upgrade to the newest version
        self.domain = domain(domain_name=self.org['slug'])
        self.guarantor_id = guarantor_id
        self.account_id = account_id

    def get(self, *args, **kwargs):
        request = super(BillpayRequestFactory, self).get(*args, **kwargs)
        self._assign_attributes(request)
        return request

    def post(self, *args, **kwargs):
        request = super(BillpayRequestFactory, self).post(*args, **kwargs)
        self._assign_attributes(request)
        return request

    @classmethod
    def set_payment_data_in_session(cls, request, payment_data=None):
        """
        Sets payment data (also known as form data) in the request's session.
        """
        if not payment_data:
            payment_data = {
                'payment_amount': 999, 'masked_card_number': '************1111', 'card_type': 'Visa',
                'expiration_date': '2099-1-1', 'payer_name': 'Jane Smith', 'address': '200 1st St.',
                'city': 'Chicago', 'state': 'IL', 'postal_code': '99999'}

        request.session[PAYMENT_DATA_SESSION_KEY] = payment_data

    @classmethod
    def set_token_reference_id_session(cls, request, token_reference_id=None):
        """
        Sets payment data (also known as form data) in the request's session.
        """
        if not token_reference_id:
            token_reference_id = '999'

        request.session[TOKEN_REFERENCE_ID_SESSION_KEY] = token_reference_id

    def _assign_attributes(self, request):
        request.org = self.org
        request.domain = self.domain
        request.domain_name = self.domain['domain_name']
        request.CAREAWARE_CONF = MagicMock()
        request.session = self._create_session()

        if self.guarantor_id:
            request.guarantor_id = self.guarantor_id

            if self.account_id:
                request.acct = self._create_account()

    def _create_session(self):
        engine = import_module(settings.SESSION_ENGINE)
        session = engine.SessionStore()
        if self.guarantor_id:
            session[GUARANTOR_SESSION_KEY] = self.guarantor_id
        return session

    def _create_account(self):

        return {
            'payment_receiver_id': '888',
            'name': 'John Smith',
            'address_line_1': '123 Main St.',
            'city': 'Kansas City',
            'state': 'Missouri',
            'postal_code': '64117',
            'country': 'USA',
            'phone': '888-123-4567',
            'amount_due': 200
        }
