# -*- coding: utf-8 -*-

from sensitive_settings import *
import os

DEBUG = False
DEPLOYMENT_MODE = "prod"

#STATIC_URL = 'https://crnst.com/s/billpay/'
STATIC_URL = 'https://dpfzcqrxx682t.cloudfront.net/s/billpay/'
STATIC_ROOT =  os.environ.get('STATIC_ROOT', '/opt/djangoprojects/billpay-static/')


# Mongo is used to write logs. This is the "prod" mongo instance.
MONGODB_CONNECTION_URI = 'mongodb://cerncwpapp212,cerncwpapp213,cerncwpapp210'

# Session cookie for 15 minutes.
SESSION_COOKIE_AGE = 60 * 15
SESSION_COOKIE_SECURE = True

DATABASE_CONNECTION_POOL_SIZE = 5
DATABASE_CONNECTION_MAX_OVERFLOW = 10
DATABASE_CONNECTION_TIMEOUT = 30

# TODO Use sandbox instance of cerner care oauth provider with sandbox consumer key and secret
# when the IQH Prod Tool in sandbox/staging is updated to point to the sandbox CMS
# and all the CMS templates are merged into sandbox CMS
# For now, we are pointing to PROD CMS because IQH Prod Tool points to Prod
CC_OAUTH_ACCESS_TOKEN_URL = 'https://api.cernercare.com/oauth/access'
CC_OAUTH_CONSUMER_KEY_IQH = 'cOEg0C2TV0Ubc0PKlELi5-qhXB1fsT_d'

EMAIL_HOST = 'mail.cernerasp.com'

EDI_SUBMITTER_LOOKUP_API_URL = 'https://rapidservices.cernerasp.com/edi/'
EDI_BILLPAY_API_URL = 'https://revenuecyclepci.cernerworks.com/edi/epayment/'

EDI_TOKEN_REQUEST_API_URL = 'https://revenuecyclepci.cernerworks.com/edi/epayment/cors/token'
TOKENIZATION_SERVICE_TIMEOUT = 40000

TSEP_TRANSIT_DOMAIN = 'https://gateway.transit-pass.com'

STATSD_HOST = 'cerncwpapp50'
STATSD_PORT = 8125

#connection timeout for caches in milliseconds
CACHE_CONNECTION_TIMEOUT = 70

CACHE_HOSTS = ['cerniqhmem201', 'cerniqhmem203']

DEFAULT_CACHE = {
    'default': {
        'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
        #This must be a host in the PCI network
        'LOCATION': 'cerniqhqpapp201:11700',
        'VERSION': '1',
        'OPTIONS':{
            'connect_timeout': CACHE_CONNECTION_TIMEOUT,
            'hash': 'murmur',
            'distribution': 'consistent',
        }
    }
}

DEFAULT_FILE_STORAGE = 'storages.backends.s3boto.S3BotoStorage'
AWS_STORAGE_BUCKET_NAME = 'cerner-healthelife-iqh-public'
AWS_S3_CUSTOM_DOMAIN = 'd292eo2ec5lzlq.cloudfront.net'
AWS_S3_FILE_OVERWRITE = False
AWS_QUERYSTRING_AUTH = False

AWS_HEADERS = {
    'x-amz-server-side-encryption': 'AES256',
}

THEMING_ACCESS_TOKEN = '3dc0d32d-28c0-49a6-aabe-e685dd057b38'
VIRTUAL_ENV_BIN = '/opt/.virtualenvs/iqh_billpay/bin'
