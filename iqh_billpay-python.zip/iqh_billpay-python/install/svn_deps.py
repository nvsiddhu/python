"""
Used by patient_portal_dependencies.py to checkout and install our svn dependencies
"""

svn_deps = (
    'iqh_template_loaders',
)
