# -*- coding: utf-8 -*-

"""
This file is used by the fabfile to be executed on the remote box.
This takes care of checking out the svn code and versioned dependencies
for the remote box.  The work to install the code base is done in the main 
function which takes advantage of the patient_portal_dependencies installer
which only installs versioned dependencies when they change so that installation
will be faster.
"""

import os

from patient_portal_dependencies.patient_portal_dependencies import FabInstaller
 
def get_installer():
    iqhbp_install= FabInstaller(svn_deps_path=os.path.join(os.path.dirname(os.path.abspath(__file__)),"install"),
                              requirements_file="/opt/djangoprojects/iqh_billpay/install/deploy_requirements.txt")
    return iqhbp_install
 
def main():
    """
    Method used to update versioned dependencies in iqh_billpay.
    """
    iqhbp_install = get_installer()
    iqhbp_install()
 
    print 'IQH Bill Pay versioned dependencies install/update completed!'
 
if __name__ == '__main__':
    main()
