# -*- coding: utf-8 -*-

from django.conf import settings
from django.core.urlresolvers import reverse
from django.http import Http404
from django.shortcuts import redirect
from iqh_organizations import organizations
from iqh_payments import payments
import iqh_logging

logger = iqh_logging.get_logger(__name__)
GUARANTOR_SESSION_KEY = '_bp_guarantor_id'

def requires_org(func):
    """
    Use this decorator to set the org on the request.
    All views that require an org should use this decorator.
    """
    def decorated(request, *args, **kwargs):
        org_slug = request.domain.get('default_org', None)

        if not org_slug:
            logger.debug("No org found. The domain must have a default org in order to access this page.")
            raise Http404

        request.org = organizations.get_by_slug_or_404(org_slug)
        return func(request, *args, **kwargs)
    return decorated

def requires_guarantor(func):
    """
    Use this decorator to make sure there's a guarantor in session.
    All views that require a guarantor should use this decorator.
    """
    def decorated1(func):
        @requires_org
        def decorated2(request, *args, **kwargs):
            guarantor_id = request.session.get(GUARANTOR_SESSION_KEY, None)
            if not guarantor_id:
                # Perhaps user bookmarked the account payment page, go back to the start of the flow
                return redirect(reverse('home'))

            request.guarantor_id = guarantor_id
            return func(request, *args, **kwargs)
        return decorated2
    return decorated1(func)

def requires_acct(func):
    """
    Use this decorator to make sure that the account exists and put in request.
    All views that require a guarantor and acct should use this decorator.
    If no account is found it will raise a 404.
    """
    def decorated1(func):
        @requires_guarantor
        def decorated2(request, *args, **kwargs):
            guarantor_id = request.guarantor_id
            org_slug = request.org.get('slug')
            account_id = kwargs.get('account_id', None)
            acct = payments.get_account(org_slug, guarantor_id, account_id)
            if not acct:
                logger.debug("acct could not be found based on org_slug, account_id and guarantor_id.")
                raise Http404
            request.acct = acct
            return func(request, *args, **kwargs)
        return decorated2
    return decorated1(func)
