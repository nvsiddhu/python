# -*- coding: utf-8 -*-

import ast
import re

from operator import itemgetter

from axiom_core.simpleids import random_id
from axiom_dates.parsers import parse_date
from axiom_dates.timezones import utc_naive_to_tz
from axiom_django.multiresponse import html, no_cache_response
from decorators import requires_org, requires_guarantor, requires_acct, GUARANTOR_SESSION_KEY
from django.conf import settings
from django.contrib import messages
from django.core.cache import get_cache
from django.core.urlresolvers import reverse
from django.http import HttpResponseServerError, HttpResponseNotFound, HttpResponse
from django.shortcuts import redirect, render_to_response
from django.template import RequestContext
from django.utils.safestring import mark_safe
from django.utils.translation import ugettext as _
from django.views.generic.base import RedirectView, TemplateView
from django.views.generic.edit import FormView

from bill_pay_config.models import BillPayConfig
from billpay_template_config.models import BillpayTemplateConfig
from forms import AccessForm, AccessFormTerms, PaymentForm, RecaptchaForm, ReceiptForm, TSEPPaymentForm
from guarantor_auth.auth import guarantor_authenticate, guarantor_login, guarantor_logout
from iqh_email.utils import send_email_from_templates
from iqh_organizations.models import Organization
from iqh_payments import payment_utils
from iqh_payments import payments
from iqh_payments.codes import *
from mixins import NeedsAccountMixin, CaptchaMixin
from site_utils import render_to_string
from tokenizer.exceptions import (EDISystemException,
                                  MissingInfoException,
                                  GenericTokenException,
                                  TSEPSystemException)
from tokenizer.request_metrics import record_measured_request
from tokenizer.validate import is_get_token_response_valid
import iqh_logging

logger = iqh_logging.get_logger(__name__)

PAYMENT_DATA_SESSION_KEY = '_bp_payment_data'
TOKEN_REFERENCE_ID_SESSION_KEY = '_token_reference_id'

@no_cache_response
def server_error(request, template_name='500.html'):
    """
    Custom 500 error page view.
    """
    # Go ahead and log the exception even though exception middleware probably
    # will log it too. We do this for the edge case where something goes
    # wrong with that middleware not executing, to ensure every time the 500
    # page is rendered we get a log.
    org_slug = getattr(request, 'org', {}).get('slug')
    account_id = getattr(request, 'acct', {}).get('id')
    guarantor_id = getattr(request, 'guarantor_id', None)

    try:
        logger.exception('Uncaught exception, rendering 500 page. Org_Slug={0}, Guarantor_ID={1}, Account_ID={2}'.format(org_slug, guarantor_id, account_id))
    except:
        pass

    return HttpResponseServerError(render_to_string(request, template_name))


def not_found(request, template_name='404.html'):
    return HttpResponseNotFound(render_to_string(request, template_name))


class LogoutView(RedirectView):

    permanent = False

    def get_redirect_url(self, *args, **kwargs):
        guarantor_logout(self.request)

        if self.request.GET.get('timeout'):
            messages.add_message(self.request, messages.WARNING,
                _("You were signed out after a period of inactivity. Enter your information again to use Quick Pay."))

        return reverse('home')


@requires_org
@html('index.html')
def home(request):
    context = dict()

    try:
        template = BillpayTemplateConfig.objects.get(template_key='quickpay-terms', org=request.org.get('id'))
        context['quickpay_terms_template_content'] = mark_safe(template.template_html_content)
        request.session['quickpay_terms'] = True
    except BillpayTemplateConfig.DoesNotExist:
        request.session['quickpay_terms'] = False

    request.session[PAYMENT_DATA_SESSION_KEY] = None
    if request.method == 'POST':
        if request.session['quickpay_terms']:
            terms_form = AccessFormTerms(request.POST)
        form = AccessForm(request.POST)

        #if terms are shown we need to validate them
        valid_terms = not request.session['quickpay_terms'] or terms_form.is_valid()

        if form.is_valid() and valid_terms:
            last_name = form.cleaned_data['last_name']
            date_of_birth = form.cleaned_data['date_of_birth']
            access_code = form.cleaned_data['access_code']

            cache = get_cache('billpay.access.captcha.counter')
            access_code_key = _safe_key(u'access_failed_{0}_{1}'.format(request.org['slug'], access_code))
            name_dob_key = _safe_key(u'access_failed_{0}_{1}_{2}'.format(request.org['slug'], last_name.lower(), date_of_birth))
            failures_access_code = cache.get(access_code_key, 0)
            failures_name_dob = cache.get(name_dob_key, 0)
            access_failures = failures_access_code if failures_access_code > failures_name_dob else failures_name_dob
            is_recaptcha_displayed = 'g-recaptcha-response' in request.POST

            # if recaptcha is displayed but not checked by the user
            if is_recaptcha_displayed:
                is_recaptcha_checked = len(request.POST.get('g-recaptcha-response', '').strip()) > 0
                if not is_recaptcha_checked:
                    access_failures += 1
                    cache.set_many({access_code_key: failures_access_code + 1,
                                name_dob_key: failures_name_dob + 1}, 86400)
                    context['captcha_autofocus'] = True
                    context['form'] = form
                    context['recaptcha_form'] = RecaptchaForm(request.POST)
                    if request.session['quickpay_terms']:
                        context['terms_form'] = terms_form
                    return context

            guarantor_id = guarantor_authenticate(request.org['slug'], access_code, last_name, date_of_birth)
            if not guarantor_id:
                form.error_msg = _('<h3>We couldn&#039;t find an account that matches that information</h3><p>Make sure you enter the last name and date of birth of the person to whom the bill was sent. (Hint: This may be a different person than the patient.)</p>')
                access_failures += 1
                cache.set_many({access_code_key: failures_access_code + 1,
                                name_dob_key: failures_name_dob + 1}, 86400)

            else:
                cache.delete_many([access_code_key,
                                   name_dob_key])

                guarantor_login(request, guarantor_id)
                return redirect(reverse('view_accounts'))

            if access_failures >= 5:
                context['recaptcha_form'] = RecaptchaForm()
    else:
        request.session[GUARANTOR_SESSION_KEY] = None
        if request.session['quickpay_terms']:
            terms_form = AccessFormTerms()
        form = AccessForm()

    context['form'] = form
    if request.session['quickpay_terms']:
        context['terms_form'] = terms_form
    return context


@requires_guarantor
@html('view_accounts.html')
def view_accounts(request):
    request.session[PAYMENT_DATA_SESSION_KEY] = None
    context = dict()
    guarantor_id = request.guarantor_id
    accounts = payments.get_accounts(request.org['slug'], guarantor_id)
    timezone = _get_org_tz(request.org['slug'])
    accts_amount_due = []
    accts_no_amount_due = []
    status = request.GET.get('status', None)
    if status == 'cancel':
        messages.warning(request, _('<h3>Payment Canceled</h3><p>You canceled your payment. No payment was made and no credit card information was submitted.</p>'))
    for acct in accounts:
        if acct.get('last_payment_date'):
            acct['last_payment_date'] = utc_naive_to_tz(acct['last_payment_date'], timezone)

        if acct.get('amount_due', 0) > 0:
            accts_amount_due.append(acct)
        else:
            if not acct.get('amount_due', None):
                # Set the amount_due to 0 if not set
                acct['amount_due'] = 0
            accts_no_amount_due.append(acct)

        # If the bad_debt_amount is not set, it is set to 0
        if not acct.get('bad_debt_amount'):
            acct['bad_debt_amount'] = 0

    context['accts_amount_due'] = sorted(accts_amount_due, key=itemgetter('amount_due'), reverse=True)
    context['accts_no_amount_due'] = sorted(accts_no_amount_due, key=itemgetter('amount_due'))

    org = Organization.objects.get(slug=request.org['slug'])
    context['show_bad_debt_amount'] = BillPayConfig.is_bad_debt_enabled(org)

    return context


class AccountPaymentView(NeedsAccountMixin, CaptchaMixin, FormView):

    form_class = PaymentForm
    template_name = 'account_payment.html'

    def get_context_data(self, **kwargs):
        context = super(AccountPaymentView, self).get_context_data(**kwargs)

        token_reference_id = random_id(20)
        self.request.session[TOKEN_REFERENCE_ID_SESSION_KEY] = token_reference_id

        context['token_reference_id'] = token_reference_id
        context["acct"] = self.request.acct
        context['payment_receiver_id'] = self.request.acct['payment_receiver_id']
        context["account_id"] = self.kwargs.get('account_id')
        context['interchange_id_lookup_api_url'] = settings.EDI_TOKEN_REQUEST_API_URL
        context['tokenization_service_timeout'] = settings.TOKENIZATION_SERVICE_TIMEOUT
        context['tsep'] = BillPayConfig.is_tsep_enabled(self.org)
        return context

    def get_form_kwargs(self):
        kwargs = super(AccountPaymentView, self).get_form_kwargs()
        org_slug = self.request.org['slug']
        org_tz = _get_org_tz(org_slug)
        account_id = getattr(self.request, 'acct', {}).get('id')
        guarantor_id = getattr(self.request, 'guarantor_id', None)

        payment_types, merchant_id = self.get_supported_payment_types_and_merchant_id(
            org_slug,
            self.request.acct['payment_receiver_id'],
            guarantor_id,
            account_id
        )

        kwargs['org_tz'] = org_tz
        kwargs['payment_types'] = payment_types
        kwargs['request'] = self.request
        return kwargs

    def get_initial(self):
        initial = super(AccountPaymentView, self).get_initial()

        payment_data = _get_payment_data(self.request)
        if payment_data:
            initial = payment_data
            amount = payment_data.get('payment_amount', None)
        else:
            amount = self.request.acct.get('amount_due', None)

        if amount:
            initial['payment_amount'] = format(amount, '.2f')

        return initial

    def post(self, request, *args, **kwargs):
        post_data = request.POST

        # record timings of the tokenization service before the form validation occurs
        if post_data.get('response_time'):
            statsd_keys = payments._build_statsd_keys('hnam_rest_payments.edi_request_token', request.org['slug'])
            record_measured_request(statsd_keys, post_data.get('http_status_code'), post_data.get('response_time'), post_data.get('error_message'))

        return super(AccountPaymentView, self).post(request, *args, **kwargs)

    def form_valid(self, form):
        request = self.request
        post_data = request.POST
        account_id = getattr(request, 'acct', {}).get('id')
        guarantor_id = getattr(request, 'guarantor_id', None)

        try:
            assert(is_get_token_response_valid(request))
        except MissingInfoException:
                return self.form_invalid(form)
        except (EDISystemException, TSEPSystemException):
            messages.error(request, _('<h3>Unable to process payment</h3><p>We are unable to process your payment at this time. Please try again later.</p>'))
            return redirect(reverse('view_accounts'))
        except GenericTokenException:
            self.increment_access_failures()
            messages.error(request, _('<h3>Unable to process payment</h3><p>We were unable to process your payment. Please try again.</p>'))
            return self.form_invalid(form)

        if self.get_access_failures() >= 5 and not self.is_human():
            self.increment_access_failures()
            messages.error(request, _('<h3>Unable to process payment</h3><p>We were unable to process your payment. Please try again.</p>'))
            return self.form_invalid(form)

        self.delete_access_failures_cache()

        payment_types, merchant_id = self.get_supported_payment_types_and_merchant_id(
            request.org['slug'],
            request.acct['payment_receiver_id'],
            guarantor_id,
            account_id
        )

        form_data = form.cleaned_data
        form_data['expiration_date'] = str(form_data['expiration_date'])
        form_data['payment_amount'] = float(str(form_data['payment_amount']))
        form_data['interchange_id'] = str(post_data.get('interchange_id'))
        form_data['card_type'] = payment_utils.parse_card_type(post_data.get('card_type'))
        form_data['masked_card_number'] = post_data.get('masked_card_number')
        form_data['merchant_id'] = merchant_id

        self.request.session[PAYMENT_DATA_SESSION_KEY] = unicode(form_data)
        return redirect(reverse('confirm_payment', args=[self.kwargs.get('account_id')]))

    def form_invalid(self, form):
        # Overriding this to add error messages for the card_number and security_number
        # Since we don't have the name attribute anymore we don't send the data back to
        # the server hence we have to set required=False on the form, but those values are required to make
        # a CORS request, we need to show an error message whenever the form is invalid since we clear these
        # fields.
        form._errors["card_number"] = form.error_class([_(u'This field is required.')])
        form._errors["security_number"] = form.error_class([_(u'This field is required.')])
        return super(AccountPaymentView, self).form_invalid(form)

    def get_captcha_key(self):
        org_slug = self.request.org['slug']
        account_id = self.kwargs.get('account_id')
        return u'payment_failed_{0}_{1}'.format(org_slug, account_id)

    def get_supported_payment_types_and_merchant_id(self, org_slug, payment_receiver_id, guarantor_id, account_id):
        """Returns the supported payment types and the merchant id for the transaction"""
        if hasattr(self, 'merchant_id') and hasattr(self, 'payment_types'):
            return self.payment_types, self.merchant_id
        if BillPayConfig.is_tsep_enabled(self.org):
            self.merchant = payments.get_merchant(org_slug, payment_receiver_id, guarantor_id, account_id)
            self.payment_types = self.merchant['payment_types']
            self.merchant_id = self.merchant['merchant_id']
        else:
            self.payment_types, self.merchant_id = payments.get_supported_payment_types_and_merchant_id(
                org_slug,
                payment_receiver_id,
                guarantor_id,
                account_id
            )
        return self.payment_types, self.merchant_id


class TSEPAccountPaymentView(NeedsAccountMixin, FormView):

    form_class = TSEPPaymentForm
    template_name = 'tsep.html'

    def get_context_data(self, **kwargs):
        account_id = getattr(self.request, 'acct', {}).get('id')
        guarantor_id = getattr(self.request, 'guarantor_id', None)
        context = super(TSEPAccountPaymentView, self).get_context_data(**kwargs)
        context.update(payments.get_merchant(self.org.slug, self.request.acct['payment_receiver_id'], guarantor_id, account_id))
        return context


class ConfirmPaymentView(NeedsAccountMixin, TemplateView):

    template_name = 'confirm_payment.html'

    def get_context_data(self, **kwargs):
        context = super(ConfirmPaymentView, self).get_context_data(**kwargs)
        context["acct"] = self.request.acct
        context["account_id"] = self.kwargs.get('account_id')
        context['payment_data'] = self.get_payment_data()

        try:
            template = BillpayTemplateConfig.objects.get(template_key='payment-terms', org=self.request.org.get('id'))
            context['payment_terms_template_content'] = mark_safe(template.template_html_content)
        except BillpayTemplateConfig.DoesNotExist:
            context['terms_template'] = 'payment_terms.html'
        return context

    def get(self, request, *args, **kwargs):
        payment_data = self.get_payment_data()
        token_reference_id = self.request.session.get(TOKEN_REFERENCE_ID_SESSION_KEY)

        # ensure payment data and token reference id is in session before rendering the confirm page
        if not payment_data or not token_reference_id:
            return redirect(reverse('account_payment', args=[self.kwargs.get('account_id')]))

        return super(ConfirmPaymentView, self).get(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        payment_data = self.get_payment_data()
        token_reference_id = request.session.get(TOKEN_REFERENCE_ID_SESSION_KEY)

        account_id = self.kwargs.get('account_id')

        payment_status = payments.charge_by_token(request.org['slug'],
            request.guarantor_id, account_id, request.acct['payment_receiver_id'],
            payment_data['payment_amount'], payment_data['payer_name'],
            payment_data['address'], payment_data['city'],
            payment_data['state'], payment_data['postal_code'],
            payment_data['interchange_id'], payment_data['formatted_masked_card_number'],
            payment_data['card_type'], payment_data['formatted_expiration_date'],
            payment_data['merchant_id'], token_reference_id)

        cache = get_cache('billpay.payment.captcha.counter')
        if payment_status[0] == 'success':
            # clear the failed payment captcha count from cache
            cache.delete(u'payment_failed_{0}_{1}'.format(request.org['slug'], account_id))

        elif payment_status[0] == 'timeout':
            # set pending status to cache for the payment before redirecting the the payment view.
            # This will ensure that we only clear the captcha cache for a user whom attempted to submit
            # a payment and not for a user simply navigating to the receipt page.
            cache.set(u'payment_pending_{0}_{1}_{2}'.format(request.org['slug'], account_id, payment_status[1]['payment_id']), True)

        return _handle_payment_result(request, request.org['slug'], account_id, payment_status)

    def get_payment_data(self):
        if hasattr(self, 'payment_data'):
            return self.payment_data

        self.payment_data = _get_payment_data(self.request)
        return self.payment_data


@requires_acct
@html('payment_receipt.html')
def payment(request, account_id, payment_id):
    context = dict()
    context["acct"] = request.acct
    context["account_id"] = account_id
    context["payment_id"] = payment_id

    card_type = None  # Change made for https://jira2.cerner.com/browse/PORTALDEV-49400
    payment_data = _get_payment_data(request)
    if payment_data:
        card_type = payment_data.get('card_type')

    #If the payment is indicated as incomplete, check the status
    if request.GET.get('i') == 't':
        payment_status = payments.check_payment_status(request.org['slug'], request.guarantor_id,
            account_id, payment_id, request.acct['payment_receiver_id'], card_type)

        if payment_status[0] == 'timeout':
            return render_to_response('payment_status.html', context,
                                      RequestContext(request))
        elif payment_status[0] != 'success':
            return _handle_payment_result(request, request.org['slug'], account_id, payment_status)

        #If the payment is now a success, make sure we have the latest account
        # info since it may have been updated by check_payment_status
        request.acct = payments.get_account(request.org['slug'], request.guarantor_id, account_id)
        context["acct"] = request.acct

        cache = get_cache('billpay.payment.captcha.counter')
        payment_pending_cache_key = u'payment_pending_{0}_{1}_{2}'.format(request.org['slug'], account_id, payment_status[1]['payment_id'])
        payment_pending = cache.get(payment_pending_cache_key)

        # clear the failed payment captcha count from cache when the user is redirected to this view
        # from the confirm page.
        if payment_pending:
            cache.delete_many([u'payment_failed_{0}_{1}'.format(request.org['slug'], account_id), payment_pending_cache_key])

    #Getting the payment summary information
    payment = payments.get_payment(request.org['slug'], request.guarantor_id, account_id, payment_id)
    payment['remaining_balance'] = request.acct['amount_due']
    payment['localized_payment_date'] = utc_naive_to_tz(payment['payment_date'], _get_org_tz(request.org['slug']))

    #Eventually we want to get this information with payments.get_payment
    #instead of using what's in session
    if payment_data:
        payment['payer_masked_card_number'] = payment_data['masked_card_number']
        payment['payer_card_type'] = payment_data['card_type']
    # Removed payment data and token reference id from session since we won't need it anymore
    # and we don't want them to be able to hit the back button and confirm
    # the payment again...
    request.session[PAYMENT_DATA_SESSION_KEY] = None
    request.session[TOKEN_REFERENCE_ID_SESSION_KEY] = None

    context['payment'] = payment
    context['form'] = ReceiptForm()

    return context


@requires_acct
@html('payment_receipt.html')
def email_receipt(request, account_id, payment_id):
    success = True
    payment = payments.get_payment(request.org['slug'], request.guarantor_id, account_id, payment_id)
    payment['remaining_balance'] = request.acct['amount_due']
    payment['localized_payment_date'] = utc_naive_to_tz(payment['payment_date'], _get_org_tz(request.org['slug']))
    form = ReceiptForm(request.POST)

    if not form.is_valid():
        context = dict()
        context["acct"] = request.acct
        context["account_id"] = account_id
        context["payment_id"] = payment_id

        context["payment"] = payment
        context["form"] = form
        return context

    to_email = form.cleaned_data['email']

    try:
        from_email = request.domain.get('notification_email')
    except:
        from_email = 'noreply@iqhealth.com'

    receipt_info = dict()
    receipt_info.update(request.acct)
    receipt_info.update(payment)
    receipt_info['org_name'] = request.org['name']
    #receipt_info['payer_masked_card_number'] = 'xxxx-xxxx-xxxx-{0}'.format(payment['payer_card_number'][12:])

    context = dict()
    context['receipt_info'] = receipt_info

    try:
        send_email_from_templates(to_email, from_email,
                              'receipt_email_subject.txt',
                              'receipt_email.txt',
                              'receipt_email.html',
                              fail_silently=False, context=context)
        info_msg = _(u"A copy of your receipt was sent to {0}").format(to_email)
    except:
        success = False
        info_msg = _("We are experiencing technical difficulties. Your receipt was not sent. Try again or print a copy for your records.")

    if request.is_ajax():
        return HttpResponse(status=204) if success else HttpResponse(status=500)

    if success:
        messages.add_message(request, messages.SUCCESS, u'<h3>{0}</h3>'.format(info_msg))
    else:
        messages.add_message(request, messages.ERROR, u'<h3>{0}</h3>'.format(info_msg))

    return redirect(reverse('payment', args=[account_id, payment_id]))


def health_check(request):
    """ This view is used for health check purposes and should be ignored by middleware. """
    return HttpResponse('OK', mimetype='text/plain')


def keep_alive(request):
    return HttpResponse('OK', mimetype='text/plain')


def _handle_payment_result(request, org_slug, account_id, payment_status):
    cache = get_cache('billpay.payment.captcha.counter')
    access_failures = cache.get(u'payment_failed_{0}_{1}'.format(org_slug, account_id), 0)

    if payment_status[0] in ('success', 'timeout'):
        url = reverse('payment', args=[account_id, payment_status[1]['payment_id']])
        # If the payment didn't complete, make sure the payment view knows to check the status
        return redirect(u'{0}?i=t'.format(url) if payment_status[0] == 'timeout' else url)

    if payment_status[1]['error_code'] in ['submission_failure', 'declined']:
        messages.add_message(request, messages.ERROR, _('<h3>Submission Failure</h3><p>We were unable to process your payment. Please try again.</p>'))
    else:
        messages.add_message(request, messages.ERROR, _('<h3>Unable to process payment</h3><p>If you believe this is an error, please contact your bank, otherwise, please select another method of payment.</p>'))

    if payment_status[1]['error_code'] != 'submission_failure':
        cache.set(u'payment_failed_{0}_{1}'.format(org_slug, account_id),
                      access_failures + 1, 86400)

    return redirect(reverse('account_payment', args=[account_id]))


def _get_payment_data(request):
    payment_data = request.session.get(PAYMENT_DATA_SESSION_KEY, None)
    if not payment_data:
        return None
    payment_data = ast.literal_eval(unicode(payment_data))
    payment_data['formatted_masked_card_number'] = 'xxxx-xxxx-xxxx-{0}'.format(payment_data['masked_card_number'][-4:])
    payment_data['expiration_date'] = parse_date(payment_data['expiration_date'])
    payment_data['formatted_expiration_date'] = payment_data['expiration_date'].strftime('%m/%Y')
    payment_data['remaining_balance'] = request.acct['amount_due'] - payment_data['payment_amount']
    return payment_data

def _get_org_tz(org_slug):
    try:
        org = Organization.objects.get(slug=org_slug)
        return org.time_zone
    except Organization.DoesNotExist:
        logger.warning("Org does not exist for org_slug {0}".format(org_slug))

    return 'America/Chicago'


def _safe_key(value):
    """ Memcached keys cannot contain certain control characters (ascii < 33)
    So strip them out to make user input strings safe for caching.
    """
    return re.sub(r'\s', '', value)
