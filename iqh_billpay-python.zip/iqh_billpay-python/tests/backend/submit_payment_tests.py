# -*- coding: utf-8 -*-

import datetime
import json
from django.test import TestCase

from axiom_django.backends import get_backend
from mock import patch, MagicMock
import requests

from iqh_payments.types import PaymentStatus

payments = get_backend('',
                       'iqh_payments.backends.hnam_rest_payments',
                       'PaymentBackend')


class TestSubmitPayment(TestCase):

    @patch('iqh_payments.backends.hnam_rest_payments.BillPayConfig')
    @patch('iqh_payments.backends.hnam_rest_payments.Organization')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.post')
    def submit_payment_successful_test(self, MockPost, org, config):
        """
        _submit_payment should return a PaymentStatus object when the POST
        to charge the payment by interchange_id was successful.
        """
        config.is_tsep_enabled.return_value = False
        self.mock_response = MagicMock()
        self.mock_response.headers = {'content-length': 4}
        self.mock_response.elapsed = datetime.timedelta(0)
        self.mock_response.text = json.dumps({
            'ack': {
                'interchangeId': '123',
                'approvalCode': '456',
                'amount': '20.0',
                'amountRequested': '20.0'
            }
        })
        MockPost.return_value = self.mock_response

        payment_status = self._make_payment()
        self.assertEquals(type(payment_status), PaymentStatus)
        self.assertEquals(json.loads(MockPost.call_args[1]['data'])['tokenPaymentRequest']['payment']['card'],
                          {u'billingAddress': {u'address1': u'123 Main St', u'state': u'MO', u'city': u'Kansas City',
                                               u'zipCode': u'64117', u'country': u'US'}})

    @patch('iqh_payments.backends.hnam_rest_payments.BillPayConfig')
    @patch('iqh_payments.backends.hnam_rest_payments.Organization')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.post')
    def submit_tsep_payment_successful_test(self, MockPost, org, config):
        """
        _submit_payment should return a PaymentStatus object when the POST
        to charge the payment by interchange_id was successful. The payment
        submission should contain the expiration date of the card.
        """
        self.mock_response = MagicMock()
        self.mock_response.headers = {'content-length': 4}
        self.mock_response.elapsed = datetime.timedelta(0)
        self.mock_response.text = json.dumps({
            'ack': {
                'interchangeId': '123',
                'approvalCode': '456',
                'amount': '20.0',
                'amountRequested': '20.0'
            }
        })
        MockPost.return_value = self.mock_response

        payment_status = self._make_payment()
        self.assertEquals(type(payment_status), PaymentStatus)
        self.assertEquals(json.loads(MockPost.call_args[1]['data'])['tokenPaymentRequest']['payment']['card'],
                          {u'billingAddress': {u'address1': u'123 Main St', u'state': u'MO', u'city': u'Kansas City',
                                               u'zipCode': u'64117', u'country': u'US'}, u'expirationDate': u'122025'})
        self.assertEquals(org.objects.get.call_args[1], {'slug': 'baseline'})

    @patch('iqh_payments.backends.hnam_rest_payments.BillPayConfig')
    @patch('iqh_payments.backends.hnam_rest_payments.Organization')
    @patch('iqh_payments.backends.hnam_rest_payments.logger')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.post')
    def submit_payment_edi_failure_test(self, MockPost, mock_logger, org, config):
        """
        _submit_payment should log an error and return a PaymentStatus object
        when the charging the payment by interchange_id returned an EDI error code.
        """

        self.mock_response = MagicMock()
        self.mock_response.headers = {'content-length': 4}
        self.mock_response.elapsed = datetime.timedelta(0)
        self.mock_response.text = json.dumps({
            'ack': {
                'interchangeId': '12345',
                'errors': {
                    'error': [{
                        'errorCode': 'S3',
                        'errorMsg': 'Missing Required Information'
                    }]
                }
            }
        })
        MockPost.return_value = self.mock_response

        payment_status = self._make_payment()
        self.assertEquals(type(payment_status), PaymentStatus)
        self.assertTrue(mock_logger.error.called)

    @patch('iqh_payments.backends.hnam_rest_payments.requests.post')
    def submit_payment_non_200_test(self, MockPost):
        """
        _submit_payment should return an exception when the POST to charge
        the payment by interchange_id unexpectedly returns a malformed response
        with no JSON.
        """

        self.mock_response = MagicMock()
        self.mock_response.headers = {'content-length': 4}
        self.mock_response.elapsed = datetime.timedelta(0)
        self.mock_response.text = u'500 Internal Server Error'
        MockPost.return_value = self.mock_response

        with self.assertRaises(Exception):
            self._make_payment()

    @patch('iqh_payments.backends.hnam_rest_payments.BillPayConfig')
    @patch('iqh_payments.backends.hnam_rest_payments.Organization')
    @patch('iqh_payments.backends.hnam_rest_payments.requests.post')
    def submit_payment_exception_test(self, MockPost, org, config):
        """
        _submit_payment should return an exception when the POST to charge
        the payment by interchange_id unexpectedly raised an exception.
        """

        MockPost.side_effect = requests.exceptions.Timeout

        with self.assertRaises(requests.exceptions.Timeout):
            self._make_payment()

    def _make_payment(self):

        return payments._submit_payment(
            'BASELINE',
            304.23,
            'Mr. Smith',
            '123 Main St',
            'Kansas City',
            'MO',
            '64117',
            '9999',
            'interchangeid',
            'tokenreferenceid',
            'baseline',
            'guarantorid',
            'accountid',
            '122025'
        )
