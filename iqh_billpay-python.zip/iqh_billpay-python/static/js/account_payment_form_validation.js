$(function(){

  // each regex allows empty strings
  var visaRegex = /^4|^$/,
      mastercardRegex = /^5$|^5[1-5]|^$/,
      amexRegex = /^3$|^34|^37|^$/,
      discoverRegex = /^6|^$/;

  var validate_cvv = false,
      validate_card_number = false;


  if (context_data.is_mobile == 'False'){
    var info_content = '';
    if ($('#card-american').length) {
      if ($('#card-visa, #card-mastercard, #card-discover').length) {
        img = 'cvv-vmd-ax.png';
      }
      else {
        img = 'cvv-ax.png';
      }
    } else {
        img = 'cvv-vmd.png';
    }
    info_content = '<img src="' + gStaticUrl + 'img/' + img + '"/>';
    var elem = $('#err_security_number, #security_number').last();
    elem.infoBox({html: info_content, position: 'right', icon_text: gettext("What is this?"), width: 310, add_icon: true});
  }

  /** Highlights the credit type image with the associated credit card number and
  updates the images in the info box for CVV based on the card number entered. **/
  function highlightCardType() {
    var card_num = $(this).val(),
        img = '';

    /**
    Checks if visa card type is supported and if it
    is supported highlights the VISA image if the value
    entered matches the VISA regex.
    **/
    if ($('#card-visa').length) {
      if (visaRegex.test(card_num)) {
        $('#card-visa').fadeTo('fast', 1);
        img = 'cvv-vmd.png';
      } else {
        $('#card-visa').fadeTo('fast', 0.5);
      }
    }

    /**
    Checks if mastercard card type is supported and if it
    is supported highlights the MASTERCARD image if the value
    entered matches the MASTERCARD regex.
    **/
    if ($('#card-mastercard').length) {
      if (mastercardRegex.test(card_num)) {
         $('#card-mastercard').fadeTo('fast', 1);
         img = 'cvv-vmd.png';
      } else {
         $('#card-mastercard').fadeTo('fast', 0.5);
      }
    }

    /**
    Checks if AMEX card type is supported and if it
    is supported highlights the AMEX image if the value
    entered matches the AMEX regex.
    **/
    if ($('#card-american').length) {
      if (amexRegex.test(card_num)) {
          $('#card-american').fadeTo('fast', 1);
          img = 'cvv-ax.png';
        } else {
          $('#card-american').fadeTo('fast', 0.5);
        }
    }

    /**
    Checks if DISCOVER card type is supported and if it
    is supported highlights the DISCOVER image if the value
    entered matches the DISCOVER regex.
    **/
    if ($('#card-discover').length) {
      if (discoverRegex.test(card_num)) {
        $('#card-discover').fadeTo('fast', 1);
        img = 'cvv-vmd.png';
      } else {
          $('#card-discover').fadeTo('fast', 0.5);
      }
    }

    if (card_num.length === 0 || img === '') {
      img = 'cvv-vmd.png';

      if ($('#card-american').length) {
        if (($('#card-visa').length || $('#card-mastercard').length || $('#card-discover').length))
          img = 'cvv-vmd-ax.png';
        else {
          img = 'cvv-ax.png';
        }
      }
    }

    var info_content = '<img src="'+ gStaticUrl +'img/' + img + '" />';
    $('.info-box .content').html(info_content);
  }

  $.each($('.error-msg'), function() {
    $(this).attr('for', this.id.slice(4));
    $(this).attr('generated', 'generated');
  });

  $.validator.addMethod(
    "requiredDate",
    function(value, element) {
      element.visited = true;
      if (($('#id_expiration_date_month')[0].visited && $('#id_expiration_date_year')[0].visited) ||
        (this.errorsFor(element) && this.errorsFor(element).is(':visible'))) {
          return $('#id_expiration_date_month').val() != '0' && $('#id_expiration_date_year').val() != '0';
      }
      return true;
    },
    function() {
      if ($('#id_expiration_date_month').val() === 0 && $('#id_expiration_date_year').val() === 0) {
       return gettext('This field is required.');
      }
      return gettext("Enter a valid date.");
    }
  );

  $.validator.addMethod(
    "amount",
    function(value, element, param) {
      value = value.replace(/[$,]/g, '');
      return value > 0 && value <= param;
    },
    function() {
      value = $('#payment_amount').val().replace(/[$,]/g, '');
      if (/[^\d\.]/.test(value) || value <= 0) {
        return gettext('You must enter a payment amount.');}
      return gettext('Enter an amount less than or equal to your current balance.');
    }
  );

  $.validator.addMethod(
    "zip",
    function(value, element, param) {
      var zipRegExp = /^\d{5}(?:-\d{4})?$/;
      return zipRegExp.test(value);
    },
    gettext('Enter a zip code in the format XXXXX or XXXXX-XXXX.')
  );

  $("form").validate({
    onsubmit: false,
    errorElement: "span",
    errorClass: "error-msg",
    validClass: "",
    onfocusout: function(element, event) {
      if (!this.checkable(element) && (element.name in this.submitted ||
       !this.optional(element) || $(element).rules()['required']) &&
        (element != $('#card_number')[0] && (element != $('#security_number')[0]))) {
       this.element(element);
      }
    },
    highlight: function(element, errorClass) {
      if (element.id.indexOf('expiration_date') > 0) {
        $('#field_expiration_date').addClass('error');
      }
      else { $('#field_'+element.id).addClass('error'); }
    },
    unhighlight: function(element, errorClass) {
      if (element.id.indexOf('expiration_date') > 0) {
        $('#field_expiration_date').removeClass('error');
      }
      else { $('#field_'+element.id).removeClass('error'); }
    },
    errorPlacement: function(error, element) {
      if (element.attr('name') == 'expiration_date_month' ||
        element.attr('name') == 'expiration_date_year') {
        error.insertAfter('#id_expiration_date_year');
      }
      else {
        error.insertAfter(element);
      }
    },
    groups: {
      expiration_date: "expiration_date_month expiration_date_year"
    },
    rules: {
      payment_amount: {required: true, amount: context_data.amount_due },
      expiration_date_month: {required: true, requiredDate: true},
      expiration_date_year: {required: true, requiredDate: true},
      payer_name: {required: true, minlength: 2},
      address: "required",
      city: "required",
      state: "required",
      postal_code: {required: true, zip: true}
    },
    messages: {
      payer_name: {
        minlength: gettext('Ensure this value has at least 2 characters.')
      }
    }
 });

  // Validates the cvv number entered for empty value and a valid cvv number based on the card type.
  function validateCVV(event){
    var cvv = $(this).val();
    var card_number = $('#card_number').val();
    var error_msg = '';

    // Only validate cvv if the user has focused out of the field
    if (event.type == 'focusout') {
      validate_cvv = true;
    }

    if (!validate_cvv){
      return true;
    }

    if(cvv.length === 0) {
      error_msg = gettext('This is a required field.');
      add_error_styles('field_security_number', 'err_security_number', error_msg, 'security_number');
      return true;
    }

    var card_type = $.payment.cardType(card_number);

    if(!($.payment.validateCardCVC(cvv, card_type)) ||
       (card_type == 'amex' && cvv.length === 3)) {

      if (card_type == 'amex') {
        error_msg = gettext('This is the 4 digit number found on the front of your card.');
      } else {
        error_msg = gettext('This is the 3 digit number found on the back of your card.');
      }

      add_error_styles('field_security_number', 'err_security_number', error_msg, 'security_number');

    } else {
      remove_error_styles('field_security_number', 'err_security_number');
    }

  }

  // Validates the credit card number entered for empty value and a valid credit card number.
  function validateCCN(event){
    var ccn = $(this).val();

    // Only validate ccn if the user has focused out of the field
    if (event.type == 'focusout') {
      validate_card_number = true;
    }

    if (!validate_card_number){
      return true;
    }

    if(ccn.length === 0) {
        error_msg = gettext('This is a required field.');
        add_error_styles('field_card_number', 'err_card_number', error_msg, 'card_number');

    } else if(!($.payment.validateCardNumber(ccn))) {
      error_msg = gettext('Enter a valid card number.');
      add_error_styles('field_card_number', 'err_card_number', error_msg, 'card_number');

    } else {
      remove_error_styles('field_card_number', 'err_card_number');
    }
  }

  // Removes the error style components for card number and cvv as required.
  function remove_error_styles(field_id, error_id){
    $('#' + error_id).remove();
    $('#' + field_id).removeClass('error');

  }

  // Adds Error style components for the card number and cvv as required.
  function add_error_styles(field_id, error_id, error_msg, element){
    remove_error_styles(field_id, error_id);
    $('#' + field_id).addClass('error');
    var error_element = $('<span />').attr({
      'class': 'error-msg',
      'id': error_id
    });
    error_element.text(error_msg);
    error_element.insertAfter($('#' + element));
  }

  // Validates the CCN and highlights card type img of the associated card number.
  $('#card_number').focusout(validateCCN)
                   .keyup(validateCCN)
                   .keyup(highlightCardType);

  // Validates the CVV
  $('#security_number').focusout(validateCVV)
                       .keyup(validateCVV);
});