from django.test.client import RequestFactory
from django.template import RequestContext
from django.template.loader import render_to_string
from django.core.urlresolvers import reverse
from unittest import TestCase
from bs4 import BeautifulSoup
from forms import PaymentForm


class AccountPaymentsTests(TestCase):
    """
    Templates tests for the account_payment template components.
    """
    def setUp(self):
        self.request = RequestFactory(guarantor_id='98765', account_id='1234').get('/')

        form = PaymentForm(request=self.request, payment_types={'Visa': 'V', 'Master': 'M'}, org_tz='US/Central')

        context = RequestContext(self.request, {'account_id': '1234',
            'interchange_id_lookup_api_url': "http://google.com",
            'tokenization_service_timeout': 20000,
            'form': form})

        html = render_to_string('account_payment.html', context)
        self.soup = BeautifulSoup(html)

    def account_payment_test(self):
        """
        Account payments form should have a cancel link with the query param as
        status=cancel.
        """
        expected_cancel_link = "{0}?status=cancel".format(reverse('view_accounts'))
        cancel_link = self.soup.find(href=expected_cancel_link)
        self.assertEquals(expected_cancel_link, cancel_link['href'])
