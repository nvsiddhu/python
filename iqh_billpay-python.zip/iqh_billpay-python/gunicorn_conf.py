# -*- coding: utf-8 -*-
import multiprocessing
workers = 2 * multiprocessing.cpu_count()

bind = '0.0.0.0:8000'
secure_scheme_headers = {'X-FORWARDED-PROTOCOL': 'https', 'X-FORWARDED-SSL': 'on'}
timeout = 120
forwarded_allow_ips = '*'
proc_name = 'iqh_billpay'
errorlog = '/var/log/gunicorn/iqh_billpay_error.log'

# NOTE Per http://stackoverflow.com/a/13581637/50498 this location is configured in settings.LOGGING
# "-" means to log to stderr
accesslog = '-'

# NOTE We are following a convention set by Go/PopHealth: https://wiki.ucern.com/display/OPSINFRA/Splunk+for+Access+Logs
# However, gunicorn doesn't provide the following bit at the end: "%I %O"
# If we ever want to add more info to the end of this line, we must fill in dashes to move shared parsing rules past that part
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" "%({Host}i)s" "%({X-Forwarded-For}i)s" %(T)s/%(D)s'
