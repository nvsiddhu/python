# -*- coding: utf-8 -*-

from django.test import TestCase

from ..utils import BillpayRequestFactory
from bs4 import BeautifulSoup
from django.core.urlresolvers import reverse
from django.template import RequestContext
from django.template.loader import render_to_string


class AccountPaymentsTests(TestCase):
    """
    Templates tests for the account_payment template components.
    """
    def setUp(self):
        self.request = BillpayRequestFactory(guarantor_id='g_1', account_id='1234').get('/')
        self.request.payment_receiver_id = self.request.acct['payment_receiver_id']

    def account_payment_test(self):
        """
        The confirm payment page should have a cancel link with the query param of
        status set to cancel.
        """
        context = RequestContext(self.request, {'account_id': '1234'})

        html = render_to_string('confirm_payment.html', context)
        self.soup = BeautifulSoup(html)

        expected_cancel_link = "{0}?status=cancel".format(reverse('view_accounts'))
        cancel_link = self.soup.find(href=expected_cancel_link)
        self.assertEquals(expected_cancel_link, cancel_link['href'])
