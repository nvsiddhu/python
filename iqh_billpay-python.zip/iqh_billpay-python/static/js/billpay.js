/*
 * Make all AJAX requests include the CSRF token.
 * See: http://docs.djangoproject.com/en/dev/ref/contrib/csrf/#ajax
 */
$.ajaxSetup({
    beforeSend: function(xhr, settings) {
        function getCookie(name) {
            var cookieValue = null;
            if (document.cookie && document.cookie != '') {
                var cookies = document.cookie.split(';');
                for (var i = 0; i < cookies.length; i++) {
                    var cookie = jQuery.trim(cookies[i]);
                    // Does this cookie string begin with the name we want?
                    if (cookie.substring(0, name.length + 1) == (name + '=')) {
                        cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                        break;
                    }
                }
            }
            return cookieValue;
        }
        if (!(/^http:.*/.test(settings.url) || /^https:.*/.test(settings.url))) {
            // Only send the token to relative URLs i.e. locally
        	c = getCookie('iqh_csrf');
        	if (c){xhr.setRequestHeader("X-CSRFToken", c);}
        }
    }
});

/* Prevents forms from being submitted more than once. */
$(document).ready(function() {
	 $('form').submit(function() {
	    if (this.beenSubmitted)
	      return false;
	    else
	      this.beenSubmitted = true;
	 });
});

/* String formatting.
 * Example:
 *
 * var location = 'World';
 * alert('Hello {0}'.format(location));
 */
String.prototype.format = function() {
 	var s = this,
      i = arguments.length;

  while (i--) {
  	s = s.replace(new RegExp('\\{' + i + '\\}', 'gm'), arguments[i]);
  }
  return s;
};
