# -*- coding: utf-8 -*-

import time

from fabric.api import execute


def timed_execute(task, *args, **kwargs):
    start = time.time()
    result = execute(task, *args, **kwargs)
    task_name = getattr(task, '__name__', None)
    print "[TIMING] task {} finished in {:g} seconds".format(task_name, time.time() - start)
    return result
