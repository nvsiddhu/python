# -*- coding: utf-8 -*-

from django.utils.decorators import method_decorator

from iqh_billpay.decorators import requires_acct
from iqh_organizations.models import Organization
from django.core.cache import get_cache
from forms import RecaptchaForm


class NeedsAccountMixin(object):
    """
    Mixin that retrieves the account information by account_id.
    If no account exists, a 404 will be raised.
    """

    @method_decorator(requires_acct)
    def dispatch(self, *args, **kwargs):
        if hasattr(args[0], 'org'):
            self.org = Organization.objects.get(slug=args[0].org['slug'])
        return super(NeedsAccountMixin, self).dispatch(*args, **kwargs)


class CaptchaMixin(object):
    """
    The CaptchaMixin handles the processing of captcha in billpay.
    To consume this mixin, extend it on your FormView view. It's the
    responsibility of the view to increment the counter of failure attempts.

    Example:

    class AccountPaymentView(CaptchaMixin, FormView):
        def get_captcha_key(self):
            org_slug = self.request.org['slug']
            account_id = self.kwargs.get('account_id')
            return u'payment_failed_{0}_{1}'.format(org_slug, account_id)

    TODO: It's much more efficient to create a Captcha Field Type rather than
    extending this mixin. Please create the field in style-guide to be re-used or
    see if there is an open source project that does it for us.
    """

    max_num_of_failures = 5

    def get_context_data(self, **kwargs):
        context = super(CaptchaMixin, self).get_context_data(**kwargs)
        context['access_failures'] = self.get_access_failures()
        context['recaptcha_form'] = RecaptchaForm()
        return context

    def form_invalid(self, form):
        """
        When the form is invalid, add the extra captcha data into context.
        """
        context = self.get_context_data(form=form)
        if self.get_access_failures() > 5:

            captcha = RecaptchaForm(self.request.POST)
            captcha_context = {'recaptcha_form': captcha}
            context.update(captcha_context)

        return self.render_to_response(context)

    def get_access_failures(self):
        """
        Gets the number of failures when submitting the form.
        """
        cache = get_cache('billpay.payment.captcha.counter')
        self.captcha_counter = cache.get(self.get_captcha_key(), 0)
        return self.captcha_counter

    def increment_access_failures(self):
        """
        Increments the number of failures when submitting the form.
        """
        cache = get_cache('billpay.payment.captcha.counter')
        captcha_counter = cache.get(self.get_captcha_key(), 0)
        cache.set(self.get_captcha_key(), captcha_counter+1)

    def delete_access_failures_cache(self):
        """
        Deletes the cache holding the number of access failures.
        """
        cache = get_cache('billpay.payment.captcha.counter')
        cache.delete(self.get_captcha_key())

    def is_human(self):
        """
        Returns true if recaptcha has been checked else false.
        """
        return len(self.request.POST.get('g-recaptcha-response', '').strip()) > 0

    def get_captcha_key(self):

        raise NotImplementedError
