# -*- coding: utf-8 -*-

from cache_settings.cache_settings import create_cache_config

import logging
from logging.handlers import SysLogHandler

import django_thread_local
from iqh_logging import set_request_logging_context
from iqh_logging.logger import IQHLogger

import os
import sys

# Do not run in DEBUG in production!!!
DEBUG = False
TEMPLATE_DEBUG = DEBUG

# Disable Requests verififcation of SSL certs in local/dev/cert, Enable in staging/prod
VERIFY_SSL = True

ADMINS = (
    # TODO: add your admins here!
    #('John', 'john.doe@chsite.com'),
    #('Jane', 'jane.doe@chsite.com'),
)

APP_SLUG = 'iqh_billpay'
MANAGERS = ADMINS
TIME_ZONE = 'UTC'
# Throws and error in when using -us
#fixed in 1.6 https://code.djangoproject.com/ticket/19811
# LANGUAGE_CODE = 'en-us'
LANGUAGE_CODE = 'en'
SITE_ID = 1
USE_I18N = False

SITE_ROOT = os.path.dirname(os.path.realpath(__file__))
STATICI18N_ROOT = os.environ.get('STATIC_ROOT', os.path.join(SITE_ROOT, 'static'))

# This tells the user agent middleware to just rely on session variables
# to control the site rather than redirecting to a specific tablet or mobile
# subdomain.
UA_DOMAIN_REDIRECTION = False
# We don't have any tablet specific styles yet, so set base tablet to the
# standard base template
BASE_TEMPLATE_TABLET = 'base_standard.html'

# Ensure Django templates are cached in "real" deployments. This can be
# overridden locally so template changes are reflected immediately.
TEMPLATE_LOADERS = (
    ('django.template.loaders.cached.Loader', (
        'django.template.loaders.filesystem.Loader',
        'django.template.loaders.app_directories.Loader',
    )),
)

ROOT_URLCONF = 'urls'

TEMPLATE_DIRS = (
    os.path.join(SITE_ROOT, 'templates')
)

MIDDLEWARE_CLASSES = (
    'django_thread_local.ThreadLocalRequestMiddleware',
    'axiom_django.middleware.realip.SetRemoteAddrXForwardedFor',
    'iqh_billpay.middleware.NoCacheMiddleware',
    'iqh_billpay.middleware.IQHRequestDomainMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'iqh_billpay.middleware.ValidateUserSessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'axiom_django.middleware.http_response_exceptions.HttpResponseExceptionMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'axiom_django.middleware.csrf_used.CsrfCookieUsedMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'pipeline.middleware.MinifyHTMLMiddleware',
    'axiom_django.middleware.user_agent_detection.UserAgentDetectionMiddleware',
)

INSTALLED_APPS = (
    'django.contrib.sessions',
    'django.contrib.humanize',
    'django.contrib.messages',
    'axiom_django',
    'axiom_dates',
    'iqh_configurations',
    'iqh_domains',
    'iqh_locales',
    'iqh_organizations',
    'iqh_email',
    'iqh_billpay',
    'iqh_template_loaders',
    'axiom_django_filez',
    'theming',
    'django.contrib.staticfiles',
    'pipeline',
    'storages',
    'site_layout_config',
    'footer_config',
    'bill_pay_config',
    'statici18n',
    'recaptcha',
    'style_guide',
    'billpay_template_config',
)

TEMPLATE_CONTEXT_PROCESSORS = (
    'django.core.context_processors.request',
    'django.core.context_processors.media',
    'django.contrib.messages.context_processors.messages',
    'custom_context_processors.site_pages',
    'theming.theme_context_processor.theme_processor',
    'django.core.context_processors.i18n',
)


BASE_FONTS = (
    'Arial',
    'Times',
    'Georgia',
    'Verdana',
    'Helvetica Neue',
    'Myriad Pro',
)

# Session related settings:
# See http://docs.djangoproject.com/en/dev/topics/http/sessions/#settings
SESSION_COOKIE_NAME = 'iqh_billpay'
SESSION_EXPIRE_AT_BROWSER_CLOSE = True
SESSION_SAVE_EVERY_REQUEST = True
SESSION_ENGINE = 'cached_sessions'
SESSION_COOKIE_AGE = 60 * 15  # Session cookie for 15 minutes

# Used by the NoXSSCharField to attempt to reject script from user input.
DEFAULT_XSS_BLACKLIST_FILTER_REGEX = r'[|/()<>"=%;:#{}\[\]\\`~$^*+?!]'

CSRF_COOKIE_NAME = 'iqh_csrf'
CSRF_FAILURE_VIEW = 'axiom_django.common_views.csrf_failure'
CSRF_COOKIE_SECURE = True

# If @skip decorator is applied to a middleware function it uses this array
# to determine which url patterns to skip the function for
MIDDLEWARE_IGNORE_PATH_PREFIXES = ['/api/']

CSRF_MIDDLEWARE_IGNORE_PATHS = ['/api/', '/static/', '/jsi18n/']

NOCACHE_MIDDLEWARE_IGNORE_PATHS = ['/api/', '/static/', '/jsi18n/']

# New ReCaptcha settings. This for ReCaptcha v2. Every environment will
# now have different keys So see the appropriate sensitive settings for the keys.
G_RECAPTCHA_JS = 'https://www.google.com/recaptcha/api.js'
G_RECAPTCHA_VERIFICATION_URL = 'https://www.google.com/recaptcha/api/siteverify'

#Force https - since we autoredirect from http to https this is for sanity and not required
SESSION_COOKIE_SECURE = True

#needed for cms
CACHE_NAMESPACE_OAUTH = 'iqh.oauth'

# This is the header used in the IQHDenyApiAccessByIpMiddleware class
# If the header is X-Client-IP-Header then this value should be converted
# to HTTP_X_CLIENT_IP_HEADER due to Django behavior.
TRUSTED_HEADER = "HTTP_X_CLIENT_IP_HEADER"

MESSAGE_STORAGE = 'django.contrib.messages.storage.session.SessionStorage'

#Django-Pipeline configs
STATICFILES_STORAGE = 'pipeline.storage.PipelineCachedStorage'
STATIC_URL = '/static/'
STATIC_ROOT =  os.environ.get('STATIC_ROOT', os.path.join(SITE_ROOT, 'static_deploy'))
PIPELINE_COMPILERS = (
  'pipeline.compilers.less.LessCompiler',
)
PIPELINE_LESS_ARGUMENTS = '--include-path={0}'.format(os.path.join(SITE_ROOT, 'static', 'less'))

PIPELINE_CSS_COMPRESSOR = 'pipeline.compressors.yui.YUICompressor'
PIPELINE_JS_COMPRESSOR = 'pipeline.compressors.yui.YUICompressor'

PIPELINE_CSS = {
    # themed styelsheets that are themed and delivered through moonpie.
    # Ensure these assets are added to settings_compress
    'standard': {
        'source_filenames': (
            'less/base_standard.less',
        ),
        'output_filename': 'css/default/standard.css',
        'extra_context': {
            'media': 'screen,projection,print',
        },
    },
    'mobile': {
        'source_filenames': (
            'less/base_mobile.less',
        ),
        'output_filename': 'css/default/mobile.css',

        'extra_context': {
            'media': 'screen,projection,print',
        },
    },
    'print': {
        'source_filenames': (
            'css/print.css',
        ),
        'output_filename': 'css/default/print.css',

        'extra_context': {
            'media': 'print',
        },
    },
}

PIPELINE_JS = {
    'standard': {
        'source_filenames': (
            'js/billpay.js',
            'js/style_guide/date-picker.js',
            'js/style_guide/info-box.js',
            'js/style_guide/timeout-dialog.js',
            'js/style_guide/alerts.js',
            'js/style_guide/bootstrap-modal.js',
            'js/style_guide/dialog.js',
            'js/style_guide/spin.js',
            'js/cors_request.js',
            'js/spinner.js',
            'lib/jquery.payment.js',
        ),
        'output_filename': 'js/standard.js',
    },
    'mobile': {
        'source_filenames': (
            'js/billpay.js',
            'js/cors_request.js',
            'js/style_guide/date-picker.js',
            'js/style_guide/spin.js',
            'js/spinner.js',
            'lib/jquery.payment.js',
            'js/style_guide/timeout-dialog.js',
        ),
        'output_filename': 'js/mobile.js',
    },
    'tokenizer': {
        'source_filenames': (
            'js/account_payment_form_validation.js',
            'js/tokenizer.js',
        ),
        'output_filename': 'js/make_payment.js',
    },
}

MOONPIE_THEMING_VERSION = '35'

LOGGING = {
    'version': 1,
    'disable_existing_loggers': True,
    'root': {
        'level': 'WARNING',
        'handlers': ['console'],
    },
    'formatters': {
        'detail_logging': {
            'format': ' [%(levelname)s] %(name)s: process_id="%(process)s";thread_id="%(thread)s";%(message)s',
        },
        'axiom_logging': {
            #leave the space for syslog formatting compatibility
            'format': ' %(message)s'
        },
    },
    'handlers': {
        'IQHBPHandler': {
            'class': 'axiom_logging.handler.AxiomLoggingHandler',
            'formatter': 'axiom_logging',
            'application': 'iqh_billpay',
        },
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'detail_logging'
        },
        'access_file': {
            'class': 'logging.handlers.SysLogHandler',
            'formatter': 'axiom_logging',
            'facility': SysLogHandler.LOG_LOCAL0,
            'address': '/dev/log',
        },
        'splunk': {
            'class': 'iqh_logging.handler.SplunkHandler',
            'formatter': 'axiom_logging',
            'facility': SysLogHandler.LOG_LOCAL1,
            'address': '/dev/log',
        },
    },
    'loggers': {
        'iqh_billpay': {
            'level': 'WARNING',
            'handlers': ['splunk', 'IQHBPHandler'],
            'propagate': False,
        },
        # Per http://stackoverflow.com/a/13581637/50498:
        'gunicorn.access': {
            'level': 'INFO',
            'handlers': ['access_file'],
            'propagate': False,
        },
    },
}

DEFAULT_LOGGER = "iqh_billpay"
set_request_logging_context(DEFAULT_LOGGER,
                            django_thread_local.get_current_request)
logging.setLoggerClass(IQHLogger)

DEPLOYMENT_SUPPORTS_PDFKIT = False

try:
    from deployment_settings import *
except ImportError:
    from local_settings import *

if DEPLOYMENT_MODE != 'local':
    # Used to encrypt data in session
    from ConfigParser import RawConfigParser
    config = RawConfigParser()

    # need to have root access to read django-aes-secret file in the shell
    try:
        config.read('/etc/sysconfig/django-aes-secret')
        SESSION_DATA_ENC_KEY = config.get('secrets', 'AES_SECRET_KEY')
    except Exception as e:
        print "Either AES key doesn't exist or user doesn't have access to read the key. If using the python shell, make sure you're running it as root."
        raise e

if DEPLOYMENT_MODE not in ('local', 'branch'):
    CACHES = create_cache_config(CACHE_HOSTS, CACHE_CONNECTION_TIMEOUT, MOONPIE_THEMING_VERSION, app='billpay')
    CACHES.update(DEFAULT_CACHE)

if DEPLOYMENT_MODE in ('local', 'dev') and DEBUG and 'test' not in sys.argv:
    # Cannot test in IE if debug toolbar is enabled. Debug toolbar uses jQuery 2.1.0
    # That version does work in IE 9 and less.
    # MIDDLEWARE_CLASSES += ('debug_toolbar.middleware.DebugToolbarMiddleware',)
    # INSTALLED_APPS += ('debug_toolbar', 'template_timings_panel')
    DEBUG_TOOLBAR_PATCH_SETTINGS = False
    INTERNAL_IPS = ('127.0.0.1',)

    DEBUG_TOOLBAR_CONFIG = {'SHOW_TOOLBAR_CALLBACK': 'iqh_billpay.debug_toolbar_helper.helper'}
    DEBUG_TOOLBAR_PANELS = (
        'debug_toolbar.panels.versions.VersionsPanel',
        'debug_toolbar.panels.timer.TimerPanel',
        'debug_toolbar.panels.settings.SettingsPanel',
        'debug_toolbar.panels.headers.HeadersPanel',
        'debug_toolbar.panels.request.RequestPanel',
        'debug_toolbar.panels.sql.SQLPanel',
        #Uncomment below to see static files
        #'debug_toolbar.panels.staticfiles.StaticFilesPanel',
        'debug_toolbar.panels.templates.TemplatesPanel',
        'debug_toolbar.panels.cache.CachePanel',
        'debug_toolbar.panels.signals.SignalsPanel',
        'debug_toolbar.panels.logging.LoggingPanel',
        'debug_toolbar.panels.redirects.RedirectsPanel',
        'template_timings_panel.panels.TemplateTimings.TemplateTimings'
    )

if DEPLOYMENT_MODE == 'local':
    INSTALLED_APPS += ('django_nose',)
    TEST_RUNNER = 'django_nose.NoseTestSuiteRunner'
    NOSE_ARGS = [
            '--with-doctest',
            '--enable-pydocstring',
            '--ignore-files=fabfile.py',
            '--ignore-files=apple.py',
            '--logging-clear-handlers'
    ]

from allowed_hosts_setting import *  # noqa
