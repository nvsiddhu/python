/*
 * Axiom Date Picker
 * 
 * Extends jQuery UI datepicker with default options.
 * See: http://jqueryui.com/demos/datepicker/
 * 
 * date-picker.js v1.0
 */
(function($) {
  $.fn.axiomDatepicker = function(opts) {

    var initial_opts = {
      showOn: 'both',
      buttonImage: gStaticUrl + 'img/ico-calendar.png',
      buttonImageOnly: true,
      changeMonth: true,
      changeYear: true,
      yearRange: 'c-100:+0'
    }

    opts = $.extend(initial_opts, opts || {});

    // Language specific options found in JQuery
    // http://jquery-ui.googlecode.com/svn/trunk/ui/i18n/
    if (opts.lang) {
      if (opts.lang == 'en-gb') {
        opts = $.extend(opts, {
          closeText: 'Done',
          prevText: 'Prev',
          nextText: 'Next',
          currentText: 'Today',
          monthNames: ['January','February','March','April','May','June',
          'July','August','September','October','November','December'],
          monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
          'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
          dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
          dayNamesShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
          dayNamesMin: ['Su','Mo','Tu','We','Th','Fr','Sa'],
          weekHeader: 'Wk',
          dateFormat: 'dd/mm/yy',
          firstDay: 1,
          showMonthAfterYear: false,
          yearSuffix: ''
        });
      }
      else if (opts.lang == 'ar') {
        opts = $.extend(opts, {
          closeText: 'إغلاق',
          prevText: '&#x3c;السابق',
          nextText: 'التالي&#x3e;',
          currentText: 'اليوم',
          monthNames: ['كانون الثاني', 'شباط', 'آذار', 'نيسان', 'آذار', 'حزيران',
          'تموز', 'آب', 'أيلول','تشرين الأول', 'تشرين الثاني', 'كانون الأول'],
          monthNamesShort: ['1','2','3','4','5','6','7','8','9','10','11','12'],
          dayNames: ['السبت', 'الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة'],
          dayNamesShort: ['سبت', 'أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة'],
          dayNamesMin: ['سبت', 'أحد', 'اثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة'],
          weekHeader: 'أسبوع',
          dateFormat: 'dd/mm/yy',
          firstDay: 0,
          showMonthAfterYear: false,
          yearSuffix: ''
        });
      }
      else if(opts.lang == 'de') {
        opts = $.extend(opts, {
          closeText: 'schließen',
          prevText: 'zurück',
          nextText: 'Vor',
          currentText: 'heute',
          monthNames: ['Januar','Februar','März','April','Mai','Juni',
          'Juli','August','September','Oktober','November','Dezember'],
          monthNamesShort: ['Jan','Feb','Mär','Apr','Mai','Jun',
          'Jul','Aug','Sep','Okt','Nov','Dez'],
          dayNames: ['Sonntag','Montag','Dienstag','Mittwoch','Donnerstag','Freitag','Samstag'],
          dayNamesShort: ['So','Mo','Di','Mi','Do','Fr','Sa'],
          dayNamesMin: ['So','Mo','Di','Mi','Do','Fr','Sa'],
          weekHeader: 'Wo',
          dateFormat: 'dd.mm.yy',
          firstDay: 1,
          showMonthAfterYear: false,
          yearSuffix: ''
        });
      }
      else if(opts.lang == 'es') {
        opts = $.extend(opts, {
          closeText: 'Cerrar',
          prevText: '&#x3c;Ant',
          nextText: 'Sig&#x3e;',
          currentText: 'Hoy',
          monthNames: ['Enero','Febrero','Marzo','Abril','Mayo','Junio',
          'Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'],
          monthNamesShort: ['Ene','Feb','Mar','Abr','May','Jun',
          'Jul','Ago','Sep','Oct','Nov','Dic'],
          dayNames: ['Domingo','Lunes','Martes','Mi&eacute;rcoles','Jueves','Viernes','S&aacute;bado'],
          dayNamesShort: ['Dom','Lun','Mar','Mi&eacute;','Juv','Vie','S&aacute;b'],
          dayNamesMin: ['Do','Lu','Ma','Mi','Ju','Vi','S&aacute;'],
          weekHeader: 'Sm',
          dateFormat: 'dd/mm/yy',
          firstDay: 1,
          showMonthAfterYear: false,
          yearSuffix: ''
        });
      }
      else if(opts.lang == 'fr') {
        opts = $.extend(opts, {
          closeText: 'Fermer',
          prevText: '&#x3c;Préc',
          nextText: 'Suiv&#x3e;',
          currentText: 'Courant',
          monthNames: ['Janvier','Février','Mars','Avril','Mai','Juin',
          'Juillet','Août','Septembre','Octobre','Novembre','Décembre'],
          monthNamesShort: ['Jan','Fév','Mar','Avr','Mai','Jun',
          'Jul','Aoû','Sep','Oct','Nov','Déc'],
          dayNames: ['Dimanche','Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi'],
          dayNamesShort: ['Dim','Lun','Mar','Mer','Jeu','Ven','Sam'],
          dayNamesMin: ['Di','Lu','Ma','Me','Je','Ve','Sa'],
          weekHeader: 'Sm',
          dateFormat: 'dd/mm/yy',
          firstDay: 1,
          isRTL: false,
          showMonthAfterYear: false,
          yearSuffix: ''
        });
      }
      else if(opts.lang == 'pt-br') {
        opts = $.extend(opts, {
          closeText: 'Fechar',
          prevText: '&#x3c;Anterior',
          nextText: 'Pr&oacute;ximo&#x3e;',
          currentText: 'Hoje',
          monthNames: ['Janeiro','Fevereiro','Mar&ccedil;o','Abril','Maio','Junho',
          'Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'],
          monthNamesShort: ['Jan','Fev','Mar','Abr','Mai','Jun',
          'Jul','Ago','Set','Out','Nov','Dez'],
          dayNames: ['Domingo','Segunda-feira','Ter&ccedil;a-feira','Quarta-feira','Quinta-feira','Sexta-feira','Sabado'],
          dayNamesShort: ['Dom','Seg','Ter','Qua','Qui','Sex','Sab'],
          dayNamesMin: ['Dom','Seg','Ter','Qua','Qui','Sex','Sab'],
          weekHeader: 'Sm',
          dateFormat: 'dd/mm/yy',
          firstDay: 0,
          showMonthAfterYear: false,
          yearSuffix: ''
        });
      }
    }
    return this.datepicker(opts);
  };
})(jQuery);
